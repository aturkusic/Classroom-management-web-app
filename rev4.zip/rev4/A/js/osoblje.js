Pozivi.ucitajOsoblje();
setInterval(console.log("Prosle su tri sekunde"),3000);
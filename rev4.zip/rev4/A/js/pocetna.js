
function pozovi(){
    Pozivi.slikeSljedeci();
}


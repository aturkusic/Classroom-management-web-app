const supertest = require("supertest");
const assert = require('assert');
const app = require("../index"); // ovdje promjena

const chai = require('chai');
const chaiHttp = require('chai-http');
chai.use(chaiHttp);
const expect = chai.expect;

var agent = supertest.agent(app);
before(function (done) {
    console.log('before any tests started');
    this.timeout(7000);
    app.on("eventPostavljenaBaza", function(){
        console.log("unutar eventPostavljenaBaza");
        done();
    });
});

//DOKUMENTACIJA
//1. https://www.chaijs.com/plugins/chai-http/?fbclid=IwAR2jvT54JYUkFv786x9MSgrxLV842Bfh-_TryJqJcodG6yRsWoevD17iRsw
//2. https://www.chaijs.com/api/bdd/#method_language-chains

// 1. MOZES IMATI VISE expect-OVA U JEDNOM it-U, A KRAJNJI REZULTAT CE BITI TACAN SAMO AKO SU SVI VRATILI true
// 2. SVE NAREDBE TIPA "get", "end"... SU USTVARI METODE OD supertest KOJE SE POZIVAJU JEDNA NAKON DRUGE

describe("slanje GET zahtijeva na \"/sveSale\" za dobavljanje svih sala", 
    function() 
    {
        it("trebao bi vratiti sve sale kao i u bazi", 
            function(done) 
            {
                agent
                .get("/sveSale")
                .end(function(err, response)
                {
                    if (err) 
                        done(err);

                    //console.log(response);
                    let sadrzajResponsea = response.body;
                    //console.log("SADRZAJ RESPONSEA - "+ sadrzajResponsea);
                    //console.log("STATUS RESPONSEA - "+ response.status);

                    let sveMoguceSale = ["0-00", "0-01", "0-02", "0-03", "0-04", "0-05", "0-06", "0-07", "0-08", "0-09", "0-10", "1-00", 
                    "1-01", "1-02", "1-03", "1-04", "1-05", "1-06", "1-07", "1-08", "1-09", "1-10", "1-11", "1-12", "1-13", "1-14", "1-15", 
                    "1-16", "1-17", "1-18", "1-19", "MA", "VA"];

                    let imaNetacnaSalaUBazi = false;
                    for(let i=0; i<sadrzajResponsea.length; i++)
                    {
                        let nepostojecaSalaUBazi = true;
                        for(let j=0; j<sveMoguceSale.length; j++)
                        {
                            if(sveMoguceSale[j] == sadrzajResponsea[i].naziv)
                            {
                                nepostojecaSalaUBazi = false;
                                break;
                            }
                        }

                        if(nepostojecaSalaUBazi == true)
                        {
                            //vrati poruku da se desila greska
                            imaNetacnaSalaUBazi = true;
                        }
                    }

                    expect(response).to.have.status(200); //mora vratiti 200 status kod
                    expect(imaNetacnaSalaUBazi).to.be.false;
                    done();
                });
            });
    });

describe("slanje GET zahtijeva na \"/osoblje\" za dobavljanje svih clanova osoblja", 
    function() 
    {
    
        it("trebao bi vratiti svo osoblje kao i u bazi", 
            function(done) 
            {
                agent
                .get("/osoblje")
                .end(function(err, response)
                {
                    if (err) 
                        done(err);

                    expect(response).to.have.status(200);

                    //console.log("CIJELI RESPONSE:\n");
                    //console.log(response);
                    let sadrzajResponsea = response.body;
                    //console.log("SADRZAJ RESPONSEA - "+ sadrzajResponsea);
                    //console.log("STATUS RESPONSEA - "+ response.status);

                    let svoPocetnoOSoblje = ["Neko Nekic", "Drugi Neko", "Test Test"];

                    let brojacNadjenihPocetnih = 0;
                    for(let i=0; i<sadrzajResponsea.length; i++)
                    {
                        let nepostojecaSalaUBazi = true;
                        for(let j=0; j<svoPocetnoOSoblje.length; j++)
                        {
                            if(svoPocetnoOSoblje[j] == sadrzajResponsea[i].ime+" "+sadrzajResponsea[i].prezime)
                            {
                                brojacNadjenihPocetnih++;
                                break;
                            }
                        }
                    }

                    if(brojacNadjenihPocetnih < 3)
                    {
                        //vrati poruku da se desila greska
                        done(err);
                    }
                    else
                        expect(brojacNadjenihPocetnih <= 3).to.equal(true);
            
                    done();
                });
            });
    });

let ocekivanoInicijalnoRedovnoZauzece = 
    {
        "predavac":"Test Test",
        "naziv":"1-11",
        "pocetak":"13:00",
        "kraj":"14:00",
        "dan": 0,
        "semestar": 0
    };

let ocekivanoInicijalnoVanrednoZauzece = 
    {
        "predavac":"Neko Nekic",
        "naziv":"1-11",
        "pocetak":"12:00",
        "kraj":"13:00",
        "datum":"01.01.2020"
    };

describe("slanje GET zahtijeva na \"/svaZauzeca\" za dobavljanje svih zauzeca", 
    function() 
    {
        it("trebao bi vratiti sva zauzeca kao i u bazi", 
            function(done) 
            {
                agent
                .get("/svaZauzeca")
                .end(function(err, response)
                {
                    //console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);
                    
                    expect(response).to.have.status(200); //mora vratiti 200 status kod
                    //console.log(response.body);

                    let tijeloOdgovora = response.body;

                    let ispravnoRedovnoZauzeceUBazi = false;
                    let ispravnoVanrednoZauzeceUBazi = false;

                    for(let i=0; i<tijeloOdgovora["periodicna"].length; i++)
                    {
                        if(JSON.stringify(tijeloOdgovora["periodicna"][i]) == JSON.stringify(ocekivanoInicijalnoRedovnoZauzece))
                        {
                            ispravnoRedovnoZauzeceUBazi = true;
                            break;
                        }  
                    }  
            
                    for(let i=0; i<tijeloOdgovora["periodicna"].length; i++)
                    {
                        if(JSON.stringify(tijeloOdgovora["vanredna"][i]) == JSON.stringify(ocekivanoInicijalnoVanrednoZauzece))
                        {
                            ispravnoVanrednoZauzeceUBazi = true;
                            break;
                        }
                    }    

                    //console.log(ispravnoVanrednoZauzeceUBazi);
                    //console.log(ispravnoRedovnoZauzeceUBazi);
                    //console.log("response vanredna\n");
                    //console.log(JSON.stringify(tijeloOdgovora["vanredna"][0]));
                    //console.log("response redovna\n");
                    //console.log(JSON.stringify(tijeloOdgovora["periodicna"][0]));

                    //".to.be.true" je isto kao da smo stavili ".to.equal(true)"
                    expect(ispravnoVanrednoZauzeceUBazi == true 
                        && ispravnoRedovnoZauzeceUBazi == true).to.be.true;
                    
                    done();
                });
            });
    });

let jednoPeriodicnoZauzece = 
    {
        predavac: "Test Test", 
        naziv: "1-15",
        pocetak: "13:57", 
        kraj: "21:12", 
        dan: 6, 
        semestar: 1,
        kliknutiDatum: "09.02.2020"
    };
let jednoPeriodicnoZauzeceBezKliknutiDatum = 
    {
        predavac: "Test Test", 
        naziv: "1-15",
        pocetak: "13:57", 
        kraj: "21:12", 
        dan: 6, 
        semestar: 1
    };
describe("da li se zauzeca azuriraju nakon dodavanja nove PERIODICNE rezervacije", 
    function() 
    {
        it("trebao bi vratiti sva zauzeca, medju kojima je i dodano PERIODICNO zauzece", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(jednoPeriodicnoZauzece)
                .end(function(err, response)
                {
                    console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);
                    
                    expect(response).to.have.status(200); //mora vratiti 200 status kod
                    //console.log(response.body);

                    let tijeloOdgovora = response.body;

                    let ubacenoZauzeceUBazu = false;
                    
                    for(let i =0; i<tijeloOdgovora["periodicna"].length; i++)
                    {
                        if(JSON.stringify(tijeloOdgovora["periodicna"][i]) 
                            == JSON.stringify(jednoPeriodicnoZauzeceBezKliknutiDatum))
                        {
                            ubacenoZauzeceUBazu = true;
                            break;
                        }
                    }
                        
                    expect(ubacenoZauzeceUBazu).to.be.true;
                    done();
                });
            });
    });

let jednoVanrednoZauzece = 
    {
        predavac: "Drugi Neko",
        naziv: "1-11",
        pocetak: "12:12", 
        kraj: "23:45",
        datum: "22.02.2020" 
    };
describe("da li se zauzeca azuriraju nakon dodavanja nove VANREDNE rezervacije", 
    function() 
    {
        it("trebao bi vratiti sva zauzeca medju kojima je i dodano VANREDNO zauzece", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(jednoVanrednoZauzece)
                .end(function(err, response)
                {
                    console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);

                    let tijeloOdgovora = response.body;

                    let ubacenoZauzeceUBazu = false;
                    
                    for(let i =0; i<tijeloOdgovora["vanredna"].length; i++)
                    {
                        if(JSON.stringify(tijeloOdgovora["vanredna"][i]) == JSON.stringify(jednoVanrednoZauzece))
                        {
                            ubacenoZauzeceUBazu = true;
                            break;
                        }
                    }
                        
                    expect(ubacenoZauzeceUBazu).to.be.true;
                    done();
                });
            });
    });

let jednoPreklapajuceVanrednoZauzece = 
    {
        predavac: "Drugi Neko",
        naziv: "1-11",
        pocetak: "11:00", 
        kraj: "23:00",
        datum: "01.01.2020" 
    };    

describe("da li se preklapajuce zauzece upise u bazu", 
    function() 
    {
        it("trebao bi vratiti poruku kako nije moguce izvrsiti POST VANREDNOG zauzeca koje se preklapa"
            +" sa inicijalnim VANREDNIM zauzecem", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(jednoPreklapajuceVanrednoZauzece)
                .end(function(err, response)
                {
                    //console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);
                    
                    expect(response.body).to.have.a.property("poruka");

                    done();
                });
            });
    });

//" datum: "06.01.2020" " ce uzrokovat preklapanje sa redovnim zauzecem koje je ponedjeljkom
let drugoPreklapajuceVanrednoZauzece = 
    {
        predavac: "Drugi Neko",
        naziv: "1-11",
        pocetak: "11:00", 
        kraj: "23:00",
        datum: "06.01.2020" 
    };

describe("da li se preklapajuce zauzece upise u bazu", 
    function() 
    {
        it("trebao bi vratiti poruku kako nije moguce izvrsiti POST VANREDNOG zauzeca koje se preklapa "
            +"sa inicijalnim REOVNIM zauzecem", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(drugoPreklapajuceVanrednoZauzece)
                .end(function(err, response)
                {
                    //console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);
                    
                    expect(response.body).to.have.a.property("poruka");

                    done();
                });
            });
    });

let jednoPeklapajucePeriodicnoZauzece = 
    {
        predavac: "Test Test", 
        naziv: "1-11",
        pocetak: "11:00", 
        kraj: "23:00", 
        dan: 0, 
        semestar: 0,
        kliknutiDatum: "06.01.2020"
    };    
describe("da li se preklapajuce zauzece upise u bazu", 
    function() 
    {
        it("trebao bi vratiti poruku kako nije moguce izvrsiti POST PERIODICNOG zauzeca koje se preklapa "
            +"sa inicijalnim REDOVNIM zauzecem", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(jednoPeklapajucePeriodicnoZauzece)
                .end(function(err, response)
                {
                    //console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);
                    
                    expect(response.body).to.have.a.property("poruka");

                    done();
                });
            });
    });

//"dan: 2" predstavlja ponedjeljak 01.01.2020
let drugoPeklapajucePeriodicnoZauzece = 
    {
        predavac: "Test Test", 
        naziv: "1-11",
        pocetak: "11:00", 
        kraj: "23:00", 
        dan: 2,  
        semestar: 0,
        kliknutiDatum: "22.01.2020"
    };    
describe("da li se preklapajuce zauzece upise u bazu", 
    function() 
    {
        it("trebao bi vratiti poruku kako nije moguce izvrsiti POST PERIODICNOG zauzeca koje se " 
            +"preklapa sa inicijalnim VANREDNIM zauzecem", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(drugoPeklapajucePeriodicnoZauzece)
                .end(function(err, response)
                {
                    //console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);
                    
                    expect(response.body).to.have.a.property("poruka");

                    done();
                });
            });
    });

let nepreklapajucePeriodicnoZauzece = 
    {
        predavac: "Test Test", 
        naziv: "1-11",
        pocetak: "11:00", 
        kraj: "23:00", 
        dan: 2,  
        semestar: 1,
        kliknutiDatum: "12.02.2020"
    };    
describe("da li se prepoznaje semestar prilikom slanja POST requesta REDOVNOG zauzeca", 
    function() 
    {
        it("trebao bi uspjesno izvrsiti PERIODICNU rezervaciju, zato sto se ona izvrsava "
            +"u semestru u kojem nema INICIJALNIH rezervacija ponedjeljkom", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(nepreklapajucePeriodicnoZauzece)
                .end(function(err, response)
                {
                    //console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);
                    
                    expect(response.body).to.not.have.property("poruka");

                    done();
                });
            });
    });

//datum: "06.03.2020" je u LJETNOM semestru
let nepreklapajuceVanrednoZauzece = 
{
    predavac: "Drugi Neko",
    naziv: "1-11",
    pocetak: "11:00", 
    kraj: "23:00",
    datum: "06.03.2020" 
};

describe("da li se prepoznaje semestar prilikom slanja POST requesta VANREDNOG zauzeca", 
    function() 
    {
        it("trebao bi uspjesno izvrsiti VANREDNU rezervaciju, zato sto se ona izvrsava "
            +"u semestru u kojem nema INICIJALNIH rezervacija u ljetnom semestru", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(nepreklapajuceVanrednoZauzece)
                .end(function(err, response)
                {
                    //console.log(response.body);
                    //console.log(response.status);

                    if (err) 
                        done(err);
                
                    expect(response.body).to.not.have.property("poruka");

                    done();
                });
            });
    });


let vanrednoZauzeceVanSemestra = 
    {
        predavac: "Drugi Neko",
        naziv: "1-11",
        pocetak: "11:00", 
        kraj: "23:00",
        datum: "29.08.2020" 
    };
    
    describe("da li se dopusta upisivanje VANREDNOG zauzeca van i ljetnog, i zimskog semestra", 
        function() 
        {
            it("trebao bi uspjesno izvrsiti VANREDNU rezervaciju, iako se ona izvrsava van semstara, "
                +"jer na taj datum nema INICIJALNH rezervacija ", 
                function(done) 
                {
                    agent
                    .post("/dodajZauzece")
                    .send(vanrednoZauzeceVanSemestra)
                    .end(function(err, response)
                    {
                        //console.log(response.body);
                        //console.log(response.status);
    
                        if (err) 
                            done(err);
                    
                        expect(response.body).to.not.have.property("poruka");
    
                        done();
                    });
                });
        });

let periodicnoZauzeceVanIjednogSemestra = 
    {
        predavac: "Test Test", 
        naziv: "1-11",
        pocetak: "11:00", 
        kraj: "23:00", 
        dan: 5,  
        semestar: "nebitno, nepostojeci",
        kliknutiDatum: "29.08.2020"
    };    
describe("slanje zahtijeva za PERIODICNOG zauzeca na datum koji ne pripada nijednom semestru", 
    function() 
    {
        it("treba vraiti poruku o tome kako nije moguce napraviti PERIODICNU rezervaciju van ijednog semestra", 
            function(done) 
            {
                agent
                .post("/dodajZauzece")
                .send(periodicnoZauzeceVanIjednogSemestra)
                .end(function(err, response)
                {
                    if (err) 
                        done(err);
                        
                    expect(response.body).to.have.property("poruka");
    
                    done();
                });
            });
    });
const Sequelize = require('sequelize');

//kreiranje konekcije, I nacin
const sequelize = new Sequelize('DBWT19', 'root', 'root', {
   host: 'localhost',
   dialect: 'mysql',
   logging: false
});

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

//IMPORT MODELAA
db.sala = sequelize.import(__dirname+'/Sala.js');
db.osoblje = sequelize.import(__dirname+'/Osoblje.js');
db.rezervacija = sequelize.import(__dirname+'/Rezervacija.js');
db.termin = sequelize.import(__dirname+'/Termin.js');

//RELACIJE MEDJU TABELAMA:

/*Uzmimo da su A i B modeli. 
-The A.hasMany(B) association means that a One-To-Many relationship exists between A and B, with the foreign key 
being defined in the target model (B).
-The A.belongsTo(B) association means that a One-To-One relationship exists between A and B, with the foreign key 
being defined in the source model (A).
-The "A.hasOne(B)"" association means that a One-To-One relationship exists between A and B, with the foreign key 
being defined in the target model (B).

To create a One-To-One relationship, the hasOne and belongsTo associations are used together;
To create a One-To-Many relationship, the hasMany and belongsTo associations are used together;
To create a Many-To-Many relationship, two belongsToMany calls are used together.*/

//VEZA JEDAN NA VISE, izmedju tabela "Osoblje" i tabele "Rezervacija":
db.osoblje.hasMany(db.rezervacija,
    {
        //"as" generise ime metode koja dobavlja informacija iz druge tabele
        as: "osobljeRezervacija",
        foreignKey: "osoba"
    });

db.rezervacija.belongsTo(db.osoblje,
    {
        as:"rezervacijaOsoblje",
        foreignKey: "osoba"
    });
//---------------------------------------------------------------------------
//VEZA JEDAN NA JEDAN, izmedju tabela "Rezervacija" i tabele "Termin":
db.termin.hasOne(db.rezervacija, 
    {
        as: "terminRezervacija",
        foreignKey: "termin"
    });

db.rezervacija.belongsTo(db.termin,
    {
        as: "rezervacijaTermin",
        foreignKey: "termin"
    });
//------------------------------------------------------------------------------
//VEZA VISE NA JEDAN, izmedju tabela "Rezervacija" i tabele "Sala":
db.rezervacija.belongsTo(db.sala,
    {
        as: "rezervacijaSala",
        foreignKey: "sala"
    });

db.sala.hasMany(db.rezervacija,
    {
        as: "salaRezervacija",
        foreignKey: "sala"
    });
//------------------------------------------------------------------------------
//VEZA JEDAN NA JEDAN, izmedju tabela "Sala" i tabele "Osoblje":
db.osoblje.hasOne(db.sala,
    {
        as: "osobljeSala",
        foreignKey: "zaduzenaOsoba"
    });

db.sala.belongsTo(db.osoblje,
    {
        as: "salaOsoblje",
        foreignKey: "zaduzenaOsoba"
    });
//-----------------------------------------------------------------------------------------------------

module.exports = db;
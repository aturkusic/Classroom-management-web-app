const express = require('express');
const app = express();

const fs = require('fs');

/* 
U Node.js-u je potrebno pisati "('./imeFajla.js')", iako se fajl nalazi u istom direktoriju kao u onom u kojem je napisan taj dio koda.
To je posljedica da kada se u require-u pojavi "./", tada se ucitava FAJL, za "/" se ucitava DIREKTORI */
const baza = require("./db.js");
const { Op } = require("sequelize");

const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//Fajlovi koji su static (jer je zadato da je neki direktorij static, pa su tako i svi fajlovi u njemu sttaic) su fajlovi koje klijenti 
//zahtijevaju (salju requestove za njih) od servera.
//Treba napraviti neki folder unutar kojeg ce se staviti svi fajlovi kao sto su slike, css-ovi, html-ovi, js-ovi...
//Izvrsavanjem naredbe "app.use(express.static('publicFajlovi'));" govorimo programu u kojem direktoriju se nalaze 
//staticki fajlovi, pri cemu se ovo moze iskoristi umjesto pisanja "app.get()" za sve fajlove, jer ce to u ovom slucaju 
//biti odradjeno za nas u pozadini (ne is ostalih metoda)
//BITNO- nakon deklarisanja statickog direktorija, Express trazi fajlove relativno od tog statickog direktorija (s tim da ime smaog statickog 
//direkorija ne ulazi u URL)!!! ---> ovo je isti princip na kojem smo radili nginx-om na Spirali 2 
app.use(express.static('publicFajlovi'));

const popunjavanjeBaze = require("./popunjavanjeBaze.js");
popunjavanjeBaze.inicijalizacijaNaVrijeme(
    ()=>{ 
            console.log("POSTAVLJANJE PORTA");
            //https://mrvautin.com/ensure-express-app-started-before-tests/
            app.listen(8080, function()
                {
                    app.emit("eventPostavljenaBaza");
                }); 
        });
//svi get requestovi se automatski generisu na osonvu pravljenja statickog folderalinijom iznad, ali
// request ukoliko se posaljes amo na "localhost:BROJ_PORTA" pise u postavci da se treba prikazati pocetna.html
app.get('/', function(request, response)
{
    response.sendFile(__dirname+"/publicFajlovi/html/pocetna5.html");
});

app.post('/dodajZauzece', function(request, response)
{
    //"req.body" - dobavlja tijelo zahtijeva se u expressu  
    let tijeloPOSTrequesta = request.body;
    
    //iako se salje kao broj atribut "dan", ajax ga prebasi u string, pa ga je potrebno ponovno prebaciti u broj
    if(tijeloPOSTrequesta.dan)
        tijeloPOSTrequesta.dan = Number(tijeloPOSTrequesta.dan);

    let sveRezervacije = {};
    sveRezervacije.vanredna = [];
    sveRezervacije.periodicna = [];
    
    baza.rezervacija.findAll({
        include:
        [
            {
                model: baza.sala,
                as: "rezervacijaSala"
            },
            {
                model: baza.osoblje,
                as: "rezervacijaOsoblje"
            },
            {
                model: baza.termin,
                as: "rezervacijaTermin"
            },
        ]
    }).then(function(sveRezervacijeIzBaze){
        sveRezervacijeIzBaze.forEach(jednaRezervacijaIzBaze =>
            {
                let nekaRezervacija = {};
    
                //isti nazivi se koriste u JSON objektu kojeg konstrusisemo
                nekaRezervacija.predavac = jednaRezervacijaIzBaze.rezervacijaOsoblje.ime;
                //"naziv" je ustavri naziv sale
                nekaRezervacija.naziv = jednaRezervacijaIzBaze.rezervacijaSala.naziv;

                //Neophodno izvrsiti formatiranje vremena, jer se tip DateTime u bazu spasava u 
                // formatu HH:MM:SS, a prilikom upisa u "kalendar.js" se ocekuje string formata HH::MM
                let vrijemeHHMM = jednaRezervacijaIzBaze.rezervacijaTermin.pocetak.split(':');
                nekaRezervacija.pocetak = vrijemeHHMM[0] + ":" + vrijemeHHMM[1];
                vrijemeHHMM = jednaRezervacijaIzBaze.rezervacijaTermin.kraj.split(':');
                nekaRezervacija.kraj = vrijemeHHMM[0] + ":" + vrijemeHHMM[1]; 

                if(jednaRezervacijaIzBaze.rezervacijaTermin.redovni == false)
                {
                    nekaRezervacija.datum = jednaRezervacijaIzBaze.rezervacijaTermin.datum;
    
                    sveRezervacije.vanredna.push(nekaRezervacija);
                }
                else 
                {
                    nekaRezervacija.dan = jednaRezervacijaIzBaze.rezervacijaTermin.dan;
                    nekaRezervacija.semestar = jednaRezervacijaIzBaze.rezervacijaTermin.semestar;
                        
                    sveRezervacije.periodicna.push(nekaRezervacija);
                }
            });
        
        let porukaOPreklapanjuIliFalse = daLiImaPoklapanjaSaPostojecomRezervacijom(tijeloPOSTrequesta, sveRezervacije);
        if(porukaOPreklapanjuIliFalse != false)
        {
            let povratnaPorukaONemogucnostiRezervisanja = {};
            povratnaPorukaONemogucnostiRezervisanja.poruka = porukaOPreklapanjuIliFalse;
            response.json(povratnaPorukaONemogucnostiRezervisanja);
        }
        else
        {
            let terminiPromisi = [];
            let rezervacijePromisi = [];

            return new Promise(
                function(resolve, reject)
                {
                    //vanredna rezervacija
                    if(tijeloPOSTrequesta['datum'] != null)
                    {
                        terminiPromisi.push(baza.termin.create(
                            {
                                redovni: false,
                                dan: null,
                                datum: tijeloPOSTrequesta.datum,
                                semestar: null,
                                pocetak: tijeloPOSTrequesta.pocetak,
                                kraj: tijeloPOSTrequesta.kraj
                            }
                        ));
                    }
                    else
                    {
                        let semestar = 0;
                        if(tijeloPOSTrequesta.semestar == "ljetni" || tijeloPOSTrequesta.semestar == 1)
                            semestar = 1;

                        terminiPromisi.push(baza.termin.create(
                            {
                                redovni: true,
                                dan: tijeloPOSTrequesta.dan,
                                datum: null,
                                semestar: semestar,
                                pocetak: tijeloPOSTrequesta.pocetak,
                                kraj: tijeloPOSTrequesta.kraj
                            }));
                    }

                    Promise.all(terminiPromisi).then(function(termin)
                        {
                            //ovdje se ne mora filtrirat, jer dodajemo smao jedan termin
                            let novododaniTermin = termin[0];

                            let odabraniClanOsobljaIzBaze = {};
                            baza.osoblje.findAll({
                                where:
                                {
                                    [Op.and]: [
                                        { ime: tijeloPOSTrequesta.predavac.split(' ')[0] },
                                        { prezime: tijeloPOSTrequesta.predavac.split(' ')[1] }
                                    ]
                                }
                            }).then(function(trazenaOsobaIzBaze)
                                {
                                    odabraniClanOsobljaIzBaze = trazenaOsobaIzBaze[0];

                                    let odabranSalaIzBaze = {};
                                    baza.sala.findAll({
                                        where:
                                        {
                                            naziv: tijeloPOSTrequesta.naziv
                                        }
                                    }).then(function(trazenaSalaIzBaze)
                                        {
                                            odabranaSalaIzBaze = trazenaSalaIzBaze[0];

                                            rezervacijePromisi.push(baza.rezervacija.create(
                                                {
                                                    termin: novododaniTermin.id,
                                                    sala: odabranaSalaIzBaze.id,
                                                    osoba: odabraniClanOsobljaIzBaze.id
                                                }));
                        
                                            let novaRezervacija = {};
                        
                                            novaRezervacija.predavac = odabraniClanOsobljaIzBaze.ime +
                                            " " + odabraniClanOsobljaIzBaze.prezime;
                                            //osnosi se na naziv sale
                                            novaRezervacija.naziv = odabranaSalaIzBaze.naziv;
                                            novaRezervacija.pocetak = novododaniTermin.pocetak;
                                            novaRezervacija.kraj = novododaniTermin.kraj;
                        
                                            if(tijeloPOSTrequesta['datum'] != null)
                                            {
                                                novaRezervacija.datum = tijeloPOSTrequesta.datum;

                                                sveRezervacije.vanredna.push(novaRezervacija);
                                            }
                                            else
                                            {
                                                novaRezervacija.dan = tijeloPOSTrequesta.dan;
                                                novaRezervacija.semestar = tijeloPOSTrequesta.semestar;

                                                sveRezervacije.periodicna.push(novaRezervacija);
                                            }
                        
                                            response.json(sveRezervacije);
                                        });

                                });

                        }).catch(function(error){console.log("GRESKA U DRUGOM PROMISU, DODAVNJE REZERVACIJE -"+ error)});

                }).catch(function(error){console.log("GRESKA U PRVOM PROMISU, DODAVNJE REZERVACIJE -"+ error)});;
        }
    });

   /*KOD ZA SPIRALU 3:
   fs.readFile(__dirname+'/publicFajlovi/zauzeca.json', function(err, buffer)
   {
        if(err) 
            throw err;

        let objekat = JSON.parse(buffer);

        if(tijeloPOSTrequesta['datum'])
            objekat.vanredna.push(tijeloPOSTrequesta);
        else
            objekat.periodicna.push(tijeloPOSTrequesta);

         //"JSON.stringify(objekt)" funckija pretvara objekt u string koji je json formata
        fs.writeFile(__dirname+'/publicFajlovi/zauzeca.json', JSON.stringify(objekat), function(err){
                if(err) 
                    throw err;
        })
        
        response.json(objekat);
   });*/
});

function daLiImaPoklapanjaSaPostojecomRezervacijom(tijeloPOSTrequesta, sveRezervacije)
{
    //vanredna rezervacija
    if(tijeloPOSTrequesta["datum"] != null)
    {
        var nizVanrednih =  sveRezervacije["vanredna"];

        for(let i=0; i<nizVanrednih.length; i++)
        {
            //ispitujes da li postoji u fajlu da se preklapa
            if(nizVanrednih[i].datum == tijeloPOSTrequesta.datum 
                && daLiSePoklapajuIntervali(tijeloPOSTrequesta.pocetak, tijeloPOSTrequesta.kraj, nizVanrednih[i].pocetak, 
                nizVanrednih[i].kraj) && nizVanrednih[i].naziv == tijeloPOSTrequesta.naziv)
            {
                return "Nije moguce rezervisati salu "+tijeloPOSTrequesta.naziv
                        +" sa navedenim datumom "+tijeloPOSTrequesta.datum
                        +" i termin od "+tijeloPOSTrequesta.pocetak+" do "+tijeloPOSTrequesta.kraj
                        +" zbog preklapanja sa terminom od "+nizVanrednih[i].predavac+"!";
            }
        }

        let nizPeriodicnih =  sveRezervacije['periodicna'];

        for(let i=0; i<nizPeriodicnih.length; i++)
        {
            let danProsljedjenogDatuma = parseInt(tijeloPOSTrequesta.datum.split('.')[0], 10);
            let mjesecProsljedjenogDatuma = parseInt(tijeloPOSTrequesta.datum.split('.')[1], 10) - 1;
            let godinaProsljedjenogDatuma = parseInt(tijeloPOSTrequesta.datum.split('.')[2], 10);
    
            let danUSedmiciIzvadjenIzDatuma = new Date(godinaProsljedjenogDatuma, mjesecProsljedjenogDatuma, 
                danProsljedjenogDatuma).getDay();

            if(danUSedmiciIzvadjenIzDatuma != 0)
                danUSedmiciIzvadjenIzDatuma = danUSedmiciIzvadjenIzDatuma - 1;
            else
                danUSedmiciIzvadjenIzDatuma = 6;

            let jeLiMjesecVanredneRezervacijeUSemestruPeriodicneRezervacije = false;

            if( ( (mjesecProsljedjenogDatuma>=9 && mjesecProsljedjenogDatuma<=11) || 
                mjesecProsljedjenogDatuma==0) && 
                (nizPeriodicnih[i].semestar == "zimski" || nizPeriodicnih[i].semestar == 0) )
            {
                jeLiMjesecVanredneRezervacijeUSemestruPeriodicneRezervacije = true;
            }        
            else if( (mjesecProsljedjenogDatuma>=1 && mjesecProsljedjenogDatuma<=5) &&
                (nizPeriodicnih[i].semestar == "ljetni"|| nizPeriodicnih[i].semestar == 1) )
            {
                jeLiMjesecVanredneRezervacijeUSemestruPeriodicneRezervacije = true;
            }
                    
            //ispitujes da li postoji u fajlu da se preklapa
            if(nizPeriodicnih[i].dan == danUSedmiciIzvadjenIzDatuma 
                && jeLiMjesecVanredneRezervacijeUSemestruPeriodicneRezervacije
                && daLiSePoklapajuIntervali(tijeloPOSTrequesta.pocetak, tijeloPOSTrequesta.kraj, nizPeriodicnih[i].pocetak, 
                    nizPeriodicnih[i].kraj) && nizPeriodicnih[i].naziv == tijeloPOSTrequesta.naziv)
            {
                return "Nije moguce rezervisati salu "+tijeloPOSTrequesta.naziv+" sa navedenim datumom "
                        +tijeloPOSTrequesta.datum+" i termin od "+tijeloPOSTrequesta.pocetak
                        +" do "+tijeloPOSTrequesta.kraj
                        +" zbog preklapanja sa terminom od "+nizVanrednih[i].predavac+"!";
            }
        }
    
    }
    else
    {
        let mjesecKliknutogDatuma = parseInt(tijeloPOSTrequesta.kliknutiDatum.split('.')[1], 10) - 1;
        if(( (mjesecKliknutogDatuma>=0 && mjesecKliknutogDatuma<=5) 
             || (mjesecKliknutogDatuma>=9 && mjesecKliknutogDatuma<=11)) == false)
        {
            return "Ne mozete napraviti periodicnu rezervaciju u mjesecima koji ne pripadaju ni zimskom"
                +", ni ljetnom semestru";
        }    

        let nizPeriodicnih =  sveRezervacije['periodicna'];

        for(let i=0; i<nizPeriodicnih.length; i++)
        {
            //ispitujes da li postoji u fajlu da se preklapa
            if(nizPeriodicnih[i].dan == tijeloPOSTrequesta.dan && nizPeriodicnih[i].semestar == tijeloPOSTrequesta.semestar 
                && daLiSePoklapajuIntervali(tijeloPOSTrequesta.pocetak, tijeloPOSTrequesta.kraj, nizPeriodicnih[i].pocetak, 
                    nizPeriodicnih[i].kraj) && nizPeriodicnih[i].naziv == tijeloPOSTrequesta.naziv)
            {
                return "Nije moguce rezervisati salu "+tijeloPOSTrequesta.naziv+" sa navedenim datumom "
                        +tijeloPOSTrequesta.kliknutiDatum+" i termin od "+tijeloPOSTrequesta.pocetak
                        +" do "+tijeloPOSTrequesta.kraj
                        +" zbog preklapanja sa terminom od "+nizPeriodicnih[i].predavac+"!";
            }
        }

        let nizVanrednih = sveRezervacije['vanredna'];

        for(let i=0; i<nizVanrednih.length; i++)
        {
            //parseInt(object, radix)
            let danVanrednogDatuma = parseInt(nizVanrednih[i].datum.split('.')[0], 10);
            let mjesecVanrednogDatuma = parseInt(nizVanrednih[i].datum.split('.')[1], 10) -1;
            let godinaVanrednogDatuma = parseInt(nizVanrednih[i].datum.split('.')[2], 10);

            let danUSedmici = new Date(godinaVanrednogDatuma, mjesecVanrednogDatuma, danVanrednogDatuma).getDay();

            if(danUSedmici != 0)
                danUSedmici = danUSedmici - 1;
            else
                danUSedmici = 6;
                
            let mjesecTrenutnogVanrednogZauzeca = parseInt(nizVanrednih[i].datum.split('.')[1], 10) - 1;

            let jeLiMjesecOdabranogDatumaUIstomSemestruKaoVanrednoZauzece = false;
            if( ( (mjesecKliknutogDatuma>=9 && mjesecKliknutogDatuma<=11) || 
                mjesecKliknutogDatuma==0) && 
                ( (mjesecTrenutnogVanrednogZauzeca>=9 && mjesecTrenutnogVanrednogZauzeca<=11) || 
                mjesecTrenutnogVanrednogZauzeca==0) )
            {
                jeLiMjesecOdabranogDatumaUIstomSemestruKaoVanrednoZauzece = true;
            }        
            else if( (mjesecKliknutogDatuma>=1 && mjesecKliknutogDatuma<=5) &&
                    (mjesecTrenutnogVanrednogZauzeca>=1 && mjesecTrenutnogVanrednogZauzeca<=5) )
            {
                jeLiMjesecOdabranogDatumaUIstomSemestruKaoVanrednoZauzece = true;
            }  

            //ispitujes da li postoji u fajlu da se preklapa
            if(danUSedmici == tijeloPOSTrequesta.dan && 
                daLiSePoklapajuIntervali(tijeloPOSTrequesta.pocetak, tijeloPOSTrequesta.kraj, nizVanrednih[i].pocetak, 
                    nizVanrednih[i].kraj) 
                && nizVanrednih[i].naziv == tijeloPOSTrequesta.naziv
                && jeLiMjesecOdabranogDatumaUIstomSemestruKaoVanrednoZauzece == true)
            {
                return "Nije moguce rezervisati salu "+tijeloPOSTrequesta.naziv+" sa navedenim datumom "
                        +tijeloPOSTrequesta.kliknutiDatum+" i termin od "+tijeloPOSTrequesta.pocetak+" do "+tijeloPOSTrequesta.kraj
                        +" zbog preklapanja sa terminom od "+nizVanrednih[i].predavac+"!";
            }
        }
    }

    return false;
}

function daLiSePoklapajuIntervali(pocetak1, kraj1, pocetak2, kraj2)
{
	// II nacin (moglo se je sve prevesti i u minute):
	pocetak1 = pocetak1.split(":")[0]*60 + pocetak1.split(":")[1];
	kraj1 = kraj1.split(":")[0]*60 + kraj1.split(":")[1];
	pocetak2 = pocetak2.split(":")[0]*60 + pocetak2.split(":")[1];
	kraj2 = kraj2.split(":")[0]*60 + kraj2.split(":")[1];
		
	//uradjena konverzija iz stringa u int, jer je vremena poredio kao stringove
	pocetak1 = parseInt(pocetak1);
	kraj1 = parseInt(kraj1);
	pocetak2 = parseInt(pocetak2);
	kraj2 = parseInt(kraj2);
	
	return( (kraj1 > pocetak2 && kraj1 <= kraj2) || 
		    (pocetak1 >= pocetak2 && pocetak1 < kraj2) ||
		    (pocetak1 < pocetak2 && kraj1 > kraj2) ||
			(pocetak1 <= pocetak2 && kraj1 > kraj2) ||
			(pocetak1 < pocetak2 && kraj1 >= kraj2) );
}

const MAX_BROJ_SLIKA_KOJE_SE_UCITAVAJU = 3;

app.post('/slike', function(request, response)
{
    console.log("uspjesno usao u POST metodu za slike!!!");

    let tijeloPOSTrequesta = request.body;

    let sveSlikeIzFoldera = fs.readdirSync(__dirname+"/publicFajlovi/slike");
    
    console.log("sveSlikeIzFoldera:\n");
    console.log(sveSlikeIzFoldera);
    
    let noveNeprocitaneSlike = [];
    let sveUcitaneSlike = false;
    for(let i=0; i<sveSlikeIzFoldera.length; i++)
    {
        if(tijeloPOSTrequesta.includes(sveSlikeIzFoldera[i]) == false)
        {
            noveNeprocitaneSlike.push(sveSlikeIzFoldera[i]);

            if(noveNeprocitaneSlike.length == MAX_BROJ_SLIKA_KOJE_SE_UCITAVAJU)
            {
                if(sveSlikeIzFoldera.length-1 == i)
                    sveUcitaneSlike = true;

                break;
            }
        }
    }

    if(noveNeprocitaneSlike.length < 3 || sveUcitaneSlike==true)
        noveNeprocitaneSlike.push("nema vise novih slika");
    
    response.json(noveNeprocitaneSlike);
});

app.get('/osoblje', function(request, response)
{
    console.log("USAO NA SERVERU U \"/osobe\" DIREKTORIJ");
    var dropdownOsoblje = "";
    
    setTimeout(function(){}, 500); //zaustavi izvrsavanje pola sekunde 

    baza.osoblje.findAll().then(function(results) 
    {
        response.json(results);
    });
});

app.get('/svaZauzeca', function(request, response)
{
    //https://lorenstewart.me/2016/09/12/sequelize-table-associations-joins/

    console.log("USAO U \"/svaZauzeca\"");

    let sveRezervacije = {};
    sveRezervacije.vanredna = [];
    sveRezervacije.periodicna = [];

    console.log("0");
    baza.rezervacija.findAll({
        include:
        [
            {
                model: baza.sala,
                as: "rezervacijaSala"
            },
            {
                model: baza.osoblje,
                as: "rezervacijaOsoblje"
            },
            {
                model: baza.termin,
                as: "rezervacijaTermin"
            },
        ]
    }).then(function(sveRezervacijeIzBaze){
        console.log("1");
        sveRezervacijeIzBaze.forEach(jednaRezervacijaIzBaze =>
            {
                let nekaRezervacija = {};
                //isti nazivi se koriste u JSON objektu kojeg konstrusisemo
                nekaRezervacija.predavac = jednaRezervacijaIzBaze.rezervacijaOsoblje.ime
                    + " " + jednaRezervacijaIzBaze.rezervacijaOsoblje.prezime;
                //"naziv" je ustavri naziv sale
                nekaRezervacija.naziv = jednaRezervacijaIzBaze.rezervacijaSala.naziv;

                //Neophodno izvrsiti formatiranje vremena, jer se tip DateTime u bazu spasava u 
                // formatu HH:MM:SS, a prilikom upisa u "kalendar.js" se ocekuje string formata HH::MM
                let vrijemeHHMM = jednaRezervacijaIzBaze.rezervacijaTermin.pocetak.split(':');
                nekaRezervacija.pocetak = vrijemeHHMM[0] + ":" + vrijemeHHMM[1];
                vrijemeHHMM = jednaRezervacijaIzBaze.rezervacijaTermin.kraj.split(':');
                nekaRezervacija.kraj = vrijemeHHMM[0] + ":" + vrijemeHHMM[1]; 

                if(jednaRezervacijaIzBaze.rezervacijaTermin.redovni == false)
                {
                    nekaRezervacija.datum = jednaRezervacijaIzBaze.rezervacijaTermin.datum;

                    sveRezervacije.vanredna.push(nekaRezervacija);
                }
                else 
                {
                    nekaRezervacija.dan = jednaRezervacijaIzBaze.rezervacijaTermin.dan;
                    nekaRezervacija.semestar = jednaRezervacijaIzBaze.rezervacijaTermin.semestar;
                    
                    sveRezervacije.periodicna.push(nekaRezervacija);
                }
            });
            console.log("2");
            response.json(sveRezervacije);
        });
});

app.get('/sveSale', function(request, response)
{
    //https://lorenstewart.me/2016/09/12/sequelize-table-associations-joins/

    console.log("USAO U \"/sveSale\"");

    let sveSale = [];
    baza.sala.findAll({
        include:
        [
            {
                model: baza.osoblje,
                as: "salaOsoblje"
            }
        ]
    }).then(function(sveSaleIzBaze){
        sveSaleIzBaze.forEach(jednaSalaIzBaze =>
            {
                let nekaSala = {};

                nekaSala.naziv = jednaSalaIzBaze.naziv;
                nekaSala.zaduzenaOsoba = jednaSalaIzBaze.salaOsoblje.id;

                sveSale.push(nekaSala);
            });

            response.json(sveSale);
        });
});

module.exports = app;
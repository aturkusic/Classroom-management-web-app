Pozivi.dajSvoOsobljeIzBaze();
Pozivi.dajSveSaleIzBaze();
Pozivi.zadatak1();

var nizDanaUSedmici = ["pon", "uto", "sri", "čet", "pet", "sub", "ned"];
var nizMjeseciuGodini = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar",
                                 "Oktobar", "Novembar", "Decembar"];

//event.targer moze biti bilo koji dio HTMLa koji je ugnjezden unutar diva da klasom ".kalendarTabela"
$(".kalendarTabela").click(function(event) 
{   
    //moraju biti unutar event listenera, jer je prilikom svakog klika na neki elemnt potrebno ocitati kakve 
    //su vrijednosti upisne u poljima iznad kalendara 
    let listaZaOdabirSale = document.getElementById("listaSalaSForme");
    let pocetakVrijemeSForme = document.getElementById("pocetakVrijemeSForme");
    let krajVrijemeSForme = document.getElementById("krajVrijemeSForme");
    let rezervacijaPeriodicnaSForme = document.getElementById("rezervacijaPeriodicna");
    let listaZaOdabirPredavacaSForme = document.getElementById("listaOsoblje");

    //provjerava da li je checkbox cekiran
    let daLiJePeriodicna;
    if(rezervacijaPeriodicnaSForme.checked == true)
    daLiJePeriodicna = "DA";
    else
    daLiJePeriodicna = "NE";
                                 
    let tekstKojiGovoriKojiJeMjesec = document.querySelector(".nazivMjeseca").textContent;
    let kojiRedniBrojMjesecaJePrikazanPrilikomKlika;

    for(let i =0; i<nizMjeseciuGodini.length; i++)
    {
        if(tekstKojiGovoriKojiJeMjesec.includes(nizMjeseciuGodini[i]))
        {
            kojiRedniBrojMjesecaJePrikazanPrilikomKlika = i;
            
            //da bi dobili u stirngu smao ime mjeseca izgubivsi dio "(2020. godine)"
            tekstKojiGovoriKojiJeMjesec = nizMjeseciuGodini[i];
            break;
        }
    }
    
    if(pocetakVrijemeSForme == null || krajVrijemeSForme == null || pocetakVrijemeSForme.value == "" || krajVrijemeSForme.value == "")
    {
        alert("Da bi mogli izvrsiti neku rezrvaciju morate popuniti podatke o sali, periodicnosti," 
            +"pocetnom i krajnjem vremenu prije odabira zeljenog/ih datuma!");
    }
    else if(daLiJeVrijemePocetkaPrijeVremenaKraja(pocetakVrijemeSForme, krajVrijemeSForme)==false)
    {
        alert("Da bi mogli izvrsiti neku rezrvaciju morate unijeti takvu vrijednost da je vrijeme pocetka"
            +" prije vremena kraja");
    }
    else if( $(event.target).hasClass("prviDioCelije") || $(event.target).hasClass("drugiDioCelijeSlobodna") 
    || $(event.target).hasClass("drugiDioCelijeZauzeta"))
    {
        //"event.target.closest("selektor")" - dobavlja prvi parent element kliknutog elementa koji
        // zadovoljava selektor: https://api.jquery.com/closest/
        let parentElementCijelaCelija = event.target.closest(".celijaTabele");
        //console.log("kliknut unutrasnji dio celije koja je dan u tabeli:\n"+listaZaOdabirSale.);
        console.log(parentElementCijelaCelija);

        let daLiJeKlinuoDa = confirm("Da li zelite rezervisati termin:\n"+"sala: "+listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value
            +" periodicna: "+daLiJePeriodicna+" pocetak: "+pocetakVrijemeSForme.value+" kraj: "+krajVrijemeSForme.value);

        let brojOdabranogDanaUMjesecu = parentElementCijelaCelija.querySelector(".prviDioCelije").textContent;

        if(daLiJeKlinuoDa)
        akcijaAkoJePotvrdioRezervaciju(listaZaOdabirSale, pocetakVrijemeSForme, krajVrijemeSForme, 
            rezervacijaPeriodicnaSForme, kojiRedniBrojMjesecaJePrikazanPrilikomKlika, 
            brojOdabranogDanaUMjesecu, listaZaOdabirPredavacaSForme);
    }
    else if ($(event.target).hasClass("celijaTabele") && $(event.target).hasClass("nazivDana")==false)
    {
        let childElementPrviDioCelije = event.target.querySelector(".prviDioCelije");
        console.log("kliknut vanjski dio celije koja je dan u tabeli:\n");
        console.log(childElementPrviDioCelije);

        let daLiJeKlinuoDa = confirm("Da li zelite rezervisati termi:\n"+"sala: "+listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value
            +" periodicna: "+daLiJePeriodicna+" pocetak: "+pocetakVrijemeSForme.value+" kraj: "+krajVrijemeSForme.value);

        if(daLiJeKlinuoDa)
        akcijaAkoJePotvrdioRezervaciju(listaZaOdabirSale, pocetakVrijemeSForme, krajVrijemeSForme, 
            rezervacijaPeriodicnaSForme, kojiRedniBrojMjesecaJePrikazanPrilikomKlika, 
            childElementPrviDioCelije.textContent, listaZaOdabirPredavacaSForme);
    }

});

function akcijaAkoJePotvrdioRezervaciju(listaZaOdabirSale, pocetakVrijemeSForme, krajVrijemeSForme, 
    rezervacijaPeriodicnaSForme, kojiRedniBrojMjesecaJePrikazanPrilikomKlika, 
    brojOdabranogDanaUMjesecu, listaZaOdabirPredavacaSForme)
{
    let kliknutiDatum =  dajDatumUFormatDDMMYYYY(kojiRedniBrojMjesecaJePrikazanPrilikomKlika, 
        brojOdabranogDanaUMjesecu);

    if(rezervacijaPeriodicnaSForme.checked == true)
    {
        let danUSedmici = new Date( (new Date()).getFullYear(), kojiRedniBrojMjesecaJePrikazanPrilikomKlika, 
            brojOdabranogDanaUMjesecu).getDay();

        if(danUSedmici!=0)
            danUSedmici = danUSedmici - 1;
        else
            danUSedmici = 6;

        if(daLiOdabraniMjesecOdgovovaraNekomSemestru(kojiRedniBrojMjesecaJePrikazanPrilikomKlika)==false)
        {
            alert("Ne mozete napraviti periodicnu rezervaciju u mjesecima koji ne pripadaju ni zimskom"
                +", ni ljetnom semestru");
        }
        else
        {
            let semestarKojemOdgovaraMjesec = 
                dajSemestarKojemOdgovaraMjesec(kojiRedniBrojMjesecaJePrikazanPrilikomKlika);

            Pozivi.zadatak2periodicna(danUSedmici,semestarKojemOdgovaraMjesec,
                pocetakVrijemeSForme.value, krajVrijemeSForme.value, 
                listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value, 
                listaZaOdabirPredavacaSForme.options[listaZaOdabirPredavacaSForme.selectedIndex].value, 
                kliknutiDatum, kojiRedniBrojMjesecaJePrikazanPrilikomKlika,);
        }
    }
    else
    {
        Pozivi.zadatak2vanredna(kliknutiDatum, pocetakVrijemeSForme.value, krajVrijemeSForme.value, 
            listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value,
            listaZaOdabirPredavacaSForme.options[listaZaOdabirPredavacaSForme.selectedIndex].value);
    }    
}

function dajSemestarKojemOdgovaraMjesec(mjesec)
{
    /*
    OVAKO BILO ZA SPIRALU 3
    if( (mjesec>=1 && mjesec<=5) )
        return "ljetni";
    else if( (mjesec==0) || (mjesec>=9 && mjesec<=11))
        return "zimski";
    else
        return "mjesec ne odgovara niti jednom semestru";
    */
    
    if( (mjesec>=1 && mjesec<=5) )
        return 1; //simbolizira ljetni semestar
    else if( (mjesec==0) || (mjesec>=9 && mjesec<=11))
        return 0; //simpbolizira zismki semestar
    else
        return "mjesec ne odgovara niti jednom semestru";
}

function daLiOdabraniMjesecOdgovovaraNekomSemestru(mjesec)
{
    if( (mjesec>=0 && mjesec<=5) || (mjesec>=9 && mjesec<=11) )
        return true;
    else
        return false;
}

function dajDatumUFormatDDMMYYYY(kojiRedniBrojMjesecaJePrikazanPrilikomKlika, kojiDanaJeKliknut)
{
    let tekstMjesec;
    if(kojiRedniBrojMjesecaJePrikazanPrilikomKlika+1<10)
        tekstMjesec = "0"+(kojiRedniBrojMjesecaJePrikazanPrilikomKlika+1);
    else
        tekstMjesec = kojiRedniBrojMjesecaJePrikazanPrilikomKlika+1;
                
    let tekstDan;
    if(kojiDanaJeKliknut<10)
        tekstDan = "0"+kojiDanaJeKliknut;
    else
        tekstDan = kojiDanaJeKliknut;

    return tekstDan+"."+tekstMjesec+"."+(new Date()).getFullYear();
}

function daLiJeVrijemePocetkaPrijeVremenaKraja(pocetakVrijemeSForme, krajVrijemeSForme)
{
    let pocetnoVrijemeUMinutama = pocetakVrijemeSForme.value.split(":")[0]*60 + pocetakVrijemeSForme.value.split(":")[1];		
	let krajnjeVrijemeUMinutama = krajVrijemeSForme.value.split(":")[0]*60 +krajVrijemeSForme.value.split(":")[1];
	
	pocetnoVrijemeUMinutama = parseInt(pocetnoVrijemeUMinutama);
	krajnjeVrijemeUMinutama = parseInt(krajnjeVrijemeUMinutama);
	
	if(pocetnoVrijemeUMinutama >= krajnjeVrijemeUMinutama)
		return false;
	
	return true;
}
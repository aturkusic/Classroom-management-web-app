//ovo je modul koji sluzi za Ajax pozive 
var Pozivi = (function()
{
    // 1. DA BI OVA SKRIPTA RADILA, U HTML DOKUMENT MORAMO DODATI <script> TAG (na dno body-ja, standardno) !!     
    // 2. S OBZIROM DA UZ POMOĆ JQUery-JA POZIVAMO AJAX FUNCKIJE, POTREBNO JE OVU BIBLIOTEKU (JQuery) U HTMLU
    // https://www.digitalocean.com/community/tutorials/an-introduction-to-jquery
    // 3. AKO TI IZBACUJE GRESKU "RefernceError: $ not found..." TO ZNACI DA JQuery BIBLIOTEKA NIJE UKLJUCENA PRIJE PRVOG
    // KORISTENJA NJENIH FUNKCIJA, STO SE MOZE DESITI KADA: NIJE IZVRSEN KORAK2 OPISAN IZNAD, AKO SE KORISTI CDM ZA UKLJUCIVANJE
    // JQuery-JA ONDA DA NEMA NETA, DA JE U HTML POVEZANA SKRIPTA GDJE SE KORISTI JQuery, PRIJE SCRIPT TAGA SAME BIBLIOTEKE,
    // KADA BI SE RECIMO POKRENUO OVAJ FAJL, A NE index.js, JER SE OND ANE BI NI POKRENUO HTML FAJL...

    //The document "ready" event signals that the DOM of the page is now ready (jer se ova skripta mora vezati za neki html dokument), 
    //so you can manipulate it without worrying that parts of the DOM has not yet been created. The document "ready" event fires 
    //before all images etc. are loaded, but after the whole DOM itself is ready.
    /*Inside the function passed to the ready() method, you can execute all the jQuery and JavaScript code
    you need, in order to initialize / enhance the HTML elements in your page. You will see many examples of
    this, in the following pages.*/
    /*vise o "ReferenceError: $ is not defined" na: https://thisinterestsme.com/uncaught-referenceerror/ */
    //$(document).ready(function() {})- metoda koja se poziva prilikom ucitavanja stranice     

    function zadatak1Impl()
    {
        //vise o parametrima na: https://api.jquery.com/jquery.ajax/
        $.ajax(
            {
                /*Specifies the type of request. (GET or POST) */
                type:'GET',
                /*A Boolean value indicating whether the request should be handled asynchronous or not. Default is true*/ 
                async:true,
                /*A Boolean value indicating whether the browser should cache the requested pages. Default is true*/ 
                cache:true,
                /*The data type expected of the server response.*/
                /*If json is specified, the response is parsed using jQuery.parseJSON before being passed, as an object, to the success handler.
                The parsed JSON object is made available through the responseJSON property of the jqXHR object. */
                dataType: "json",
                /*Specifies the URL to send the request to. Default is the current page*/
                url:'../svaZauzeca',
                /*Type: Function( Anything data, String textStatus, jqXHR jqXHR )
                A function to be called if the request succeeds. The function gets passed three arguments: The data returned from the server,
                formatted according to the dataType parameter or the dataFilter callback function, if specified; a string describing the status; 
                and the jqXHR (in jQuery 1.4.x, XMLHttpRequest) object. */
                success: function(data)
                {
                    //console.log("ovo je 'data' koja je vracena u successu:\n "+JSON.stringify(data)+"\n");  
                    //console.log(typeof data);

                    var nizPeriodicnih =  data['periodicna'];
                    var nizVanrednih =  data['vanredna'];

                    console.log(nizPeriodicnih);
                    console.log(nizVanrednih);

                    Kalendar.ucitajPodatke(nizPeriodicnih, nizVanrednih);
                },
                error: function(jqxhr, status, exception) 
                {
                        alert('Desila se greska prilikom slanja GET requesta za dobavljanje svih zauzeca iz baze:', exception);
                        console.log(exception);
                }
            });
    }

    //----------------------------2 zadatak--------------------------------------------
    let kalendarIzHTMLa = document.getElementById("kalendar");

    function zadatak2ImplPeriodicnaZauzeca(danParametar, semestarParametar, pocetakParametar, krajParametar, 
        nazivParametar, imeIPrezimePredavaca, kliknutiDatum, mjesecPrikazanPrilikomKlika)
    {
        let preklapaSeZeljenaRezervacija = false;

        $.ajax(
            {
                type:'GET',
                //jer se treba ovaj request izvrsiti da bi se postavila varijabla "preklapaSeZeljenaRezervacija", na 
                //osnovu koje odredjuejmo da li trebamo raditi post request, ili ne
                async:false,
                cache:true,
                //The content type used when sending data to the server. Default is: "application/x-www-form-urlencoded"
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                url:'../svaZauzeca',
                success: function(data)
                { 
                    let nizPeriodicnih =  data['periodicna'];

                    for(let i=0; i<nizPeriodicnih.length; i++)
                    {
                        //ispitujes da li postoji u fajlu da se preklapa
                        if(nizPeriodicnih[i].dan == danParametar && nizPeriodicnih[i].semestar == semestarParametar 
                            && Kalendar.daLiSePreklapajuDvaIntervala(pocetakParametar, krajParametar, nizPeriodicnih[i].pocetak, 
                                nizPeriodicnih[i].kraj) && nizPeriodicnih[i].naziv == nazivParametar)
                        {
                            preklapaSeZeljenaRezervacija = true;

                            Kalendar.ucitajPodatke(data['periodicna'], data['vanredna']);
                            Kalendar.obojiZauzeca(kalendarIzHTMLa, mjesecPrikazanPrilikomKlika, nazivParametar, 
                                pocetakParametar, krajParametar);

                            alert("Nije moguce rezervisati salu "+nazivParametar+" sa navedenim datumom "
                                +kliknutiDatum+" i termin od "+pocetakParametar+" do "+krajParametar
                                +" zbog preklapanja sa terminom od "+nizPeriodicnih[i].predavac+"!");

                            break;
                        }
                    }

                    let nizVanrednih = data['vanredna'];

                    for(let i=0; i<nizVanrednih.length; i++)
                    {
                        //parseInt(object, radix)
                        let danVanrednogDatuma = parseInt(nizVanrednih[i].datum.split('.')[0], 10);
                        let mjesecVanrednogDatuma = parseInt(nizVanrednih[i].datum.split('.')[1], 10) -1 ;
                        let godinaVanrednogDatuma = parseInt(nizVanrednih[i].datum.split('.')[2], 10);

                        let danUSedmici = new Date(godinaVanrednogDatuma, mjesecVanrednogDatuma, 
                            danVanrednogDatuma).getDay();

                        if(danUSedmici != 0)
                            danUSedmici = danUSedmici - 1;
                        else
                            danUSedmici = 6;

                        let mjesecKliknutogDatuma = parseInt(kliknutiDatum.split('.')[1], 10) - 1;
                        let mjesecTrenutnogVanrednogZauzeca = parseInt(nizVanrednih[i].datum.split('.')[1], 10) - 1;

                        let jeLiMjesecOdabranogDatumaUIstomSemestruKaoVanrednoZauzece = false;
                        if( ( (mjesecKliknutogDatuma>=9 && mjesecKliknutogDatuma<=11) || 
                            mjesecKliknutogDatuma==0) && 
                            ( (mjesecTrenutnogVanrednogZauzeca>=9 && mjesecTrenutnogVanrednogZauzeca<=11) || 
                            mjesecTrenutnogVanrednogZauzeca==0) )
                        {
                            jeLiMjesecOdabranogDatumaUIstomSemestruKaoVanrednoZauzece = true;
                        }        
                        else if( (mjesecKliknutogDatuma>=1 && mjesecKliknutogDatuma<=5) &&
                                (mjesecTrenutnogVanrednogZauzeca>=1 && mjesecTrenutnogVanrednogZauzeca<=5) )
                        {
                            jeLiMjesecOdabranogDatumaUIstomSemestruKaoVanrednoZauzece = true;
                        }            
                        
                        //ispitujes da li postoji u fajlu da se preklapa
                        if(danUSedmici == danParametar && 
                            Kalendar.daLiSePreklapajuDvaIntervala(pocetakParametar, krajParametar, nizVanrednih[i].pocetak, 
                                nizVanrednih[i].kraj) 
                            && nizVanrednih[i].naziv == nazivParametar
                            && jeLiMjesecOdabranogDatumaUIstomSemestruKaoVanrednoZauzece == true)
                        {
                            preklapaSeZeljenaRezervacija = true;

                            Kalendar.ucitajPodatke(data['periodicna'], data['vanredna']);
                            Kalendar.obojiZauzeca(kalendarIzHTMLa, mjesecPrikazanPrilikomKlika, nazivParametar, 
                                pocetakParametar, krajParametar);

                            alert("Nije moguce rezervisati salu "+nazivParametar+" sa navedenim datumom "
                                +kliknutiDatum+" i termin od "+pocetakParametar+" do "+krajParametar
                                +" zbog preklapanja sa terminom od "+nizVanrednih[i].predavac+"!");
                            break;
                        }
                    }

                },
                error: function(jqxhr, status, exception) 
                {
                    alert('Desila se greska prilikom slanja GET requesta za dobavljanje svih zauzeca u \"zadatak2ImplPeriodicnaZauzeca\":', exception);
                }
            });

        if(preklapaSeZeljenaRezervacija == false)
        {
            let kljucVrijednostParovi = {dan: Number(danParametar), semestar: semestarParametar, pocetak: pocetakParametar, kraj: krajParametar, 
                naziv: nazivParametar, predavac: imeIPrezimePredavaca, kliknutiDatum: kliknutiDatum};
            $.ajax(
                {
                    type:'POST',
                    async:false,
                    //"data" - Specifies data to be sent to the server
                    data: kljucVrijednostParovi,
                    cache:true,
                    dataType: "json",
                    url:'../dodajZauzece',
                    success: function(data)
                    {
                       if(data['poruka'])
                       {
                           alert(data['poruka']);
                       }
                       else
                       {
                            console.log("uspjesno ste izvrsili POST request na zauzeca.json PERIODICNOG zauzeca");
                            console.log(data);

                            Kalendar.ucitajPodatke(data['periodicna'], data['vanredna']);
                            //metodi "obojiZauzeca" se prosljedjuje mjesec u rasponu od 0 - 11
                            Kalendar.obojiZauzeca(kalendarIzHTMLa, mjesecPrikazanPrilikomKlika, nazivParametar, 
                                pocetakParametar, krajParametar);
                       }
                    },
                    error: function(jqxhr, status, exception) 
                    {
                        alert('Desila se greska prilikom slanja POST requesta za dodavnje vanrednog zauzeca u bazu u zadatku'+
                            +'\"zadatak2vanredna:\"\n', exception);
                        console.log(exception);
                    }
                });
        }
    }

    function zadatak2ImplVanrednaZauzeca(datumParametar, pocetakParametar, krajParametar,
         nazivParametar, imeIPrezimePredavaca)
    {
        let preklapaSeZeljenaRezervacija = false;

        $.ajax(
            {
                type:'GET',
                //jer se treba ovaj request izvrsiti da bi se postavila varijabla "preklapaSeZeljenaRezervacija", na 
                //osnovu koje odredjuejmo da li trebamo raditi post request, ili ne
                async:false,
                cache:true,
                //The content type used when sending data to the server. Default is: "application/x-www-form-urlencoded"
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                url:'../svaZauzeca',
                success: function(data)
                {
                    //"JSON.stringify(objekt)" funckija pretvara objekt u string koji je json formata
                    
                    var nizVanrednih =  data['vanredna'];

                    for(let i=0; i<nizVanrednih.length; i++)
                    {
                        //ispitujes da li postoji u fajlu da se preklapa
                        if(nizVanrednih[i].datum == datumParametar 
                            && Kalendar.daLiSePreklapajuDvaIntervala(pocetakParametar, krajParametar, nizVanrednih[i].pocetak, 
                                nizVanrednih[i].kraj) && nizVanrednih[i].naziv == nazivParametar)
                        {
                            preklapaSeZeljenaRezervacija = true;

                            Kalendar.ucitajPodatke(data['periodicna'], data['vanredna']);
                            Kalendar.obojiZauzeca(kalendarIzHTMLa, datumParametar.split('.')[1]-1, nazivParametar, 
                                pocetakParametar, krajParametar);
                        
                            alert("Nije moguce rezervisati salu "+nazivParametar+" sa navedenim datumom "+datumParametar
                                +" i termin od "+pocetakParametar+" do "+krajParametar
                                +" zbog preklapanja sa terminom od "+nizVanrednih[i].predavac+"!");
                            break;
                        }
                    }

                    let nizPeriodicnih =  data['periodicna'];

                    for(let i=0; i<nizPeriodicnih.length; i++)
                    {
                        let danProsljedjenogDatuma = parseInt(datumParametar.split('.')[0], 10);
                        let mjesecProsljedjenogDatuma = parseInt(datumParametar.split('.')[1], 10) - 1;
                        let godinaProsljedjenogDatuma = parseInt(datumParametar.split('.')[2], 10);
    
                        let danUSedmiciIzvadjenIzDatuma = new Date(godinaProsljedjenogDatuma, mjesecProsljedjenogDatuma, 
                            danProsljedjenogDatuma).getDay();

                        if(danUSedmiciIzvadjenIzDatuma != 0)
                            danUSedmiciIzvadjenIzDatuma = danUSedmiciIzvadjenIzDatuma - 1;
                        else
                            danUSedmiciIzvadjenIzDatuma = 6;

                        let jeLiMjesecVanredneRezervacijeUSemestruPeriodicneRezervacije = false;

                        if( ( (mjesecProsljedjenogDatuma>=9 && mjesecProsljedjenogDatuma<=11) || 
                            mjesecProsljedjenogDatuma==0) && 
                            (nizPeriodicnih[i].semestar == "zimski" || nizPeriodicnih[i].semestar == 0) )
                                jeLiMjesecVanredneRezervacijeUSemestruPeriodicneRezervacije = true;
                        else if( (mjesecProsljedjenogDatuma>=1 && mjesecProsljedjenogDatuma<=5) &&
                            (nizPeriodicnih[i].semestar == "ljetni"|| nizPeriodicnih[i].semestar == 1) )
                                jeLiMjesecVanredneRezervacijeUSemestruPeriodicneRezervacije = true;

                        //ispitujes da li postoji u fajlu da se preklapa
                        if(nizPeriodicnih[i].dan == danUSedmiciIzvadjenIzDatuma 
                            && jeLiMjesecVanredneRezervacijeUSemestruPeriodicneRezervacije
                            && Kalendar.daLiSePreklapajuDvaIntervala(pocetakParametar, krajParametar, nizPeriodicnih[i].pocetak, 
                                nizPeriodicnih[i].kraj) && nizPeriodicnih[i].naziv == nazivParametar)
                        {
                            preklapaSeZeljenaRezervacija = true;

                            Kalendar.ucitajPodatke(data['periodicna'], data['vanredna']);
                            Kalendar.obojiZauzeca(kalendarIzHTMLa, datumParametar.split('.')[1]-1, nazivParametar, 
                                pocetakParametar, krajParametar);

                            alert("Nije moguce rezervisati salu "+nazivParametar+" sa navedenim datumom "
                                +datumParametar+" i termin od "+pocetakParametar+" do "+krajParametar
                                +" zbog preklapanja sa terminom od "+nizVanrednih[i].predavac+"!");
                            break;
                        }
                    }

                },
                error: function(jqxhr, status, exception) 
                {
                    alert('Desila se greska prilikom slanja GET requesta za dobavljanje svih zauzeca iz baze u \"zadatak2periodicna:\"', exception);
                }
            });

        if(preklapaSeZeljenaRezervacija == false)
        {
            let kljucVrijednostParovi = {datum: datumParametar, pocetak: pocetakParametar, kraj: krajParametar, 
                naziv: nazivParametar, predavac: imeIPrezimePredavaca};
            $.ajax(
                {
                    type:'POST',
                    async:false,
                    //"data" - Specifies data to be sent to the server
                    data: kljucVrijednostParovi,
                    cache:true,
                    dataType: "json",
                    url:'../dodajZauzece',
                    success: function(data)
                    {
                       if(data['poruka'])
                       {
                            alert(data['poruka']);
                       }
                       else
                       {
                            console.log("uspjesno ste izvrsili POST request na zauzeca.json VANREDNOG zauzeca");
                            console.log(data);

                            Kalendar.ucitajPodatke(data['periodicna'], data['vanredna']);
                            Kalendar.obojiZauzeca(kalendarIzHTMLa, datumParametar.split('.')[1]-1, nazivParametar, 
                                pocetakParametar, krajParametar);
                       }
                    },
                    error: function(jqxhr, status, exception) 
                    {
                        alert('Desila se greska prilikom slanja POST requesta za dobavljanje vanrednog zauzeca u \"zadatak2periodicna:\"\n', exception);
                        console.log(exception);
                    }
                });
        }
    }

    let nizUcitanihSlika = [];
    var ajax = new XMLHttpRequest();
    var brojTrenutnoPrikazaneTrojkeSlika = 0;
    var brojacUcitanihTrojkiSlika = 0;
    var ucitaneSveSlike = false;
    var dugmeSljedeci;
    var dugmePrethodni;

    function zadatak3SljedeciImpl()
    {
        /*
        console.log("usao u Pozivi.js, prije ajaxa!!");
        let kljucVrijednostParovi = {nizVecProcitanihSlika: nizUcitanihSlika};

        let kljucVrijednostParovi2 = {broj: "broj"};

        let nizUcitanihSlikaUOvomResponesu = [];

        //vise o parametrima na: https://api.jquery.com/jquery.ajax/
        $.ajax(
        {
            type:'POST',
            async:true,
            data: kljucVrijednostParovi2,
            cache: true,
            dataType: "json",
            url:'/publicFajlovi/slike/slika1.jpg',
            success: function(data)
            {
                nizUcitanihSlikaUOvomResponesu = data;
                console.log("USPJESNO DOBAVLJENA SLIKA, data:\n");
                console.log(data);

                let innerText = "";
                for(let i=0; i<nizUcitanihSlikaUOvomResponesu.length; i++)
                {
                    nizUcitanihSlika.push(nizUcitanihSlikaUOvomResponesu[i]);
                    innerText = innerText + "<div class=\"celijaGrida\">"
                                +"<img class=\"slikaDresa\" src=\""+nizUcitanihSlikaUOvomResponesu[i]+"\" alt=\"igrac MUFC-a\">"
                                +"</div>";
                }
                
                let dioStraniceKojiCuvaSlike = document.getElementById("triSlike");
                dioStraniceKojiCuvaSlike.innerHTML = innerText;
                
            },
            error: function(jqxhr, status, exception) 
            {
                alert('Desila se greska prilikom slanja GET requesta za dobavljanje slike u zadatak3:', exception);
                console.log(exception);
                console.log(status);
                console.log(jqxhr);
            }
        });*/

        if(ucitaneSveSlike == true && brojTrenutnoPrikazaneTrojkeSlika == brojacUcitanihTrojkiSlika)
        {
            promijeniStanjeDugmadi(true);
        }
        else if( brojTrenutnoPrikazaneTrojkeSlika != brojacUcitanihTrojkiSlika)
        {
            let kopijaBrTrenutneTrojke = 3*brojTrenutnoPrikazaneTrojkeSlika;

            let innerText= "<div class=\"celijaGrida\">"
                        +"<img class=\"slikaDresa\" src=/slike/"+nizUcitanihSlika[kopijaBrTrenutneTrojke]+" alt=\"igrac MUFC-a\">"
                        +"</div>";

            if(nizUcitanihSlika.length > kopijaBrTrenutneTrojke+1)
            innerText += "<div class=\"celijaGrida\">"
                        +"<img class=\"slikaDresa\" src=/slike/"+nizUcitanihSlika[kopijaBrTrenutneTrojke+1]+" alt=\"igrac MUFC-a\">"
                        +"</div>"
            if(nizUcitanihSlika.length > kopijaBrTrenutneTrojke+2)
            innerText +="<div class=\"celijaGrida\">"
                        +"<img class=\"slikaDresa\" src=/slike/"+nizUcitanihSlika[kopijaBrTrenutneTrojke+2]+" alt=\"igrac MUFC-a\">"
                        +"</div>";        

            let dioStraniceKojiCuvaSlike = document.getElementById("triSlike");
            dioStraniceKojiCuvaSlike.innerHTML = innerText;
                    
            brojTrenutnoPrikazaneTrojkeSlika++;
                    
            if(ucitaneSveSlike == true && brojTrenutnoPrikazaneTrojkeSlika == brojacUcitanihTrojkiSlika)
                promijeniStanjeDugmadi(true);
            else
                promijeniStanjeDugmadi(false);
        }
        else
        {
            ajax.onreadystatechange = function()
            {       
                // "readyState == 4" znaci da je zavrsen zahtijev
                if(ajax.readyState == 4 && ajax.status == 200)
                {
                    let nizUcitanihSlikaUOvomResponesu = JSON.parse(ajax.responseText);

                    let innerText = "";

                    for(let i=0; i<nizUcitanihSlikaUOvomResponesu.length; i++)
                    {
                        if(nizUcitanihSlikaUOvomResponesu[i].includes("nema vise novih slika") && ucitaneSveSlike == false)
                        {
                            ucitaneSveSlike = true;
                            break;
                        }

                        nizUcitanihSlika.push(nizUcitanihSlikaUOvomResponesu[i]);
                        innerText = innerText + "<div class=\"celijaGrida\">"
                            +"<img class=\"slikaDresa\" src=/slike/"+nizUcitanihSlikaUOvomResponesu[i]+" alt=\"igrac MUFC-a\">"
                            +"</div>";
                    }

                    let dioStraniceKojiCuvaSlike = document.getElementById("triSlike");
                    dioStraniceKojiCuvaSlike.innerHTML = innerText;
                
                    brojacUcitanihTrojkiSlika++;
                    brojTrenutnoPrikazaneTrojkeSlika++;

                    if(ucitaneSveSlike == false)
                        promijeniStanjeDugmadi(false);
                    else
                        promijeniStanjeDugmadi(true);
                
                }
                else if(ajax.readyState == 4 && ajax.status == 404)
                {
                    alert("Greska, neppoznat URL!");
                }
        }

            ajax.open("POST", "../slike", true)
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(nizUcitanihSlika));
        }
    }

    function zadatak3PrethodniImpl()
    {
        let nizTrenutnoPrikazanihSlika = document.getElementsByClassName("slikaDresa");

        if(nizTrenutnoPrikazanihSlika.length+3 <= nizUcitanihSlika.length)
        {
            //console.log("nizUcitanihSlika u PRETHODNA");
            //console.log(nizUcitanihSlika);
            
            let kopijaBrTrenutneTrojke = 3*brojTrenutnoPrikazaneTrojkeSlika;
            if(brojTrenutnoPrikazaneTrojkeSlika != 1)
                kopijaBrTrenutneTrojke -= 3;

            innerText = "<div class=\"celijaGrida\">"
                +"<img class=\"slikaDresa\" src=/slike/"+nizUcitanihSlika[kopijaBrTrenutneTrojke-3]+" alt=\"igrac MUFC-a\">"
                +"</div>"
                +"<div class=\"celijaGrida\">"
                +"<img class=\"slikaDresa\" src=/slike/"+nizUcitanihSlika[kopijaBrTrenutneTrojke-2]+" alt=\"igrac MUFC-a\">"
                +"</div>"
                +"<div class=\"celijaGrida\">"
                +"<img class=\"slikaDresa\" src=/slike/"+nizUcitanihSlika[kopijaBrTrenutneTrojke-1]+" alt=\"igrac MUFC-a\">"
                +"</div>";

            let dioStraniceKojiCuvaSlike = document.getElementById("triSlike");
                dioStraniceKojiCuvaSlike.innerHTML = innerText;

            brojTrenutnoPrikazaneTrojkeSlika--;
            promijeniStanjeDugmadi();
        }
    }
    
    function promijeniStanjeDugmadi(gasiSljedeciDugme)
    {
        dugmeSljedeci = document.getElementById("dugmeSljedeci");
        dugmePrethodni = document.getElementById("dugmePrethodni");
        
        if(brojTrenutnoPrikazaneTrojkeSlika == 1)
            dugmePrethodni.disabled = true;
        else 
            dugmePrethodni.disabled = false;
        
        if(gasiSljedeciDugme == true)
            dugmeSljedeci.disabled = true;
        else 
            dugmeSljedeci.disabled = false;
    }

    function dajSvoOsoblje()
    {
        //vise o parametrima na: https://api.jquery.com/jquery.ajax/
        $.ajax(
            {
                /*Specifies the type of request. (GET or POST) */
                type:'GET',
                /*A Boolean value indicating whether the request should be handled asynchronous or not. Default is true*/ 
                async:true,
                /*A Boolean value indicating whether the browser should cache the requested pages. Default is true*/ 
                cache:false,
                /*The data type expected of the server response.*/
                /*If json is specified, the response is parsed using jQuery.parseJSON before being passed, as an object, to the success handler.
                The parsed JSON object is made available through the responseJSON property of the jqXHR object. */
                dataType: "json",
                /*Specifies the URL to send the request to. Default is the current page*/
                url:'../osoblje',
                /*Type: Function( Anything data, String textStatus, jqXHR jqXHR )
                A function to be called if the request succeeds. The function gets passed three arguments: The data returned from the server,
                formatted according to the dataType parameter or the dataFilter callback function, if specified; a string describing the status; 
                and the jqXHR (in jQuery 1.4.x, XMLHttpRequest) object. */
                success: function(data)
                {
                    let innerText = "";
                    for(let i=0; i<data.length; i++)
                    {
                        innerText += " <option value=\"" + data[i].ime + " " + data[i].prezime + "\">"
                        + data[i].ime + " " + data[i].prezime+"</option> ";
                    }

                    let dropdaunElement = document.getElementById("listaOsoblje");
                    dropdaunElement.innerHTML = innerText;
                },
                error: function(jqxhr, status, exception) 
                {
                        alert('Desila se greska prilikom slanja GET requesta za dobavljanje sviju iz osoblja: ', exception);
                        console.log(exception);
                }
            });
    }

    function dajSveSale()
    {
        //vise o parametrima na: https://api.jquery.com/jquery.ajax/
        $.ajax(
            {
                type:'GET',
                async:true,
                cache:false,
                dataType: "json",
                url:'../sveSale',
                success: function(data)
                {
                    let innerText = "";
                    for(let i=0; i<data.length; i++)
                    {
                        innerText += " <option value=\"" + data[i].naziv + "\">"
                            + data[i].naziv + "</option> ";
                    }

                    let dropdaunElementSale = document.getElementById("listaSalaSForme");
                    dropdaunElementSale.innerHTML = innerText;
                },
                error: function(jqxhr, status, exception) 
                {
                        alert('Desila se greska prilikom slanja GET requesta za dobavljanje svih sala: ', exception);
                        console.log(exception);
                }
            });
    }

    var brojac = 0;
    function dajSvoOsobljeIOdrediImajuLiTrenutnoRezervaciju()
    {
        $.ajax(
            {
                type:'GET',
                async:true,
                cache:true,
                dataType: "json",
                url:'../svaZauzeca',
                success: function(data1)
                {
                    $.ajax(
                        {
                            type:'GET',
                            async:true,
                            cache:false,
                            dataType: "json",
                            url:'../osoblje',
                            success: function(data2)
                            {
                                console.log("POZVALO SE "+brojac);
                                brojac++;

                                let paroviOsobljeSala = [];
                                
                                let innerText = "<table id=\"tabelaOsobljeZauzeca\" class=\"tabelaOsobljeZauzeca\">"
                                                + " <tr> "
                                                    + " <td class=\"naslovKolone\">clan osoblja</td> " 
                                                    + " <td class=\"naslovKolone\">trenutna sala</td> " 
                                                + " </tr> "; 

                                let trenutniDatumIVrijeme = new Date();
                                let dd = trenutniDatumIVrijeme.getDate();
                                if(parseInt(dd, 10) < 10)
                                    dd = "0" + dd;
                                let mm = trenutniDatumIVrijeme.getMonth() + 1; //January is 0!
                                if(parseInt(mm, 10) < 10)
                                    mm = "0" + mm;
                                let yyyy = trenutniDatumIVrijeme.getFullYear();
                                let datumFormataDDMMYYY = dd+"."+mm+"."+yyyy;

                                let trenutniSati = trenutniDatumIVrijeme.getHours();
                                let trenutneMinute = trenutniDatumIVrijeme.getMinutes();
                                if(parseInt(trenutniSati, 10) < 10)
                                    trenutniSati = "0" + trenutniSati;
                                if(parseInt(trenutneMinute, 10) < 10)
                                    trenutneMinute = "0" + trenutneMinute;
                                let trenutnoVrijeme = trenutniSati+":"+trenutneMinute;

                                let trenutnoVrijemePlusMinut = "";
                                if(parseInt(trenutneMinute, 10)+1 >= 60)
                                {
                                    trenutneMinute = "00";

                                    if(parseInt(trenutniSati, 10)+1 >= 24)
                                    {
                                        trenutniSati = "00";
                                    }
                                    else
                                    {
                                        trenutniSati = (parseInt(trenutniSati, 10)+1).toString();
                                    }
                                }
                                else
                                {
                                    trenutneMinute = (parseInt(trenutneMinute, 10)+1).toString();
                                }

                                if(parseInt(trenutniSati, 10) < 10)
                                    trenutniSati = "0" + trenutniSati;

                                if(parseInt(trenutneMinute, 10) < 10)
                                    trenutneMinute = "0" + trenutneMinute;

                                trenutnoVrijemePlusMinut = trenutniSati+":"+trenutneMinute;

                                for(let i=0; i<data2.length; i++)//osoblje je data2
                                {
                                    innerText += " <tr> "
                                                    + " <td>" + data2[i].ime + " " + data2[i].prezime +"</td> ";

                                    let posmatrniClanOsobljaUSali = "u kancelariji";
                                    let nizZauzeca = [];
                                    for(let j=0; j<data1['vanredna'].length; j++)//zauzeca je data1
                                    {
                                        let pocetak = data1['vanredna'][j].pocetak;
                                        let kraj = data1['vanredna'][j].kraj;
                                        let datum = data1['vanredna'][j].datum;
                                        
                                        if(daLiSePoklapajuIntervali(pocetak, kraj, 
                                            trenutnoVrijeme, trenutnoVrijemePlusMinut) == true
                                            && datum == datumFormataDDMMYYY 
                                            && data1['vanredna'][j].predavac == (data2[i].ime+" "+data2[i].prezime))
                                        {
                                            posmatrniClanOsobljaUSali = data1['vanredna'][j].naziv;
                                            nizZauzeca.push(data1['vanredna'][j].naziv);
                                        }
                                    }

                                    for(let j=0; j<data1['periodicna'].length; j++)
                                    {
                                        let pocetakTrenutnogZauzeca = data1['periodicna'][j].pocetak;
                                        let krajTrenutnogZauzeca = data1['periodicna'][j].kraj;
                                        let danTrenutnogZauzeca = data1['periodicna'][j].dan;
                                        let semestarTrenutnogZauzeca = data1['periodicna'][j].semestar;

                                        let trenutniDanUSedmici = trenutniDatumIVrijeme.getDay(); //od 0 do 6 vraca

                                        if(trenutniDanUSedmici!=0)
                                            trenutniDanUSedmici = trenutniDanUSedmici - 1;
                                        else
                                            trenutniDanUSedmici = 6;

                                        let trenutniMjesec = trenutniDatumIVrijeme.getMonth();
                                        let danasPripadaSemestru = "";
                                        
                                        if(trenutniMjesec>=1 && trenutniMjesec<=5)
                                            danasPripadaSemestru = 1;
                                        else if(trenutniMjesec==0 || (trenutniMjesec>=9 && trenutniMjesec<=11))
                                            danasPripadaSemestru = 0;

                                        if(daLiSePoklapajuIntervali(pocetakTrenutnogZauzeca, krajTrenutnogZauzeca, 
                                            trenutnoVrijeme, trenutnoVrijemePlusMinut) == true
                                            && trenutniDanUSedmici == danTrenutnogZauzeca
                                            && data1['periodicna'][j].predavac == (data2[i].ime+" "+data2[i].prezime)
                                            && semestarTrenutnogZauzeca == danasPripadaSemestru
                                            )
                                        {
                                            posmatrniClanOsobljaUSali = data1['periodicna'][j].naziv;
                                            nizZauzeca.push(data1['periodicna'][j].naziv);
                                        }
                                    }

                                    if(posmatrniClanOsobljaUSali != "u kancelariji")
                                    {
                                        innerText +=  " <td>"
                                        for(let i=0; i<nizZauzeca.length; i++)
                                        {
                                           innerText += nizZauzeca[i];
                                           
                                           if(i+1 != nizZauzeca.length)
                                           innerText += ", ";
                                        }

                                        innerText += "</td> "
                                            +" </tr> ";
                                    }
                                    else
                                    {
                                        innerText += " <td>"+posmatrniClanOsobljaUSali+"</td> "
                                            + " </tr> ";
                                    }
                                    
                                                    
                                }
                                innerText +=" </table> "
                                let divZaTabeluOsobljeSala = document.getElementById("sadrzavaTabeluOsobljeSala");

                                divZaTabeluOsobljeSala.innerHTML = innerText;
                            },
                            error: function(jqxhr, status, exception) 
                            {
                                alert('Desila se greska prilikom slanja GET requesta za dobavljanje sviju iz osoblja, iz baze (kroz server): ', exception);
                                console.log(exception);
                            }
                        });
                },
                error: function(jqxhr, status, exception) 
                {
                        alert('Desila se greska prilikom slanja GET requesta za dobavljanje svih zauzeca iz baze (kroz server):', exception);
                        console.log(exception);
                }
            });
    }
    
    function daLiSePoklapajuIntervali(pocetak1, kraj1, pocetak2, kraj2)
	{
		// II nacin (moglo se je sve prevesti i u minute):
		pocetak1 = pocetak1.split(":")[0]*60 + pocetak1.split(":")[1];
		kraj1 = kraj1.split(":")[0]*60 + kraj1.split(":")[1];
		pocetak2 = pocetak2.split(":")[0]*60 + pocetak2.split(":")[1];
		kraj2 = kraj2.split(":")[0]*60 + kraj2.split(":")[1];
		
		//uradjena konverzija iz stringa u int, jer je vremena poredio kao stringove
		pocetak1 = parseInt(pocetak1);
		kraj1 = parseInt(kraj1);
		pocetak2 = parseInt(pocetak2);
		kraj2 = parseInt(kraj2);
		
		return( (kraj1 > pocetak2 && kraj1 <= kraj2) || 
			    (pocetak1 >= pocetak2 && pocetak1 < kraj2) ||
			    (pocetak1 < pocetak2 && kraj1 > kraj2) ||
				(pocetak1 <= pocetak2 && kraj1 > kraj2) ||
				(pocetak1 < pocetak2 && kraj1 >= kraj2) );
				
		//s obzirom da su istom formatu vremena, sto je obaveno postavkom uciniti, stringovi ce se porediti kao stvarno vrijeme bez potrebe za 
		// pretvaranjem u minute - https://stackoverflow.com/questions/43733099/javascript-difference-between-two-time-strings/43733200
	}

    return {
		zadatak1: zadatak1Impl,
        zadatak2periodicna: zadatak2ImplPeriodicnaZauzeca,
        zadatak2vanredna: zadatak2ImplVanrednaZauzeca,
        zadatak3Sljedeci: zadatak3SljedeciImpl,
        zadatak3Prethodni: zadatak3PrethodniImpl,
        dajSvoOsobljeIzBaze: dajSvoOsoblje,
        dajSveSaleIzBaze: dajSveSale,
        dajSvoOsobljeIzBazeIOdrediImajuLiTrenutnoRezervaciju: dajSvoOsobljeIOdrediImajuLiTrenutnoRezervaciju   
	}

}());
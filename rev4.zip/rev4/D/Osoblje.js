const Sequelize = require('sequelize');

module.exports = function(sequelize, DataTypes)
{
/*Model predstavlja jednu tabelu u bazi, veze između modela su ujedno veze između tabela, a instanca jednog modela predstavlja red iz tabele. 
Model u sequelize-u definišemo sa "sequelize.define(‘ime modela’,{atributi},{opcije})". "ime modela" naziv koji će vrijediti za svaku instancu 
modela, ukoliko je naziv modela "user" tada sequelize kreira tebelu sa nazivom "users". */
const Osoblje = 
    sequelize.define('osoblje', {
    id: {
        type: Sequelize.INTEGER,
        field: 'id',
        autoIncrement: true,
        primaryKey: true
    },
    ime: {
        type: Sequelize.STRING,
        field: 'ime'
    },
    prezime: {
        type: Sequelize.STRING,
        field: 'prezime'
    },
    uloga: {
        type: Sequelize.STRING,
        field: 'uloga'
    }
 })

 return Osoblje;
};
const Sequelize = require('sequelize');

module.exports = function(sequelize, DataTypes)
{
/*Model predstavlja jednu tabelu u bazi, veze između modela su ujedno veze između tabela, a instanca jednog modela predstavlja red iz tabele. 
Model u sequelize-u definišemo sa "sequelize.define(‘ime modela’,{atributi},{opcije})"". "ime modela" naziv koji će vrijediti za svaku instancu 
modela, ukoliko je naziv modela "user", tada sequelize kreira tebelu sa nazivom "users". */
const Rezervacija =
    sequelize.define('rezervacija', {
    id: {
        type: Sequelize.INTEGER,
        field: 'id', 
        autoIncrement: true,
        primaryKey: true
    },
    termin: {
        type: Sequelize.INTEGER,
        field: 'termin',
        unique: true
    },
    sala: {
        type: Sequelize.INTEGER,
        field: 'sala'
    },
    osoba: {
        type: Sequelize.INTEGER,
        field: 'osoba'
    }
 })
 
 return Rezervacija;
};
const baza = require("./db.js");

function inicijalizacija()
{
    let rezervacijePromisi = [];
    let terminiPromisi = [];
    let osobljePromisi = [];
    let salePromisi = [];

    return new Promise(
        function(resolve, reject)
        {
            osobljePromisi.push(baza.osoblje.create( 
                {
                    ime: "Neko", 
                    prezime: "Nekic", 
                    uloga: "profesor"
                } 
                ));
            osobljePromisi.push(baza.osoblje.create(
                {
                    ime: "Drugi",
                    prezime: "Neko",
                    uloga: "asistent"
                }
            ));
            osobljePromisi.push(baza.osoblje.create(
                {
                    ime: "Test",
                    prezime: "Test",
                    uloga: "asistent"
                }
            ));
            Promise.all(osobljePromisi).then(function(osobe)
                {
                    //ova konstrukcija vraca niz rezultata. U ovom slucaju cevratiti niz od jednog el, tj. el. koji imaju ime "Neko"
                    let neko = osobe.filter(function(jedanRezultat)
                        {
                            return jedanRezultat.ime === "Neko";
                        })[0];

                    let drugi = osobe.filter(function(jedanRezultat)
                        {
                            return jedanRezultat.ime === "Drugi";
                        })[0];
                    
                    let test = osobe.filter(function(jedanRezultat)
                        {
                            return jedanRezultat.ime === "Test";
                        })[0];

                    //---------------------------------------------    
                    salePromisi.push(baza.sala.create(
                    {
                        naziv: "1-11",
                        zaduzenaOsoba: neko.id
                    }
                    ));
                    salePromisi.push(baza.sala.create(
                         {
                            naziv: "1-15",
                            zaduzenaOsoba: drugi.id
                        }
                    ));

                    Promise.all(salePromisi).then(function(sale)
                        {
                            terminiPromisi.push(baza.termin.create(
                                {
                                    redovni: false,
                                    dan: null,
                                    datum: "01.01.2020",
                                    semestar: null,
                                    pocetak: "12:00",
                                    kraj: "13:00"
                                }
                                ));
                            terminiPromisi.push(baza.termin.create(
                                {
                                    redovni: true,
                                    dan: 0,
                                    datum: null,
                                    semestar: 0,
                                    pocetak: "13:00",
                                    kraj: "14:00"
                                }
                                ));

                            Promise.all(terminiPromisi).then(function(termin)
                                {
                                    let sala1_11 = sale.filter(function(jedanRezultat)
                                    {
                                        return jedanRezultat.naziv === "1-11";
                                    })[0];

                                    let termin12_00 = termin.filter(function(jedanRezultat)
                                    {
                                        return jedanRezultat.pocetak === "12:00";
                                    })[0];

                                    let termin13_00 = termin.filter(function(jedanRezultat)
                                    {
                                        return jedanRezultat.pocetak === "13:00";
                                    })[0];

                                    rezervacijePromisi.push(baza.rezervacija.create(
                                        {
                                            termin: termin12_00.id,
                                            sala: sala1_11.id,
                                            osoba: neko.id
                                        }
                                        ));
                                    rezervacijePromisi.push(baza.rezervacija.create(
                                        {
                                            termin: termin13_00.id,
                                            sala: sala1_11.id,
                                            osoba: test.id
                                        }
                                        ));

                                    Promise.all(rezervacijePromisi).then(function(rezervacije)
                                        {
                                            resolve(rezervacije);
                                        }).catch(function(err){console.log("ZADNJI PROMIS GRESKA -"+err);});

                                }).catch(function(error){console.log("TRECI PROMIS GRESKA -"+ error)});//kraj terminPromise
    
                        }).catch(function(error){console.log("DRUGI PROMIS GRESKA -"+ error)});//kraj salePromisi
                   
                }).catch(function(error){console.log("PRVI PROMIS GRESKA -"+ error)});//kraj osobljePromisi
        }
    );
}

function inicijalizacijaNaVrijeme(callback) 
{
    console.log("prije poziva sinhronizacije");
    baza.sequelize.sync({force:true}).then(function(){
        console.log("prije poziva inicijalizacije");
        inicijalizacija().then(
            function()
            {
                console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka, PRIJE POZIVA callback-a");
                callback();
            }).catch(function(error){console.log("NIJE USPJELA INICIJALIZACIJA - "+error)});
    }).catch(function(error){console.log("NIJE USPJELA SINHRONIZACIJA - "+error)});
}

baza.inicijalizacijaNaVrijeme = inicijalizacijaNaVrijeme;

module.exports = baza;
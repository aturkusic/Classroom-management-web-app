const db = require('./db.js')

db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        process.exit();
    });
});

function inicijalizacija()
{
    var rezervacijePromisi = [];
    var terminiPromisi = [];
    var osobljePromisi = [];
    var salePromisi = [];

    return new Promise(
        function(resolve, reject)
        {
            osobljePromisi.push(db.osoblje.create( 
                {
                    ime: "Neko", 
                    prezime: "Nekić", 
                    uloga: "profesor"
                } 
                ));
            osobljePromisi.push(db.osoblje.create(
                {
                    ime: "Drugi",
                    prezime: "Neko",
                    uloga: "asistent"
                }
            ));
            osobljePromisi.push(db.osoblje.create
                {
                    ime: "Test",
                    prezime: "Test",
                    uloga: "asistent"
                });
            //---------------------------------------------    
            salePromisi.push(db.sale.create(
                {
                    naziv: "1-11",
                    zaduzenaOsoba: 1
                }
            ));
            salePromisi.push(db.sale.create(
                {
                    naziv: "1-15",
                    zaduzenaOsoba: 2
                }
            ));
            //---------------------------------------------
            terminiPromisi.push(db.termini.create(
                {
                    redovni: false,
                    dan: null,
                    datum: "01.01.2020",
                    semestar: null,
                    pocetak: "12:00",
                    kraj: "13:00"
                }
            ));
            terminiPromisi.push(db.termini.create(
                {
                    redovni: true,
                    dan: 0,
                    datum: null,
                    semestar: "zimski",
                    pocetak: "13:00",
                    kraj: "14:00"
                }
            ));
            //---------------------------------------------
            rezervacijePromisi.push(db.rezervacije(
                {
                    termin: 1,
                    sala: 1,
                    osoba: 1
                }
            ));
            rezervacijePromisi.push(db.rezervacije(
                {
                    termin: 2,
                    sala: 1,
                    osoba: 3
                }
            ));     
        }
    );
}
    
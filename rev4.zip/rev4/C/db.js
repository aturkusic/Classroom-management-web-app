const Sequelize = require("sequelize");
const sequelize = new Sequelize("DBWT19","root","root",{host: "127.0.0.1",dialect:"mysql",logging:false});
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(__dirname+'/models/Osoblje.js');
db.termin = sequelize.import(__dirname+'/models/Termin.js');
db.sala= sequelize.import(__dirname+'/models/Sala.js');
db.rezervacija = sequelize.import(__dirname+'/models/Rezervacija.js');

//relacije
// Veza 1-n osoblje rezervacija
db.osoblje.hasMany(db.rezervacija, { foreignKey: "osoba", as: "rezervacije"});

// Veza 1-1 rezervacija termin
db.rezervacija.belongsTo(db.termin,{as:'t', foreignKey:{ name: 'termin', unique: true}});

// Veza n-1 rezervacija sala
db.sala.hasMany(db.rezervacija, { foreignKey: "sala", as: "rezervacije"});

// Veza 1-1 sala osoblje
db.sala.belongsTo(db.osoblje,{as:'zo', foreignKey:'zaduzenaOsoba'});

module.exports=db;
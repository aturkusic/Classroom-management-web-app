document.addEventListener("DOMContentLoaded", function() {
    Pozivi.ucitajOsobe();
    Pozivi.ucitajZauzeca();
});

setInterval(Pozivi.ucitajZauzeca, 30000);
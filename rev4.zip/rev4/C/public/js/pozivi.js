var slike = [];
var trenutnaPrva=0;
var trenutnaZadnja=2;
var osobe=[];
var periodicna=[];
var vanredna=[];
var brojPeriodicnihZauzeca=-1;
var brojVanrednihZauzeca=-1;

let Pozivi = (function(){
    function ucitajZauzecaImpl() {
        try{
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function()
            {
                if (ajax.readyState === XMLHttpRequest.DONE) {
                    if (ajax.status === 200) {
                        Kalendar.ucitajPodatke(JSON.parse(ajax.responseText).periodicna, JSON.parse(ajax.responseText).vanredna);
                        periodicna=JSON.parse(ajax.responseText).periodicna;
                        vanredna=JSON.parse(ajax.responseText).vanredna;
                        pozovi();
                    }
                }
            };
            ajax.open("GET", "http://localhost:8080/rezervacije", true);
            ajax.send();
        }
        catch(error){
            console.log(error);
        }
    }

    function rezervisiVanredniTerminImpl(sala, pocetak, kraj, datum, predavac) {
        try{
            var ajax = new XMLHttpRequest();
            ajax.open("POST", "http://localhost:8080/rezervisiVanredno", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    Kalendar.ucitajPodatke(JSON.parse(ajax.responseText).periodicna, JSON.parse(ajax.responseText).vanredna);
                    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, sala, pocetak, kraj, predavac);
                    periodicna=JSON.parse(ajax.responseText).periodicna;
                    vanredna=JSON.parse(ajax.responseText).vanredna;
                }
                else if (ajax.status === 500) {
                    alert(ajax.responseText);
                }
            };
            var data = JSON.stringify({"datum": datum,"pocetak": pocetak,"kraj": kraj,"naziv": sala,"predavac": predavac});

            ajax.send(data);
        }
        catch(error){
            console.log(error);
        }
    }

    function rezervisiPeriodicneTermineImpl(sala, pocetak, kraj, datum, predavac, semestar, dan) {
        try{
            var ajax = new XMLHttpRequest();
            ajax.open("POST", "http://localhost:8080/rezervisiPeriodicne", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    Kalendar.ucitajPodatke(JSON.parse(ajax.responseText).periodicna, JSON.parse(ajax.responseText).vanredna);
                    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, sala, pocetak, kraj, predavac);
                    periodicna=JSON.parse(ajax.responseText).periodicna;
                    vanredna=JSON.parse(ajax.responseText).vanredna;
                }
                else if (ajax.status === 500) {
                    alert(ajax.responseText);
                }
            };
            var data = JSON.stringify({"dan": dan,"semestar": semestar,"pocetak": pocetak,"kraj": kraj,"naziv": sala,"predavac": predavac});

            ajax.send(data);
        }
        catch(error){
            console.log(error);
        }
    }

    function ucitajSlikeImpl(prva, zadnja) {
        try{
            var ajax = new XMLHttpRequest();
            ajax.open("POST", "http://localhost:8080/slike", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    var slikeJSON = JSON.parse(ajax.responseText);
                    slikeJSON = JSON.parse(slikeJSON);
                    if(slikeJSON.url.length%3==0) {
                        slike.push(slikeJSON.url[0]);
                        slike.push(slikeJSON.url[1]);
                        slike.push(slikeJSON.url[2]);
                        document.getElementById("slika1").src = slike[slike.length-3];
                        document.getElementById("slika2").src = slike[slike.length-2];
                        document.getElementById("slika3").src = slike[slike.length-1];
                        if(slikeJSON.zadnja)
                            document.getElementById("sljedeciPocetna").disabled = true;
                    }
                    else if(slikeJSON.url.length%3==1){
                        slike.push(slikeJSON.url[0]);
                        document.getElementById("slika1").src = slike[slike.length-1];
                        document.getElementById("slika2").style.visibility = "hidden";
                        document.getElementById("slika2").src = "";
                        document.getElementById("slika3").style.visibility = "hidden";
                        document.getElementById("slika3").src = "";
                        document.getElementById("sljedeciPocetna").disabled = true;
                    }
                    else {
                        slike.push(slikeJSON.url[0]);
                        slike.push(slikeJSON.url[1]);
                        document.getElementById("slika1").src = slike[slike.length-2];
                        document.getElementById("slika2").src = slike[slike.length-1];
                        document.getElementById("slika3").style.visibility = "hidden";
                        document.getElementById("slika3").src = "";
                        document.getElementById("sljedeciPocetna").disabled = true;
                    }
                }
                else if (ajax.status === 500) {
                    alert(JSON.parse(ajax.responseText).greska);
                }
            };
            var data = JSON.stringify({"prva": prva,"zadnja": zadnja});

            ajax.send(data);
        }
        catch(error){
            console.log(error);
        }
    }

    function ucitajOsobeImpl() {
        try{
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function()
            {
                if (ajax.readyState === XMLHttpRequest.DONE) {
                    if (ajax.status === 200) {
                        var dat = JSON.parse(ajax.responseText);
                        osobe = dat;
                        var x = document.getElementById("osoblje");
                        var option1 = document.createElement("option");
                        option1.text = " ";
                        x.add(option1);
                        for(var i=0; i<dat.length; i++) {
                            var option2 = document.createElement("option");
                            option2.text = dat[i].ime + " " + dat[i].prezime;
                            x.add(option2);
                        }
                    }
                }
            };
            ajax.open("GET", "http://localhost:8080/osoblje", true);
            ajax.send();
        }
        catch(error){
            console.log(error);
        }
    }

    function ucitajSaleImpl() {
        try{
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function()
            {
                if (ajax.readyState === XMLHttpRequest.DONE) {
                    if (ajax.status === 200) {
                        var dat = JSON.parse(ajax.responseText);
                        var x = document.getElementById("listaSala");
                        var option1 = document.createElement("option");
                        option1.text = " ";
                        x.add(option1);
                        for(var i=0; i<dat.length; i++) {
                            var option2 = document.createElement("option");
                            option2.text = dat[i].naziv;
                            x.add(option2);
                        }
                    }
                }
            };
            ajax.open("GET", "http://localhost:8080/sale", true);
            ajax.send();
        }
        catch(error){
            console.log(error);
        }
    }

    function pozovi() {
        var danas = new Date();
        var dd = String(danas.getDate()).padStart(2, '0');
        var mm = String(danas.getMonth() + 1).padStart(2, '0');
        var yyyy = danas.getFullYear();
        var datum = dd + '.' + mm + "." + yyyy;
        var vrijeme = danas.getHours() + ":" + danas.getMinutes();
        var dan = danas.getDay();
        dan--;
        if(dan<0)
            dan=6;
        azurirajListu(vrijeme, datum, dan);
    }
    
    function azurirajListu(vrijeme, datum, dan) {
        if(brojPeriodicnihZauzeca!=periodicna.length || brojVanrednihZauzeca!=vanredna.length) {
            var lista=[];
            for(var k=0; k<osobe.length; k++)
                lista.push({'osoba': osobe[k].ime + " " + osobe[k].prezime, 'uloga' : osobe[k].uloga, 'sala' : 'u kancelariji'});
            for(var i=0; i<periodicna.length; i++) {
                if(dan==periodicna[i].dan && poklapanjeTermina(vrijeme.split(":")[0], vrijeme.split(":")[1], periodicna[i].pocetak.toString().split(":")[0],periodicna[i].pocetak.toString().split(":")[1],periodicna[i].kraj.toString().split(":")[0],periodicna[i].kraj.toString().split(":")[1])
                && periodicna[i].semestar==semestarUGodini(datum)){
                    for(var k=0; k<osobe.length; k++)
                        if((osobe[k].ime + " " + osobe[k].prezime)==periodicna[i].predavac)
                            lista[k].sala = periodicna[i].naziv;
                }
            }
            for(var i=0; i<vanredna.length; i++) {
                if(datum==vanredna[i].datum && poklapanjeTermina(vrijeme.split(":")[0], vrijeme.split(":")[1], vanredna[i].pocetak.toString().split(":")[0],vanredna[i].pocetak.toString().split(":")[1],vanredna[i].kraj.toString().split(":")[0],vanredna[i].kraj.toString().split(":")[1])){
                    for(var k=0; k<osobe.length; k++)
                        if((osobe[k].ime + " " + osobe[k].prezime)==vanredna[i].predavac)
                            lista[k].sala = vanredna[i].naziv;
                }
            }
    
            var elementiTabele='<tr><td>' + 'Ime i prezime' + '</td><td>' + 'Uloga' + '</td><td>' + 'Sala' + '</td></tr>';
            for(var i = 0; i < lista.length; i++)
                elementiTabele+= '<tr><td>' + lista[i].osoba + '</td><td>' + lista[i].uloga + '</td><td>' + lista[i].sala + '</td></tr>';
    
            var listaOsoba = document.getElementById('listaOsoba');
            listaOsoba.innerHTML = elementiTabele;
            brojVanrednihZauzeca=vanredna.length;
            brojPeriodicnihZauzeca=periodicna.length;
        }
    }
    
    function poklapanjeTermina(h, m, h1, m1, h2, m2) {
        return (parseInt(h1) < parseInt(h) || parseInt(h1) == parseInt(h) && parseInt(m1) <= parseInt(m)) && (parseInt(h) < parseInt(h2) || parseInt(h) == parseInt(h2) && parseInt(m) <= parseInt(m2));
    }
    
    function semestarUGodini(datum){
        if(parseInt(datum.toString().split(".")[1])==1 || parseInt(datum.toString().split(".")[1])==10 || parseInt(datum.toString().split(".")[1])==11 || parseInt(datum.toString().split(".")[1])==12)
            return "zimski";
        else if(parseInt(datum.toString().split(".")[1])==2 || parseInt(datum.toString().split(".")[1])==3 || parseInt(datum.toString().split(".")[1])==4 || parseInt(datum.toString().split(".")[1])==5 || parseInt(datum.toString().split(".")[1])==6)
            return "ljetni";
        return "";
    }

    return {
        ucitajZauzeca : ucitajZauzecaImpl,
        rezervisiVanredniTermin : rezervisiVanredniTerminImpl,
        rezervisiPeriodicneTermine : rezervisiPeriodicneTermineImpl,
        ucitajSlike : ucitajSlikeImpl,
        ucitajOsobe : ucitajOsobeImpl,
        ucitajSale : ucitajSaleImpl
    }
}());
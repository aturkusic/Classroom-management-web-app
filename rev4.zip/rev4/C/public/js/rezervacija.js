var kalendarRef = document.getElementById("kalendar");
if (kalendarRef != null) {
    for (var i = 2; i < kalendarRef.rows.length; i++) {
        for (var j = 0; j < kalendarRef.rows[i].cells.length; j++)
        kalendarRef.rows[i].cells[j].onclick = function () {
            rezervacijaTermina(this);
        };
    }
}

function rezervacijaTermina(dan) {
    Pozivi.ucitajZauzeca();
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="" && trenutnaOsoba!="") {
        if(dan.innerHTML.length==36 && dan.innerHTML.substring(2,dan.innerHTML.length) != '<div class="zauzeta">&nbsp;</div>') {
            var r = confirm("Ako želite rezervisati termin pritisnite OK!");
            if (r == true) {
                var m = trenutniMjesec+1;
                var mjesec;
                if(m<10)
                    mjesec = "0" + m.toString();
                else
                    mjesec = m.toString();
                var dan = dan.innerHTML.substring(0,2);
                var godina = d.getFullYear();
                var datum = dan + "." + mjesec + "." + godina;
                var dpom = new Date(godina, trenutniMjesec, parseInt(dan), 1, 1, 1, 1);
                var danUSedmici = dpom.getDay();
                danUSedmici--;
                if(danUSedmici<0)
                    danUSedmici=6;
                var semestar="";
                if(mjeseci[trenutniMjesec]=="Januar" || mjeseci[trenutniMjesec]=="Oktobar" || mjeseci[trenutniMjesec]=="Novembar" || mjeseci[trenutniMjesec]=="Decembar")
                    semestar="zimski";
                else if(mjeseci[trenutniMjesec]=="Februar" || mjeseci[trenutniMjesec]=="Mart" || mjeseci[trenutniMjesec]=="April" || mjeseci[trenutniMjesec]=="Maj" || mjeseci[trenutniMjesec]=="Juni")
                    semestar="ljetni";
                if(document.getElementById("periodicna").checked && semestar!="")
                    Pozivi.rezervisiPeriodicneTermine(trenutnaSala, trenutniPocetak, trenutniKraj, datum, trenutnaOsoba, semestar,danUSedmici);
                else
                    Pozivi.rezervisiVanredniTermin(trenutnaSala, trenutniPocetak, trenutniKraj, datum, trenutnaOsoba);
            }
        }
        else if(dan.innerHTML.length==35 && dan.innerHTML.substring(1,dan.innerHTML.length) != '<div class="zauzeta">&nbsp;</div>' && dan.innerHTML.substring(1,2) == '<') {
            var r = confirm("Ako želite rezervisati termin pritisnite OK!");
            if (r == true) {
                var m = trenutniMjesec+1;
                var mjesec;
                if(m<10)
                    mjesec = "0" + m.toString();
                else
                    mjesec = m.toString();
                var dan = "0" + dan.innerHTML.substring(0,1);
                var godina = d.getFullYear();
                var datum = dan + "." + mjesec + "." + godina;
                var dpom = new Date(godina, trenutniMjesec, parseInt(dan), 1, 1, 1, 1);
                var danUSedmici = dpom.getDay();
                danUSedmici--;
                if(danUSedmici<0)
                    danUSedmici=6;
                var semestar="";
                if(mjeseci[trenutniMjesec]=="Januar" || mjeseci[trenutniMjesec]=="Oktobar" || mjeseci[trenutniMjesec]=="Novembar" || mjeseci[trenutniMjesec]=="Decembar")
                    semestar="zimski";
                else if(mjeseci[trenutniMjesec]=="Februar" || mjeseci[trenutniMjesec]=="Mart" || mjeseci[trenutniMjesec]=="April" || mjeseci[trenutniMjesec]=="Maj" || mjeseci[trenutniMjesec]=="Juni")
                    semestar="ljetni";
                if(document.getElementById("periodicna").checked && semestar!="")
                    Pozivi.rezervisiPeriodicneTermine(trenutnaSala, trenutniPocetak, trenutniKraj, datum, trenutnaOsoba, semestar, danUSedmici);
                else
                    Pozivi.rezervisiVanredniTermin(trenutnaSala, trenutniPocetak, trenutniKraj, datum, trenutnaOsoba);
            }
        }
        else if(dan.innerHTML.substring(1,2) == '<'){
            var m = trenutniMjesec+1;
            var mjesec;
            if(m<10)
                mjesec = "0" + m.toString();
            else
                mjesec = m.toString();
            var dan = "0" + dan.innerHTML.substring(0,1);
            var godina = d.getFullYear();
            var datum = dan + "." + mjesec + "." + godina;
            var dpom = new Date(godina, trenutniMjesec, parseInt(dan), 1, 1, 1, 1);
            var danUSedmici = dpom.getDay();
            danUSedmici--;
            if(danUSedmici<0)
                danUSedmici=6;
            var semestar="";
            if(mjeseci[trenutniMjesec]=="Januar" || mjeseci[trenutniMjesec]=="Oktobar" || mjeseci[trenutniMjesec]=="Novembar" || mjeseci[trenutniMjesec]=="Decembar")
                semestar="zimski";
            else if(mjeseci[trenutniMjesec]=="Februar" || mjeseci[trenutniMjesec]=="Mart" || mjeseci[trenutniMjesec]=="April" || mjeseci[trenutniMjesec]=="Maj" || mjeseci[trenutniMjesec]=="Juni")
                semestar="ljetni";
            var imePrezime="";
            for(var i=0; i<periodicna.length; i++) {
                if(periodicna[i].dan==danUSedmici && periodicna[i].naziv==trenutnaSala && periodicna[i].semestar==semestar && 
                    poklapanjeTermina(parseInt(periodicna[i].pocetak.split(":")[0]),parseInt(periodicna[i].pocetak.split(":")[1]), parseInt(periodicna[i].kraj.split(":")[0]),parseInt(periodicna[i].kraj.split(":")[1]),parseInt(trenutniPocetak.split(":")[0]),parseInt(trenutniPocetak.split(":")[1]),parseInt(trenutniKraj.split(":")[0]),parseInt(trenutniKraj.split(":")[1]))){
                    imePrezime=periodicna[i].predavac;
                    break;
                }
            }
            for(var i=0; i<vanredna.length; i++) {
                if(vanredna[i].datum==datum && vanredna[i].naziv==trenutnaSala && 
                    poklapanjeTermina(parseInt(vanredna[i].pocetak.split(":")[0]),parseInt(vanredna[i].pocetak.split(":")[1]), parseInt(vanredna[i].kraj.split(":")[0]),parseInt(vanredna[i].kraj.split(":")[1]),parseInt(trenutniPocetak.split(":")[0]),parseInt(trenutniPocetak.split(":")[1]),parseInt(trenutniKraj.split(":")[0]),parseInt(trenutniKraj.split(":")[1]))){
                    imePrezime=vanredna[i].predavac;
                    break;
                }
            }
            for(var i=0; i<osobe.length; i++) {
                if(osobe[i].ime + " "+ osobe[i].prezime==imePrezime){
                    alert("Salu je rezervisao " + osobe[i].uloga + " " + osobe[i].prezime + " " + osobe[i].ime + ".");
                    break;
                }
            }
        }
        else {
            var m = trenutniMjesec+1;
            var mjesec;
            if(m<10)
                mjesec = "0" + m.toString();
            else
                mjesec = m.toString();
            var dan = dan.innerHTML.substring(0,2);
            var godina = d.getFullYear();
            var datum = dan + "." + mjesec + "." + godina;
            var dpom = new Date(godina, trenutniMjesec, parseInt(dan), 1, 1, 1, 1);
            var danUSedmici = dpom.getDay();
            danUSedmici--;
            if(danUSedmici<0)
                danUSedmici=6;
            var semestar="";
            if(mjeseci[trenutniMjesec]=="Januar" || mjeseci[trenutniMjesec]=="Oktobar" || mjeseci[trenutniMjesec]=="Novembar" || mjeseci[trenutniMjesec]=="Decembar")
                semestar="zimski";
            else if(mjeseci[trenutniMjesec]=="Februar" || mjeseci[trenutniMjesec]=="Mart" || mjeseci[trenutniMjesec]=="April" || mjeseci[trenutniMjesec]=="Maj" || mjeseci[trenutniMjesec]=="Juni")
                semestar="ljetni";
            var imePrezime="";
            for(var i=0; i<periodicna.length; i++) {
                if(periodicna[i].dan==danUSedmici && periodicna[i].naziv==trenutnaSala && periodicna[i].semestar==semestar && 
                    poklapanjeTermina(parseInt(periodicna[i].pocetak.split(":")[0]),parseInt(periodicna[i].pocetak.split(":")[1]), parseInt(periodicna[i].kraj.split(":")[0]),parseInt(periodicna[i].kraj.split(":")[1]),parseInt(trenutniPocetak.split(":")[0]),parseInt(trenutniPocetak.split(":")[1]),parseInt(trenutniKraj.split(":")[0]),parseInt(trenutniKraj.split(":")[1]))){
                    imePrezime=periodicna[i].predavac;
                    break;
                }
            }
            for(var i=0; i<vanredna.length; i++) {
                if(vanredna[i].datum==datum && vanredna[i].naziv==trenutnaSala && 
                    poklapanjeTermina(parseInt(vanredna[i].pocetak.split(":")[0]),parseInt(vanredna[i].pocetak.split(":")[1]), parseInt(vanredna[i].kraj.split(":")[0]),parseInt(vanredna[i].kraj.split(":")[1]),parseInt(trenutniPocetak.split(":")[0]),parseInt(trenutniPocetak.split(":")[1]),parseInt(trenutniKraj.split(":")[0]),parseInt(trenutniKraj.split(":")[1]))){
                    imePrezime=vanredna[i].predavac;
                    break;
                }
            }
            for(var i=0; i<osobe.length; i++) {
                if(osobe[i].ime + " "+ osobe[i].prezime==imePrezime){
                    alert("Salu je rezervisao " + osobe[i].uloga + " " + osobe[i].prezime + " " + osobe[i].ime + ".");
                    break;
                }
            }
        }
    }
    else if(dan.innerHTML.length!=0){
        alert("Nemoguće rezervisati termin, jer nisu sva polja ispravno unesena!");
    }
}

document.addEventListener("DOMContentLoaded", function() {
    Pozivi.ucitajSale();
    Pozivi.ucitajOsobe();
    Pozivi.ucitajZauzeca();
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
});

document.getElementById("prethodni").addEventListener("click", function(){
    if(trenutniMjesec==0)
        this.disabled = true;
    else {
        document.getElementById("sljedeci").disabled = false;
        trenutniMjesec--; 
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj, trenutnaOsoba);
    }
});
document.getElementById("sljedeci").addEventListener("click", function(){
    if(trenutniMjesec==11)
        this.disabled = true;
    else {
        document.getElementById("prethodni").disabled = false;
        trenutniMjesec++; 
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj, trenutnaOsoba);
    }
});
document.getElementById("listaSala").addEventListener("change", function(){
    trenutnaSala=this.value;
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="" && trenutnaOsoba!="")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj, trenutnaOsoba);
});
document.getElementById("osoblje").addEventListener("change", function(){
    trenutnaOsoba=this.value;
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="" && trenutnaOsoba!="")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj, trenutnaOsoba);
});
document.getElementById("pocetak").addEventListener("change", function(){
    var sati = this.value.split(":")[0];
    var minute = this.value.split(":")[1];
    trenutniPocetak = sati + ":" + minute;
    if(trenutniPocetak==":")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="" && trenutnaOsoba!="")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj, trenutnaOsoba);
});
document.getElementById("kraj").addEventListener("change", function(){
    var sati = this.value.split(":")[0];
    var minute = this.value.split(":")[1];
    trenutniKraj = sati + ":" + minute;
    if(trenutniKraj==":")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="" && trenutnaOsoba!="")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj, trenutnaOsoba);
});

function poklapanjeTermina(hp, mp, hk, mk, h1, m1, h2, m2) {
    if((h1+m1===h2+m2) || h1>h2 || (h1==h2 && m1>m2))
        return false;
    if(hk==h1 && mk==m1)
        return false;
    if(hp==h2 && mp==m2)
        return false;
    if(hp<=h1 && hk>=h2)
        return true;
    return (h1 < hp || h1 == hp && m1 <= mp) && (hp < h2 || hp == h2 && mp <= m2) || (h1 < hk || h1 == hk && m1 <= mk) && (hk < h2 || hk == h2 && mk <= m2);
}
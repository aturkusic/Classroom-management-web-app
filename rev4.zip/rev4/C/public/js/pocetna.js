document.addEventListener("DOMContentLoaded", function() {
    Pozivi.ucitajSlike(trenutnaPrva, trenutnaZadnja);
    document.getElementById("prethodniPocetna").disabled = true;
});

document.getElementById("prethodniPocetna").addEventListener("click", function(){
    var j=trenutnaPrva-3;
    for(var i=0; i<3; i++) {
        var slika = '';
        if(i==0) 
            slika='slika1';
        else if(i==1)
            slika='slika2';
        else
            slika='slika3';
        document.getElementById(slika).style.visibility = "visible";
        
        document.getElementById(slika).src = slike[j];
        j++;
    }
    trenutnaPrva-=3;
    trenutnaZadnja-=3;
    if(trenutnaPrva==0)
        document.getElementById("prethodniPocetna").disabled = true;
    document.getElementById("sljedeciPocetna").disabled = false;
});

document.getElementById("sljedeciPocetna").addEventListener("click", function(){
    trenutnaPrva+=3;
    trenutnaZadnja+=3;
    var j=trenutnaPrva;
    if(trenutnaZadnja+1-3==slike.length)
        Pozivi.ucitajSlike(trenutnaPrva, trenutnaZadnja);
    else{
        for(var i=0; i<3; i++) {
            var slika = '';
            if(i==0) 
                slika='slika1';
            else if(i==1)
                slika='slika2';
            else
                slika='slika3';
            document.getElementById(slika).style.visibility = "visible";
            
            document.getElementById(slika).src = slike[j];
            j++;
            if(trenutnaZadnja+1==slike.length)
                document.getElementById("sljedeciPocetna").disabled = true;
        }
    }
    
    if(slike.length%3!=0 && trenutnaZadnja>=slike.length) {
        document.getElementById("sljedeciPocetna").disabled = true;
        var brojSlika=slike.length%3;  
        if(brojSlika==1) {
            document.getElementById("slika1").src = slike[slike.length-1];
            document.getElementById("slika2").style.visibility = "hidden";
            document.getElementById("slika2").src = "";
            document.getElementById("slika3").style.visibility = "hidden";
            document.getElementById("slika3").src = "";
        }
        else if(brojSlika==2){
            document.getElementById("slika1").src = slike[slike.length-2];
            document.getElementById("slika2").src = slike[slike.length-1];
            document.getElementById("slika3").style.visibility = "hidden";
            document.getElementById("slika3").src = "";
        }
    }
    document.getElementById("prethodniPocetna").disabled = false;
});
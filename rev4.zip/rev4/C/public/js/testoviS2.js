var d = new Date();
var trenutniMjesec=d.getMonth();
var trenutnaGodina=d.getFullYear();

let assert = chai.assert;
describe('Kalendar', function() {
  describe('ucitajPodatke() i obojiZauzeca()', function() {
    it('Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([],[]); // ucitava se prilikom load, pa sam ovdje ponistio ucitane podatke
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec,"MA","12:00","13:00");
      let brojObojenihZauzeca=document.getElementById("kalendar").getElementsByClassName("zauzeta").length;
         
      assert.equal(brojObojenihZauzeca, 0,"Broj dana treba biti 0");
    });
    it('Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina: očekivano je da se dan oboji bez obzira što postoje duple vrijednosti', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([],[{datum: "13.12.2019",pocetak: "15:00",kraj: "16:30",naziv: "EE1",predavac: "Faris Kovačević"},{datum: "13.12.2019",pocetak: "14:00",kraj: "15:30",naziv: "EE1",predavac: "Nadja Kovačević"}]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 11,"EE1","14:30","16:00");
      let brojObojenihZauzeca=document.getElementById("kalendar").getElementsByClassName("zauzeta").length;
         
      assert.equal(brojObojenihZauzeca, 1,"Broj obojenih treba biti 1, jer su oba zauzeca vanredna");
    }); 
    it('Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([{dan: 0, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Irfan Prazina"}],[{datum: "13.12.2019",pocetak: "15:00",kraj: "16:30",naziv: "EE1",predavac: "Faris Kovačević"},{datum: "13.12.2019",pocetak: "14:00",kraj: "15:30",naziv: "EE1",predavac: "Nadja Kovačević"}]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 4,"VA2","12:00","13:30"); // pozivamo za mjesec maj koji se nalazi u ljetnom semestru
      let brojObojenihZauzeca=document.getElementById("kalendar").getElementsByClassName("zauzeta").length;
         
      assert.equal(brojObojenihZauzeca, 0,"Broj obojenih treba biti 0, jer maj nije u zimskom semestru");
    });
    it('Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano je da se ne oboji zauzeće', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([{dan: 0, semestar: "ljetni", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Irfan Prazina"}],
      [{datum: "13.12.2019",pocetak: "15:00",kraj: "16:30",naziv: "EE1",predavac: "Faris Kovačević"}]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 10,"EE1","15:00","16:30"); // pozivamo za mjesec novembar, a zauzece je u mjesecu decembru
      let brojObojenihZauzeca=document.getElementById("kalendar").getElementsByClassName("zauzeta").length;
         
      assert.equal(brojObojenihZauzeca, 0,"Broj obojenih treba biti 0, jer pozivamo za mjesec novembar, a zauzece je u mjesecu decembru");
    });
    it('Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi dani oboje', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([{dan: 0, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Irfan Prazina"},
      {dan: 1, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Faris"},
      {dan: 2, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Amira"},
      {dan: 3, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Hamed"},
      {dan: 4, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Željko"},
      {dan: 5, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Amela"},
      {dan: 6, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Dino"}],
      [{datum: "13.12.2019",pocetak: "15:00",kraj: "16:30",naziv: "EE1",predavac: "Faris Kovačević"}]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 10,"VA2","12:00","13:30"); // pozivamo za mjesec novembar, koji ima 30 dana
      let brojObojenihZauzeca=document.getElementById("kalendar").getElementsByClassName("zauzeta").length;
         
      assert.equal(brojObojenihZauzeca, 30,"Broj obojenih treba biti 30, jer pozivamo za mjesec novembar");
    });
    it('Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([{dan: 0, semestar: "ljetni", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Irfan Prazina"}],
      [{datum: "13.12.2019",pocetak: "15:00",kraj: "16:30",naziv: "EE1",predavac: "Faris Kovačević"}]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 11,"EE1","15:00","16:30");
      let divs = document.getElementById("kalendar").getElementsByTagName("div");
      let lokacija1=-1;// lokacija prvog i jedinog zauzeca u mjesecu,jer je vanredno
      for(var i=0; i<divs.length; i++)
       if(divs[i].className=="zauzeta")
        lokacija1=i;
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 11,"EE1","15:00","16:30");
      let lokacija2=0;// lokacija prvog i jedinog zauzeca u mjesecu,jer je vanredno
      for(var i=0; i<divs.length; i++)
        if(divs[i].className=="zauzeta")
        lokacija2=i;
         
      assert.equal(lokacija1, lokacija2,"Lokacije moraju biti iste, sto znaci da je boja zauzeca ista");
    });
    it('Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: očekivano da se zauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podaci', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([{dan: 0, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Irfan Prazina"}],[]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 11,"VA2","13:00","14:30");
      Kalendar.ucitajPodatke([],[{datum: "13.12.2019",pocetak: "15:00",kraj: "16:30",naziv: "EE1",predavac: "Faris Kovačević"}]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 11,"EE1","15:00","16:30");
      let brojObojenihZauzeca=document.getElementById("kalendar").getElementsByClassName("zauzeta").length;
         
      assert.equal(brojObojenihZauzeca, 1,"Broj obojenih treba biti 1, jer drugi poziv obojiZauzeca boji samo jedno vanredno zauzece");
    });
    it('Pozivanje obojiZauzece kada se termini poklapaju: očekivano je da se zauzeća oboje', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([{dan: 0, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Irfan Prazina"}],[{datum: "13.12.2019",pocetak: "15:00",kraj: "16:30",naziv: "EE1",predavac: "Faris Kovačević"},{datum: "13.12.2019",pocetak: "14:00",kraj: "15:30",naziv: "EE1",predavac: "Nadja Kovačević"}]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 11,"VA2","12:30","14:00"); // pozivamo za mjesec decembar. Termin 12:30-14:00 se preklapa sa 12:00-13:30
      let brojObojenihZauzeca=document.getElementById("kalendar").getElementsByClassName("zauzeta").length;
         
      assert.equal(brojObojenihZauzeca, 5,"Broj obojenih treba biti 5, jer decembar ima 5 ponedjeljaka");
    });
    it('Pozivanje obojiZauzece kada se termini poklapaju, ali sala ne: očekivano je da se zauzeće ne oboji', function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
      Kalendar.ucitajPodatke([{dan: 0, semestar: "zimski", pocetak: "12:00", kraj: "13:30", naziv: "VA2", predavac: "Irfan Prazina"}],[{datum: "13.12.2019",pocetak: "15:00",kraj: "16:30",naziv: "EE1",predavac: "Faris Kovačević"},{datum: "13.12.2019",pocetak: "14:00",kraj: "15:30",naziv: "EE1",predavac: "Nadja Kovačević"}]);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"), 11,"VA1","12:30","14:00"); // pozivamo za mjesec decembar. Termin 12:30-14:00 se preklapa sa 12:00-13:30, ali sale ne
      let brojObojenihZauzeca=document.getElementById("kalendar").getElementsByClassName("zauzeta").length;
         
      assert.equal(brojObojenihZauzeca, 0,"Broj obojenih treba biti 0, jer se sale ne poklapaju");
    });
  });
 describe('iscrtajKalendar()', function() {
  it('Očekivano je da iscrta mjesec juni koji ima 30 dana', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 5);
    let tds = document.getElementsByTagName("td");
    let brojDana=0;
    for(var i=0; i<tds.length; i++)
     if(tds[i].id=="brojDan")
       brojDana++;
       
    assert.equal(brojDana, 30,"Broj dana treba biti 30");
  }); 
  it('Očekivano je da iscrta mjesec oktobar koji ima 31 dan', function() {
     Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 9);
     let tds = document.getElementsByTagName("td");
     let brojDana=0;
     for(var i=0; i<tds.length; i++)
      if(tds[i].id=="brojDan")
        brojDana++;

     assert.equal(brojDana, 31,"Broj dana treba biti 31");
   });
   it('Očekivano je da iscrta trenutni mjesec čiji je prvi dan u petak', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    var datum = new Date(trenutnaGodina, trenutniMjesec, 1, 1, 1, 1, 1);
    var prviDan = datum.getDay();
    prviDan--;
    if(prviDan<0)
        prviDan=6; // Metoda getDay() dane počinje brojati od nedjelje do subote
    
    let tds = document.getElementsByTagName("td");
    var brojPrvogDana;
    for(var i=0; i<tds.length; i++) {
      if(tds[i].id=="brojDan"){
        brojPrvogDana=i;
        break; // dosli smo do prvog dana u mjesecu
      }
    }
    brojPrvogDana%=7; // 7 dana u sedmici
    assert.equal(prviDan, brojPrvogDana,"Prvi dan treba biti 4, jer je petak pod rednim brojem 4(pon=0,...)");
  });
  it('Očekivano je da iscrta trenutni mjesec čiji je zadnji dan u subotu', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    var daniUMjesecu = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] 
        if(((trenutnaGodina % 100==0) && (trenutnaGodina % 400==0)) || (trenutnaGodina % 4==0 ))
            daniUMjesecu[1]=29;
    var datum = new Date(trenutnaGodina, trenutniMjesec, daniUMjesecu[trenutniMjesec], 1, 1, 1, 1);
    var zadnjiDan = datum.getDay();
    zadnjiDan--;
    if(zadnjiDan<0)
        zadnjiDan=6; // Metoda getDay() dane počinje brojati od nedjelje do subote
    let tds = document.getElementsByTagName("td");
    var brojPrvogDana;
    var brojZadnjegDana;
    for(var i=0; i<tds.length; i++) {
      if(tds[i].id=="brojDan"){
        brojPrvogDana=i;
        break; // dosli smo do prvog dana u mjesecu
      }                                                                                                               // slobodanDan je id za one dane koji pripadaju prethodnom ili sljedecem mjesecu
    }
    if(tds[brojPrvogDana+daniUMjesecu[trenutniMjesec]-1].innerHTML.substring(0,2)==daniUMjesecu[trenutniMjesec].toString() && tds[brojPrvogDana+daniUMjesecu[trenutniMjesec]].id == "slobodanDan")
      brojZadnjegDana = (brojPrvogDana+daniUMjesecu[trenutniMjesec]-1)%7;

    assert.equal(zadnjiDan, brojZadnjegDana,"Zadnji dan treba biti 5, jer je subota pod rednim brojem 5(pon=0,...)");
  });
  it('Očekivano je da iscrta mjesec januar koji ima 31 dan(prvi dan utorak)', function() {
    var kalendarRef = document.getElementById("kalendar");
    Kalendar.iscrtajKalendar(kalendarRef, 0);
    let tds = kalendarRef.getElementsByTagName("td");
    let brojDana=0;
    for(var i=0; i<tds.length; i++)
     if(tds[i].id=="brojDan")
       brojDana++;
    var brojPrvogDana=-1;
    var prviDan=-1;
    if(brojDana==31) // Provjera da je broj dana tačan
    {
      var datum = new Date(trenutnaGodina, 0, 1, 1, 1, 1, 1); // Januar je pod rednim brojem 0
      prviDan = datum.getDay();
      prviDan--;
      if(prviDan<0)
          prviDan=6; // Metoda getDay() dane počinje brojati od nedjelje do subote
      
      let tds = document.getElementsByTagName("td");
      for(var i=0; i<tds.length; i++) {
        if(tds[i].id=="brojDan"){
          brojPrvogDana=i;
          break; // dosli smo do prvog dana u mjesecu
        }
      }
      brojPrvogDana%=7; // 7 dana u sedmici
    }
       
    assert.equal(prviDan, brojPrvogDana,"Prvi dan treba biti 1, jer je utorak pod rednim brojem 1(pon=0,...)");
  });
  it('Očekivano je da iscrta mjesec koji ima 6 sedmica(decembar-prvi dan u nedjelju)', function() {
    var kalendarRef = document.getElementById("kalendar");
    Kalendar.iscrtajKalendar(kalendarRef, 11);
    var brojPrvogDana=-1;
    var brojSedmica=1;
    var datum = new Date(trenutnaGodina, 11, 1, 1, 1, 1, 1); // Decembar je pod rednim brojem 11
    var prviDan = datum.getDay();
    prviDan--;
    if(prviDan<0)
        prviDan=6; // Metoda getDay() dane počinje brojati od nedjelje do subote
    
    let tds = document.getElementsByTagName("td");
    for(var i=0; i<tds.length; i++) {
      if(tds[i].id=="brojDan"){
        brojPrvogDana=i;
        break; // dosli smo do prvog dana u mjesecu
      }
    }
    brojPrvogDana%=7; // 7 dana u sedmici
    if(brojPrvogDana==prviDan){
      for(var i=0; i<tds.length; i++) {
        if(tds[i].innerHTML.length==36 && parseInt(tds[i].innerHTML.substring(0,2))%7==2)
          brojSedmica++;
        else if(tds[i].innerHTML.length==35 && parseInt(tds[i].innerHTML.substring(0,1))%7==2)
          brojSedmica++;
      }
    }
    assert.equal(brojSedmica, 6,"Prvi dan treba biti 6, jer je nedjelja pod rednim brojem 6(pon=0,...)");
  });
  it('Očekivano je da iscrta mjesec februar koji ima 28 dana', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 1);
    let tds = document.getElementsByTagName("td");
    let brojDana=0;
    for(var i=0; i<tds.length; i++)
     if(tds[i].id=="brojDan")
       brojDana++;

    assert.equal(brojDana, 28,"Broj dana treba biti 28");
  });
 });
});

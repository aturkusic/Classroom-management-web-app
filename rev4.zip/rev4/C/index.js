const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const path = require('path');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static('public'));

const db = require('./db.js');
db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){ console.log("Gotovo kreiranje tabela i ubacivanje početnih podataka!");});
});

// Zadatak 1
app.get('/osoblje', function (req, res) {
    db.osoblje.findAll().then(function (rez) {
        var niz = [];
        for (var i = 0; i < rez.length; i++) {
            var objekat = { ime: rez[i].ime, prezime: rez[i].prezime, uloga: rez[i].uloga };
            niz.push(objekat);
        }
        res.writeHead(200, { 'Content-Type': "application/json" });
        res.end(JSON.stringify(niz));
    });
});

app.get('/sale', function (req, res) {
    db.sala.findAll().then(function (rez) {
        var niz = [];
        for (var i = 0; i < rez.length; i++) {
            var objekat = { naziv: rez[i].naziv };
            niz.push(objekat);
        }
        res.writeHead(200, { 'Content-Type': "application/json" });
        res.end(JSON.stringify(niz));
    });
});

// Zadatak 2
app.get('/rezervacije', (req, res) => {
    db.rezervacija.findAll().then(function (rez) {
        let promises = [];
        for (r of rez) {
            promises.push(getSala(r.sala));
            promises.push(getOsoba(r.osoba));
            promises.push(getTermin(r.termin));
        }
        Promise.all(promises).then(function(results) {
            var p=[];
            var v=[];
            for (let i = 0; i < results.length; i += 3) {
                var sala = results[i];
                var predavac = results[i + 1];
                var termin = results[i + 2];
                if(termin.redovni && predavac!="" && sala!=""){
                    var o = {dan: termin.dan,semestar: termin.semestar,pocetak: termin.pocetak.toString().substring(0, 5),kraj: termin.kraj.toString().substring(0, 5),naziv: sala,predavac: predavac};
                    p.push(o);
                }
                else if(!termin.redovni && predavac!="" && sala!=""){
                    var o = {datum: termin.datum,pocetak: termin.pocetak.toString().substring(0, 5),kraj: termin.kraj.toString().substring(0, 5),naziv: sala,predavac: predavac};
                    v.push(o);
                }
            }
            var zauzeca = { periodicna: p, vanredna:v};
            return zauzeca;
        }).then(function(zauzeca) {
            res.writeHead(200, { 'Content-Type': "application/json" });
            res.end(JSON.stringify(zauzeca));
        }).catch(function(err) { console.log(err) });
    });
});

app.post('/rezervisiVanredno', (req, res) => {
    String.prototype.replaceAll = function(searchStr, replaceStr) {
        var str = this;
        if(str.indexOf(searchStr) === -1)
            return str;
        return (str.replace(searchStr, replaceStr)).replaceAll(searchStr, replaceStr);
    }
    
    db.rezervacija.findAll().then(function (rez) {
        let promises = [];
        for (r of rez) {
            promises.push(getSala(r.sala));
            promises.push(getOsoba(r.osoba));
            promises.push(getTermin(r.termin));
        }
        Promise.all(promises).then(function(results) {
            var p=[];
            var v=[];
            for (let i = 0; i < results.length; i += 3) {
                var sala = results[i];
                var predavac = results[i + 1];
                var termin = results[i + 2];
                if(termin.redovni && predavac!="" && sala!=""){
                    var o = {dan: termin.dan,semestar: termin.semestar,pocetak: termin.pocetak.toString().substring(0, 5),kraj: termin.kraj.toString().substring(0, 5),naziv: sala,predavac: predavac};
                    p.push(o);
                }
                else if(!termin.redovni && predavac!="" && sala!=""){
                    var o = {datum: termin.datum,pocetak: termin.pocetak.toString().substring(0, 5),kraj: termin.kraj.toString().substring(0, 5),naziv: sala,predavac: predavac};
                    v.push(o);
                }
            }
            var zauzeca = { periodicna: p, vanredna:v};
            return zauzeca;
        }).then(function(zauzeca) {
            var greska=false;
            var predavacGreska="";
            for(var i = 0; i < zauzeca.vanredna.length; i++) {
                if(JSON.stringify(zauzeca.vanredna[i]) == JSON.stringify(req.body)){
                    greska=true;
                    predavacGreska=zauzeca.vanredna[i].predavac;
                    break;
                }
                if(req.body.datum.toString() == zauzeca.vanredna[i].datum.toString() && req.body.naziv.toString() == zauzeca.vanredna[i].naziv.toString() &&
                    poklapanjeTermina(parseInt(zauzeca.vanredna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.vanredna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.vanredna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.vanredna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                    greska=true;
                    predavacGreska=zauzeca.vanredna[i].predavac;
                    break;
                }
                if(req.body.datum.toString() == zauzeca.vanredna[i].datum.toString() && req.body.predavac.toString() == zauzeca.vanredna[i].predavac.toString() &&
                    poklapanjeTermina(parseInt(zauzeca.vanredna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.vanredna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.vanredna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.vanredna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                    greska=true;
                    predavacGreska="Odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.";
                    break;
                }
            }
            for(var i = 0; i < zauzeca.periodicna.length; i++) {
                if(dajDatume(zauzeca.periodicna[i].dan,zauzeca.periodicna[i].semestar.toString()).find(element => element == req.body.datum.toString()) != undefined && req.body.naziv.toString() == zauzeca.periodicna[i].naziv.toString() &&
                poklapanjeTermina(parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                    greska=true;
                    predavacGreska=zauzeca.periodicna[i].predavac;
                    break;
                }
                if(dajDatume(zauzeca.periodicna[i].dan,zauzeca.periodicna[i].semestar.toString()).find(element => element == req.body.datum.toString()) != undefined && req.body.predavac.toString() == zauzeca.periodicna[i].predavac.toString() &&
                poklapanjeTermina(parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                    greska=true;
                    predavacGreska="Odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.";
                    break;
                }
            }
            if(!greska){
                db.sala.findOne({ where: { naziv: req.body.naziv } }).then(function (s) {
                    if(s!=null){
                        db.osoblje.findOne({ where: { ime: req.body.predavac.toString().split(" ")[0], prezime: req.body.predavac.toString().split(" ")[1] } }).then(function (o) {
                            if(o!=null){    
                                db.termin.create({
                                    redovni: false, 
                                    dan: null, 
                                    datum: req.body.datum, 
                                    semestar: null,
                                    pocetak: req.body.pocetak, 
                                    kraj: req.body.kraj
                                }).then(function(t) {
                                    db.rezervacija.create({
                                        termin: t.id,
                                        sala: s.id,
                                        osoba: o.id
                                    }).then(function(z) {
                                        console.log('Vanredno zauzeće uspješno dodano!');
                                        zauzeca.vanredna.push({datum: req.body.datum,pocetak: req.body.pocetak,kraj: req.body.kraj,naziv: req.body.naziv,predavac: req.body.predavac});
                                        res.writeHead(200, { 'Content-Type': "application/json" });
                                        res.end(JSON.stringify(zauzeca));
                                    }).catch(function(err) { console.log(err) });
                                }).catch(function(err) { console.log(err) });
                            }
                        }).catch(function(err) { console.log(err) });
                    }
                }).catch(function(err) { console.log(err) });   
            }
            else {
                if(predavacGreska!="Odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.") {
                    db.osoblje.findOne({ where: { ime: predavacGreska.toString().split(" ")[0], prezime: predavacGreska.toString().split(" ")[1] } }).then(function (o) {
                        var greskaTekst = 'Salu je rezervisao ' + o.uloga + ' ' + o.prezime + ' ' + o.ime + '.';
                        res.status(500).send(greskaTekst);
                    });
                }
                else
                    res.status(500).send(predavacGreska);
            }
        }).catch(function(err) { console.log(err) });
    });
});

app.post('/rezervisiPeriodicne', (req, res) => {
    db.rezervacija.findAll().then(function (rez) {
        let promises = [];
        for (r of rez) {
            promises.push(getSala(r.sala));
            promises.push(getOsoba(r.osoba));
            promises.push(getTermin(r.termin));
        }
        Promise.all(promises).then(function(results) {
            var p=[];
            var v=[];
            for (let i = 0; i < results.length; i += 3) {
                var sala = results[i];
                var predavac = results[i + 1];
                var termin = results[i + 2];
                if(termin.redovni && predavac!="" && sala!=""){
                    var o = {dan: termin.dan,semestar: termin.semestar,pocetak: termin.pocetak.toString().substring(0, 5),kraj: termin.kraj.toString().substring(0, 5),naziv: sala,predavac: predavac};
                    p.push(o);
                }
                else if(!termin.redovni && predavac!="" && sala!=""){
                    var o = {datum: termin.datum,pocetak: termin.pocetak.toString().substring(0, 5),kraj: termin.kraj.toString().substring(0, 5),naziv: sala,predavac: predavac};
                    v.push(o);
                }
            }
            var zauzeca = { periodicna: p, vanredna:v};
            return zauzeca;
        }).then(function(zauzeca) {
            var greska=false;
            var predavacGreska="";
            for(var i = 0; i < zauzeca.periodicna.length; i++) {
                if(JSON.stringify(zauzeca.periodicna[i]) == JSON.stringify(req.body)) {
                    greska=true;
                    predavacGreska=zauzeca.periodicna[i].predavac;
                    break;
                }
                if(parseInt(req.body.dan) == zauzeca.periodicna[i].dan && req.body.semestar.toString() == zauzeca.periodicna[i].semestar.toString() && req.body.naziv.toString() == zauzeca.periodicna[i].naziv.toString() &&
                    poklapanjeTermina(parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                    greska=true;
                    predavacGreska=zauzeca.periodicna[i].predavac;
                    break;
                }
                if(parseInt(req.body.dan) == zauzeca.periodicna[i].dan && req.body.semestar.toString() == zauzeca.periodicna[i].semestar.toString() && req.body.predavac.toString() == zauzeca.periodicna[i].predavac.toString() &&
                    poklapanjeTermina(parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                    greska=true;
                    predavacGreska="Odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.";
                    break;
                }
            }

            for(var j = 0; j < zauzeca.vanredna.length; j++) { 
                if(danUSedmici(zauzeca.vanredna[j].datum.toString()) == req.body.dan && semestarUGodini(zauzeca.vanredna[j].datum) == req.body.semestar.toString() && zauzeca.vanredna[j].naziv.toString() == req.body.naziv.toString() &&
                poklapanjeTermina(parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]), parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]),parseInt(zauzeca.vanredna[j].pocetak.toString().split(":")[0]),parseInt(zauzeca.vanredna[j].pocetak.toString().split(":")[1]),parseInt(zauzeca.vanredna[j].kraj.toString().split(":")[0]),parseInt(zauzeca.vanredna[j].kraj.toString().split(":")[1]))) {
                    greska=true;
                    predavacGreska=zauzeca.vanredna[j].predavac;
                    break;
                }
                if(danUSedmici(zauzeca.vanredna[j].datum.toString()) == req.body.dan && semestarUGodini(zauzeca.vanredna[j].datum) == req.body.semestar.toString() && zauzeca.vanredna[j].predavac.toString() == req.body.predavac.toString() &&
                poklapanjeTermina(parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]), parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]),parseInt(zauzeca.vanredna[j].pocetak.toString().split(":")[0]),parseInt(zauzeca.vanredna[j].pocetak.toString().split(":")[1]),parseInt(zauzeca.vanredna[j].kraj.toString().split(":")[0]),parseInt(zauzeca.vanredna[j].kraj.toString().split(":")[1]))) {
                    greska=true;
                    predavacGreska="Odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.";
                    break;
                }
            }
            
            if(!greska){
                db.sala.findOne({ where: { naziv: req.body.naziv } }).then(function (s) {
                    if(s!=null) {
                        db.osoblje.findOne({ where: { ime: req.body.predavac.toString().split(" ")[0], prezime: req.body.predavac.toString().split(" ")[1] } }).then(function (o) {
                            if(o!=null) {    
                                db.termin.create({
                                    redovni: true, 
                                    dan: req.body.dan, 
                                    datum: null, 
                                    semestar: req.body.semestar,
                                    pocetak: req.body.pocetak, 
                                    kraj: req.body.kraj
                                }).then(function(t) {
                                    db.rezervacija.create({
                                        termin: t.id,
                                        sala: s.id,
                                        osoba: o.id
                                    }).then(function(z) { 
                                        console.log('Periodično zauzeće uspješno dodano!');
                                        zauzeca.periodicna.push({dan: req.body.dan,semestar: req.body.semestar,pocetak: req.body.pocetak,kraj: req.body.kraj,naziv: req.body.naziv,predavac: req.body.predavac});
                                        res.writeHead(200, { 'Content-Type': "application/json" });
                                        res.end(JSON.stringify(zauzeca));
                                    }).catch(function(err) { console.log(err) });
                                }).catch(function(err) { console.log(err) });
                            }
                        }).catch(function(err) { console.log(err) });
                    }
                }).catch(function(err) { console.log(err) });
                
            }
            else {
                if(predavacGreska!="Odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.") {
                    db.osoblje.findOne({ where: { ime: predavacGreska.toString().split(" ")[0], prezime: predavacGreska.toString().split(" ")[1] } }).then(function (o) {
                        var greskaTekst = 'Salu je rezervisao ' + o.uloga + ' ' + o.prezime + ' ' + o.ime + '.';
                        res.status(500).send(greskaTekst);
                    });
                }
                else
                    res.status(500).send(predavacGreska);
            }
        }).catch(function(err) { console.log(err) });
    });
});

// Spirala 3
app.get('/rezervacija.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/rezervacija.html'));
});

app.get('/sale.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/sale.html'));
});

app.get('/osobe.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/osobe.html'));
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/pocetna.html'));
});

app.get('/pocetna.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/pocetna.html'));
});

app.get('/unos.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/unos.html'));
});

app.post('/slike', (req, res) => {
    fs.readFile('./slike.json', 'utf8', function (err, data) {
        if (err) throw err;
        var urls = JSON.parse(data);
        var slike = { "url" :[], "zadnja": false};
        for (var i=0; i<urls.url.length; i++)
            if(i>=req.body.prva && i<=req.body.zadnja)
                slike.url.push(urls.url[i]);
        if(req.body.zadnja+1==urls.url.length)
            slike.zadnja=true;
        
        if(slike.url.length!=0)
            res.json(JSON.stringify(slike));
        else {
            res.status(500);
            res.json({ greska: 'Ne postoji niti jedna slika ili su poslati pogresni podaci!'});
        }
    });
});

function getSala(salaID) {
    return new Promise((resolve, reject) => {
        db.sala.findOne({ where: { id: salaID } }).then(sala => {
            resolve(sala.naziv);
        }).catch(err => {
            reject(err)
        });
    });
}
function getOsoba(osobaID) {
    return new Promise((resolve, reject) => {
        db.osoblje.findOne({ where: { id: osobaID } }).then(osoba => {
            resolve(osoba.ime + " " + osoba.prezime);
        }).catch(err => {
            reject(err)
        });
    });
}
function getTermin(terminID) {
    return new Promise((resolve, reject) => {
        db.termin.findOne({ where: { id: terminID } }).then(t => {
            resolve(t);
        })
        .catch(err => {
            reject(err)
        });
    });
}

function inicializacija(){
    var osobeListaPromisea=[];
    var saleListaPromisea=[];
    var terminiListaPromisea=[];
    var rezervacijeListaPromisea=[];
    return new Promise(function(resolve,reject){
    osobeListaPromisea.push(new Promise((resolve, reject) => {db.osoblje.create({ime: "Neko", prezime: "Nekić", uloga: "profesor"}).then(o => {resolve(o);}).catch(err => {reject(err)});}));
    osobeListaPromisea.push(new Promise((resolve, reject) => {db.osoblje.create({ime: "Drugi", prezime: "Neko", uloga: "asistent"}).then(o => {resolve(o);}).catch(err => {reject(err)});}));
    osobeListaPromisea.push(new Promise((resolve, reject) => {db.osoblje.create({ime: "Test", prezime: "Test", uloga: "asistent"}).then(o => {resolve(o);}).catch(err => {reject(err)});}));
   
    Promise.all(osobeListaPromisea).then(function(osobe){
        var prvaOsoba=osobe[0];
        var drugaOsoba=osobe[1];
        var trecaOsoba=osobe[2];
        
        saleListaPromisea.push(db.sala.create({ naziv: "1-11",zaduzenaOsoba: prvaOsoba.id}).then(function (s){
            saleListaPromisea.push(db.sala.create({ naziv: "1-15",zaduzenaOsoba: drugaOsoba.id}));
            return new Promise(function (resolve, reject) { resolve(s);});
        }));

        Promise.all(saleListaPromisea).then(function(sale){
            var prvaSala=sale[0];
            var drugaSala=sale[1];

            terminiListaPromisea.push(new Promise((resolve, reject) => {db.termin.create({ redovni: false, dan: null, datum: "01.01.2020", semestar: null, pocetak: "12:00", kraj: "13:00" }).then(t => {resolve(t);}).catch(err => {reject(err)});}));
            terminiListaPromisea.push(new Promise((resolve, reject) => {db.termin.create({ redovni: true, dan: 0, datum: null, semestar: "zimski", pocetak: "13:00", kraj: "14:00" }).then(t => {resolve(t);}).catch(err => {reject(err)});}));

            Promise.all(terminiListaPromisea).then(function(termini){
                var prviTermin=termini[0];
                var drugiTermin=termini[1];
                rezervacijeListaPromisea.push(new Promise((resolve, reject) => {db.rezervacija.create({termin: prviTermin.id, sala: prvaSala.id, osoba: prvaOsoba.id}).then(r => {resolve(r);}).catch(err => {reject(err)});}));
                rezervacijeListaPromisea.push(new Promise((resolve, reject) => {db.rezervacija.create({termin: drugiTermin.id, sala: prvaSala.id, osoba: trecaOsoba.id}).then(r => {resolve(r);}).catch(err => {reject(err)});}));
                Promise.all(rezervacijeListaPromisea).then(function(r){resolve(r);}).catch(function(err){console.log("Rezervacije greska "+err);});
            }).catch(function(err){console.log("Termini greska "+err);});
        }).catch(function(err){console.log("Sale greska "+err);});
    }).catch(function(err){console.log("Osobe greska "+err);});   
    });
}

function semestarUGodini(datum){
    if(parseInt(datum.toString().split(".")[1])==1 || parseInt(datum.toString().split(".")[1])==10 || parseInt(datum.toString().split(".")[1])==11 || parseInt(datum.toString().split(".")[1])==12)
        return "zimski";
    else if(parseInt(datum.toString().split(".")[1])==2 || parseInt(datum.toString().split(".")[1])==3 || parseInt(datum.toString().split(".")[1])==4 || parseInt(datum.toString().split(".")[1])==5 || parseInt(datum.toString().split(".")[1])==6)
        return "ljetni";
    return "";
}
function dajBrojDanaUMjesecu(mjesec, godina){
    var daniUMjesecu = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] 
    if(((godina % 100==0) && (godina % 400==0)) || (godina % 4==0 ))
        daniUMjesecu[1]=29;
    return daniUMjesecu[mjesec];
}
function danUSedmici(datum){
    var dpom = new Date(parseInt(datum.toString().split(".")[2]), parseInt(datum.toString().split(".")[1])-1, parseInt(datum.toString().split(".")[0]), 10, 33);
    var dan = dpom.getDay();
    dan--;
    if(dan<0)
        dan=6;
    return dan;
}
function dajDatume(dan,semestar){
    var datumi =[];
    if(semestar=="zimski"){
        var m = 0;
        for(var i=1; i<=dajBrojDanaUMjesecu(m,2020); i++){
            if(dan==danUSedmici(i +"." + (m+1)  + ".2020")){
                var mjesec;
                var d;
                if(m+1<10)
                    mjesec = "0" + (m+1).toString();
                else
                    mjesec = (m+1).toString();
                if(i<10)
                    d= "0" + i.toString();
                else
                    d = i.toString();
                datumi.push(d + "." + mjesec + ".2020");
            }
        }
        for(var j=9; j<12; j++){
            m = j;
            for(var i=1; i<=dajBrojDanaUMjesecu(m,2020); i++){
                if(dan==danUSedmici(i +"." + (m+1)  + ".2020")){
                    var mjesec, d;
                    if(m+1<10)
                        mjesec = "0" + (m+1).toString();
                    else
                        mjesec = (m+1).toString();
                    if(i<10)
                        d = "0" + i.toString();
                    else
                        d = i.toString();
                    datumi.push(d + "." + mjesec + ".2020");
                }
            }
        }
    }
    else if(semestar=="ljetni"){
        for(var j=1; j<6; j++){
            var m = j;
            for(var i=1; i<=dajBrojDanaUMjesecu(m,2020); i++){
                if(dan==danUSedmici(i +"." + (m+1)  + ".2020")){
                    var mjesec, d;
                    if(m+1<10)
                        mjesec = "0" + (m+1).toString();
                    else
                        mjesec = (m+1).toString();
                    if(i<10)
                        d = "0" + i.toString();
                    else
                        d = i.toString();
                    datumi.push(d + "." + mjesec + ".2020");
                }
            }
        }
    }
    return datumi;
}
function poklapanjeTermina(hp, mp, hk, mk, h1, m1, h2, m2) {
    if((h1+m1===h2+m2) || h1>h2 || (h1==h2 && m1>m2))
        return false;
    if(hk==h1 && mk==m1)
        return false;
    if(hp==h2 && mp==m2)
        return false;
    if(hp<=h1 && hk>=h2)
        return true;
    return (h1 < hp || h1 == hp && m1 <= mp) && (hp < h2 || hp == h2 && mp <= m2) || (h1 < hk || h1 == hk && m1 <= mk) && (hk < h2 || hk == h2 && mk <= m2);
}

var server = app.listen(8080, function() {
    console.log('Slušam %d port!', server.address().port);
});
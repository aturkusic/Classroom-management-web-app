const chai = require("chai");
const chaiHttp = require("chai-http");
const db = require("../db.js");
const app = require("./index-test");

const { expect } = chai;
chai.use(chaiHttp);

describe('Spirala 4', function () {
    this.timeout(20000);
    before(function (done) { // Kreiramo po dvije osobe i sale, i po jedan termin i vanrednu rezervaciju
        this.timeout(10000);
        db.sequelize.sync({force:true}).then(function(){
            db.osoblje.create({
                ime: "Neko",
                prezime: "Nekić",
                uloga: "profesor" 
            }).then(function(o1) {
                db.osoblje.create({
                    ime: "Drugi",
                    prezime: "Neko",
                    uloga: "asistent" 
                }).then(function(o2) {
                    db.sala.create({
                        naziv: "1-11",
                        zaduzenaOsoba: o1.id
                    }).then(function(s1) {
                        db.sala.create({
                            naziv: "1-15",
                            zaduzenaOsoba: o2.id
                        }).then(function(s2) {
                            db.termin.create({
                                redovni: false, 
                                dan: null, 
                                datum: "01.01.2020", 
                                semestar: null,
                                pocetak: "12:00", 
                                kraj: "13:00"
                            }).then(function(t) {
                                db.rezervacija.create({
                                    termin: t.id,
                                    sala: s1.id,
                                    osoba: o1.id
                                }).then(function(z) { console.log("Uspješno kreirane dvije osobe, dvije sale i po jedan termin i vanredna rezervacija!"); done();
                                }).catch(function(err) { console.log(err); });
                            }).catch(function(err) { console.log(err); });
                        }).catch(function(err) { console.log(err); });
                    }).catch(function(err) { console.log(err); });
                }).catch(function(err) { console.log(err); });
            }).catch(function(err) { console.log(err); });
        });
     })
    describe('GET /osoblje', function () {
        this.timeout(10000);
        it("Trebaju se vratiti 2 osobe", done => {
            chai.request(app)
                .get("/osoblje")
                .end((err, res) => { 
                    expect(res).to.have.status(200);
                    expect(res.body.length).to.equals(2);
                    done();
                });
          });
    });
    describe('GET /sale', function () {
        this.timeout(10000);
        it("Trebaju se vratiti 2 sale", done => {
            chai.request(app)
                .get("/sale")
                .end((err, res) => { 
                    expect(res).to.have.status(200);
                    expect(res.body.length).to.equals(2);
                    done();
                });
          });
    });
    describe('GET /rezervacije', function () {
        this.timeout(10000);
        it("Treba se vratiti 1 vanredno zauzece", done => {
            chai.request(app)
                .get("/rezervacije")
                .end((err, res) => { 
                    expect(res).to.have.status(200);
                    expect(res.body.vanredna.length).to.equals(1);
                    done();
                });
          });
    });
    describe('/POST rezervisiVanredno', () => {
        this.timeout(10000);
        it('Treba se rezervisati vanredno zauzece', (done) => {
            let zauzece = {
                datum: "20.01.2020",
                pocetak: "09:00",
                kraj: "11:00",
                naziv: "1-11",
                predavac: "Neko Nekić"
            };
            
            chai.request(app)
              .post('/rezervisiVanredno')
              .send(zauzece)
              .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body.vanredna.length).to.equals(2); // Broj vanrednih treba biti 2 sto znaci da se rezervisalo vanredno zauzece
                    done();;
              });
        });
    });
    describe('/POST rezervisiPeriodicne', () => {
        this.timeout(10000);
        it('Treba se rezervisati periodicno zauzece', (done) => {
            let zauzece = {
                dan: 1,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "11:00",
                naziv: "1-11",
                predavac: "Neko Nekić"
            };
            
            chai.request(app)
              .post('/rezervisiPeriodicne')
              .send(zauzece)
              .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body.periodicna.length).to.equals(1); // Broj periodicnih treba biti 1 sto znaci da se rezervisalo periodicno zauzece
                    done();;
              });
        });
    });
    describe('GET /rezervacije', function () {
        this.timeout(10000);
        it("Trebaju se vratiti 3 zauzeca-provjera da se zauzeca azuriraju", done => {
            chai.request(app)
                .get("/rezervacije")
                .end((err, res) => { 
                    expect(res).to.have.status(200);
                    expect(res.body.vanredna.length+res.body.periodicna.length).to.equals(3); // 1 periodicno i 2 vanredna
                    done();
                });
          });
    });
    describe('/POST rezervisiVanredno', () => {
        this.timeout(10000);
        it('Zauzece se ne treba rezervisati jer postoji preklapanje sa vanrednim zauzecem', (done) => {
            let zauzece = {
                datum: "20.01.2020",
                pocetak: "08:00", // Imamo vanredno zauzece od 09:00 do 11:00
                kraj: "11:00",
                naziv: "1-11",
                predavac: "Drugi Neko"
            };
            
            chai.request(app)
              .post('/rezervisiVanredno')
              .send(zauzece)
              .end((err, res) => {
                    expect(res).to.have.status(500);
                    expect(res.text).to.equals('Salu je rezervisao profesor Nekić Neko.'); // U 4. testu se rezervise sala 1-11 na profesora Nekić Neko
                    done();;
              });
        });
    });
    describe('/POST rezervisiVanredno', () => {
        this.timeout(10000);
        it('Zauzece se ne treba rezervisati jer postoji preklapanje sa periodicnim zauzecem', (done) => {
            let zauzece = {
                datum: "21.01.2020", // utorak(redni broj u sedmici=1)
                pocetak: "09:00",
                kraj: "11:00",
                naziv: "1-11",
                predavac: "Drugi Neko"
            };
            
            chai.request(app)
              .post('/rezervisiVanredno')
              .send(zauzece)
              .end((err, res) => {
                    expect(res).to.have.status(500);
                    expect(res.text).to.equals('Salu je rezervisao profesor Nekić Neko.'); // U 5. testu se rezervise periodicno zauzece(sala 1-11) na profesora Nekić Neko
                    done();;
              });
        });
    });
    describe('/POST rezervisiVanredno', () => {
        this.timeout(10000);
        it('Zauzece se ne treba rezervisati jer odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.', (done) => {
            let zauzece = {
                datum: "20.01.2020",
                pocetak: "08:00",
                kraj: "11:00",
                naziv: "1-15",
                predavac: "Neko Nekić"
            };
            
            chai.request(app)
              .post('/rezervisiVanredno')
              .send(zauzece)
              .end((err, res) => {
                    expect(res).to.have.status(500);
                    expect(res.text).to.equals('Odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.'); // U 4. testu se rezervise sala 1-11 na profesora Nekić Neko
                    done();;
              });
        });
    });
    describe('/POST rezervisiPeriodicne', () => {
        this.timeout(10000);
        it('Zauzece se ne treba rezervisati jer postoji preklapanje sa periodicnim zauzecem', (done) => {
            let zauzece = {
                dan: 1,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "12:00", // Imamo periodicno zauzece od 09:00 do 11:00
                naziv: "1-11",
                predavac: "Drugi Neko"
            };
            
            chai.request(app)
              .post('/rezervisiPeriodicne')
              .send(zauzece)
              .end((err, res) => {
                    expect(res).to.have.status(500);
                    expect(res.text).to.equals('Salu je rezervisao profesor Nekić Neko.'); // U 5. testu se rezervise sala 1-11 na profesora Nekić Neko
                    done();;
              });
        });
    });
    describe('/POST rezervisiPeriodicne', () => {
        this.timeout(10000);
        it('Zauzece se ne treba rezervisati jer postoji preklapanje sa vanrednim zauzecem', (done) => {
            let zauzece = {
                dan: 0, // Imamo vanredno zauzece od 09:00 do 11:00 na 20.01.2020 (redni broj dana u sedmici=0)
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "11:00", 
                naziv: "1-11",
                predavac: "Neko Nekić"
            };
            
            chai.request(app)
              .post('/rezervisiPeriodicne')
              .send(zauzece)
              .end((err, res) => {
                    expect(res).to.have.status(500);
                    expect(res.text).to.equals('Salu je rezervisao profesor Nekić Neko.'); // U 4. testu se rezervise sala 1-11 na profesora Nekić Neko
                    done();;
              });
        });
    });
    describe('/POST rezervisiPeriodicne', () => {
        this.timeout(10000);
        it('Zauzece se ne treba rezervisati jer odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.', (done) => {
            let zauzece = {
                dan: 0, // Imamo vanredno zauzece od 09:00 do 11:00 na 20.01.2020 (redni broj dana u sedmici=0)
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "11:00", 
                naziv: "1-15",
                predavac: "Neko Nekić"
            };
            
            chai.request(app)
              .post('/rezervisiPeriodicne')
              .send(zauzece)
              .end((err, res) => {
                    expect(res).to.have.status(500);
                    expect(res.text).to.equals('Odabrani predavač ima rezervisano zauzeće u drugoj sali u ovom terminu.'); // U 5. testu se rezervise sala 1-11 na profesora Nekić Neko
                    done();;
              });
        });
    });
});
const http = require('http');
const fs = require('fs');
const express = require('express');
const bodyParser = require('body-parser');
var path = require("path");
var app = express();

app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/pocetna.html'));
});

app.get('/pocetna.html', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/pocetna.html'));
});

app.get('/unos.html', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/unos.html'));
});

app.get('/rezervacija.html', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/rezervacija.html'));
});

app.get('/sale.html', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/sale.html'));
});

app.get('/Images/univerzitet.gif', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/univerzitet.gif'));
});

app.get('/Images/Slika1.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika1.jpg'));
});

app.get('/Images/Slika2.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika2.jpg'));
});

app.get('/Images/Slika3.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika3.jpg'));
});

app.get('/Images/Slika4.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika4.jpg'));
});

app.get('/Images/Slika5.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika5.jpg'));
});

app.get('/Images/Slika6.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika6.jpg'));
});

app.get('/Images/Slika7.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika7.jpg'));
});

app.get('/Images/Slika8.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika8.jpg'));
});

app.get('/Images/Slika9.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika9.jpg'));
});

app.get('/Images/Slika10.jpg', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/Images/Slika10.jpg'));
});

app.get('/zauzeca.json', (req, res) => {
    res.setHeader('Content-Type', 'application/json'); 
    var data = fs.readFileSync('zauzeca.json');
    data = JSON.parse(data);
//    console.log(data);
    res.end(JSON.stringify(data));
});

app.get('/slike.json', (req, res) => {
    res.setHeader('Content-Type', 'application/json'); 
    var data = fs.readFileSync('slike.json');
    data = JSON.parse(data);
    //console.log(data);
  //  console.log(data);
    res.end(JSON.stringify(data));
});

app.post('/zauzeca.json', (req, res) => {
    var data = fs.readFileSync('zauzeca.json', (err, data) => {
        if(err) throw err;
    });
    //console.log("usao");
    data = JSON.parse(data);
    var zahtjev = req.body;
    //console.log(req.body["dan"]);
    var ispravno = true;

    for(var i = 0; i < data.periodicna.length; ++i) {
      /*  console.log(req.body["dan"] + " " + data.periodicna[i].dan);
        console.log(req.body["semestar"] + " " + data.periodicna[i].semestar);
        console.log(req.body["naziv"] + " " + data.periodicna[i].naziv);
        console.log(pretvoriUMinute(data.periodicna[i].pocetak) + " " + pretvoriUMinute(req.body["pocetak"]));
        console.log("Prvi bool " + (pretvoriUMinute(data.periodicna[i].pocetak) <= pretvoriUMinute(req.body["pocetak"]) && pretvoriUMinute(data.periodicna[i].kraj) >= pretvoriUMinute(req.body["pocetak"])));
  */    if(req.body["dan"] == data.periodicna[i].dan && req.body["semestar"] == data.periodicna[i].semestar && req.body["naziv"] == data.periodicna[i].naziv) {
        //    console.log("usao prvi put");
            if((pretvoriUMinute(data.periodicna[i].pocetak) <= pretvoriUMinute(req.body["pocetak"]) && pretvoriUMinute(data.periodicna[i].kraj) >= pretvoriUMinute(req.body["pocetak"])) || (pretvoriUMinute(data.periodicna[i].pocetak) <= pretvoriUMinute(req.body["kraj"]) && pretvoriUMinute(data.periodicna[i].kraj) >= pretvoriUMinute(req.body["kraj"]))) {
                ispravno = false;
              //console.log("usao drugi put i ispravno je sada " + ispravno);
                break;
            }
        }
    }
    
    
    if(ispravno) {
   // console.log(data);
        if(req.body["semestar"] != undefined) data.periodicna.push(req.body);
        else data.vanredna.push(req.body);
        fs.writeFile("zauzeca.json", JSON.stringify(data), function (err, data) {
            if(err) throw err;
        });
        res.json(data);
    }
    else {
        res.json("Nije moguće");
    }
    var dataString = toString(data);

//    Kalendar.ucitajPodatke(data.periodicna, data.vanredna);
});

app.listen(8080);

function pretvoriUMinute(vrijeme) {
    return parseInt(vrijeme.substring(0, 2), 10) * 60 + parseInt(vrijeme.substring(3, 5), 10);  
}
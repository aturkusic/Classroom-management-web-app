let Kalendar = (function() {   
    var periodicnaRezervacija = [];
    var vanrednaRezervacija = [];
    var dobaGodine = new Date();
    var mjesecZaPoredjenje = dobaGodine.getMonth();

    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {
        var sale = document.getElementsByClassName('sala');
        for(var i = 0; i < sale.length; ++i) {
            sale[i].classList.remove('zauzeta');
            sale[i].classList.add('slobodna');
        }
        
        for(var i = 0; i < periodicnaRezervacija.length; ++i) {
            if(((periodicnaRezervacija[i].semestar == 'zimski' && ((mjesec >= 9 && mjesec <= 11) || mjesec == 0)) && periodicnaRezervacija[i].naziv == sala) || ((periodicnaRezervacija[i].semestar == 'ljetni' && ((mjesec >= 1 && mjesec <= 5) || mjesec == 0)) && periodicnaRezervacija[i].naziv == sala)) {
                if(((pretvoriUMinute(pocetak) >= pretvoriUMinute(periodicnaRezervacija[i].pocetak)) && (pretvoriUMinute(pocetak) <= pretvoriUMinute(periodicnaRezervacija[i].kraj))) || ((pretvoriUMinute(kraj) >= pretvoriUMinute(periodicnaRezervacija[i].pocetak)) && (pretvoriUMinute(kraj) <= pretvoriUMinute(periodicnaRezervacija[i].kraj)))) {
                    for(var j = parseInt(periodicnaRezervacija[i].dan); j < 42; j += 7) {
                    //    if(mjesec >= mjesecZaPoredjenje - 1) { //Ovaj uslov ce se pobrinuti da se kalendar ne popunjava za mjesece koji su prosli
                            document.getElementsByClassName('sala')[j].classList.remove('slobodna');
                            document.getElementsByClassName('sala')[j].classList.add('zauzeta');
                      //  }
                    }
                }
            }     
        }

        for(var i = 0; i < vanrednaRezervacija.length; ++i) {
            if(parseInt(vanrednaRezervacija[i].datum.substring(3, 5)) - 1 == mjesec) {
                if(vanrednaRezervacija[i].naziv == sala) {
                    if(((pretvoriUMinute(pocetak) >= pretvoriUMinute(vanrednaRezervacija[i].pocetak)) && (pretvoriUMinute(pocetak) <= pretvoriUMinute(vanrednaRezervacija[i].kraj))) || ((pretvoriUMinute(kraj) >= pretvoriUMinute(vanrednaRezervacija[i].pocetak)) && (pretvoriUMinute(kraj) <= pretvoriUMinute(vanrednaRezervacija[i].kraj)))) {
                        for(var j = 0; j < 42; ++j) {
                            var varijabla1 = document.getElementsByClassName('sala')[j].innerHTML;
                            var varijabla2 = vanrednaRezervacija[i].datum.substring(0, 2);
                            if(varijabla1 == varijabla2) {
                                document.getElementsByClassName('sala')[j].classList.remove('slobodna');
                                document.getElementsByClassName('sala')[j].classList.add('zauzeta');
                            }
                        }
                    }
                }
            }
        }
    }

    function ucitajPodatkeImpl(periodicna, vanredna) {   
        vanrednaRezervacija = [];
        periodicnaRezervacija = [];     
        for(var i = 0; i < periodicna.length; ++i) periodicnaRezervacija.push(periodicna[i]);
        for(var i = 0; i < vanredna.length; ++i) vanrednaRezervacija.push(vanredna[i]);
    }    
   
    function iscrtajKalendarImpl(kalendarRef, mjesec) {    
    var sale = document.getElementsByClassName('sala');  
        switch(mjesec) {
            case 0:
                reset();
                document.getElementById('prethodni').disabled = true;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Januar";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 1; ++i) {
                    sale[i].classList.add('nePrikazuj');
                }
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 1 && i < sale.length - 10) {
                        sale[i].innerHTML = i; 
                       // sale[i].setAttribute("id", i);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 11; ++i) {
                    sale[sale.length - i].classList.add('nePrikazuj');
                }
                break;
            case 1:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Februar";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 4; ++i) {
                    sale[i].classList.add('nePrikazuj');
                }
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 4 && i < sale.length - 10) {
                        sale[i].innerHTML = i - 3;                        
                      //  sale[i].setAttribute("id", i - 3);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 11; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
            case 2:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Mart";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 4; ++i) {
                    sale[i].classList.add('nePrikazuj');
                }
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 4 && i < sale.length - 7) {
                        sale[i].innerHTML = i - 3;
                    //    sale[i].setAttribute("id", i - 3);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 8; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;             
            case 3:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "April";
                //for(var i = 0; i < 3; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < sale.length; ++i) {
                    if(i < sale.length - 12) {
                        sale[i].innerHTML = i + 1;
                   //     sale[i].setAttribute("id", i + 1);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 13; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
            case 4:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Maj";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 2; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 2 && i < sale.length - 5) {
                        sale[i].innerHTML = i - 1;                        
                    //    sale[i].setAttribute("id", i - 1);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 10; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
            case 5:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Juni";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 5; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 5 && i < sale.length - 7) {
                        sale[i].innerHTML = i - 4;
                   //     sale[i].setAttribute("id", i - 4);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 8; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
            case 6:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Juli";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                //for(var i = 0; i < 3; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < sale.length; ++i) {
                    if(i < sale.length - 11) {
                        sale[i].innerHTML = i + 1;
                    //    sale[i].setAttribute("id", i + 1);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 12; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
            case 7:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "August";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 3; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 3 && i < sale.length - 8) {
                        sale[i].innerHTML = i - 2;
                    //    sale[i].setAttribute("id", i - 2);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 9; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
            case 8:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Septembar";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 6; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 6 && i < sale.length - 6) {
                        sale[i].innerHTML = i - 5;
                     //   sale[i].setAttribute("id", i - 5);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 7; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
            case 9:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Oktobar";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 1; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 1 && i < sale.length - 10) {
                        sale[i].innerHTML = i;
                   //     sale[i].setAttribute("id", i);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 11; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
            case 10:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = false;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Novembar";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 4; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 4 && i < sale.length - 8) {
                        sale[i].innerHTML = i - 3;
                //        sale[i].setAttribute("id", i - 3);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 9; ++i) sale[sale.length - i].classList.add('nePrikazuj');

                break;
            case 11:
                reset();
                document.getElementById('prethodni').disabled = false;
                document.getElementById('sljedeci').disabled = true;
                document.getElementsByClassName('mjesecIme')[0].innerHTML = "Decembar";
                for(var i = 0; i < 42; ++i) {
                    sale[i].setAttribute("id", i);
                }
                for(var i = 0; i < 6; ++i) sale[i].classList.add('nePrikazuj');
                for(var i = 0; i < sale.length; ++i) {
                    if(i >= 6 && i < sale.length - 5) {
                        sale[i].innerHTML = i - 5;
              //          sale[i].setAttribute("id", i - 5);
                        sale[i].setAttribute("onclick", "Pozivi.odabranDan(this.id)");
                    }
                    else sale[i].innerHTML = " ";
                } 
                for(var i = 1; i < 6; ++i) sale[sale.length - i].classList.add('nePrikazuj');
                break;
        } 
        bojenje();
    }

    return {        
        obojiZauzeca: obojiZauzecaImpl,        
        ucitajPodatke: ucitajPodatkeImpl,        
        iscrtajKalendar: iscrtajKalendarImpl    
}}());

var trenutniMjesec;
var mjesIme = document.getElementsByClassName('mjesecIme');
var oldKal = document.getElementsByClassName('kalendar');
var danasnjiDatum = new Date();
trenutniMjesec = danasnjiDatum.getMonth();

var periodicna = [];/*
    {dan : 0, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'},
    {dan : 3, semestar : 'ljetni', pocetak : '13:00', kraj : '14:30', naziv : 'VA1', predavac : 'predavac2'},
    {dan : 5, semestar : 'zimski', pocetak : '13:00', kraj : '15:00', naziv : 'VA1', predavac : 'predavac3'},
    {dan : 2, semestar : 'ljetni', pocetak : '11:30', kraj : '13:30', naziv : 'VA1', predavac : 'predavac4'}
];
*/
var vanredna = [];/*
    {datum : '12.11.2019', pocetak : '12:00', kraj : '15:30', naziv : 'VA1', predavac : 'predavac5'},
    {datum : '13.11.2019', pocetak : '12:30', kraj : '15:00', naziv : 'VA1', predavac : 'predavac6'}
];*/

function pretvoriUMinute(vrijeme) {
    return parseInt(vrijeme.substring(0, 2), 10) * 60 + parseInt(vrijeme.substring(3, 5), 10);  
}

function reset() {
    var sale = document.getElementsByClassName('sala');  
    for(var i = 0; i < sale.length; ++i) sale[i].classList.remove('nePrikazuj');
}

function reset1() {
    var sale = document.getElementsByClassName('sala');  
    for(var i = 0; i < sale.length; ++i) sale[i].classList.remove('zauzeta'), sale[i].classList.add('slobodna');
}


function sljedeciprethodni(izbor) {
    switch(mjesIme) {
        case "Januar":
            trenutniMjesec = 0;
            break;
        case "Februar":
            trenutniMjesec = 1;
            break;
        case "Mart":
            trenutniMjesec = 2;
            break;                
        case "April":
            trenutniMjesec = 3;
            break;
        case "Maj":
            trenutniMjesec = 4;
            break;
        case "Juni":
            trenutniMjesec = 5;
            break;
        case "Juli":
            trenutniMjesec = 6;
            break;
        case "August":
            trenutniMjesec = 7;
            break;
        case "Septembar":
            trenutniMjesec = 8;
            break;
        case "Oktobar":
            trenutniMjesec = 9;
            break;
        case "Novembar":
            trenutniMjesec = 10;
            break;
        case "Decembar":
            trenutniMjesec = 11;
            break;             
    }
    if(izbor === 1) {
        Kalendar.iscrtajKalendar(Kalendar, --trenutniMjesec);
    }
    else if(izbor === 2) {
        Kalendar.iscrtajKalendar(Kalendar, ++trenutniMjesec);
    }
    else if(izbor === 0) Kalendar.iscrtajKalendar(Kalendar, trenutniMjesec);
}

function bojenje() {
    var mjesec = trenutniMjesec;
    var sale = document.getElementById('listaSala');
    var selektovanaSala = sale.options[sale.selectedIndex].text;
    var pocetak = new String; 
    pocetak = document.getElementById('pocetakRezervacije').value;
    var kraj = new String; 
    kraj = document.getElementById('krajRezervacije').value;
    Kalendar.obojiZauzeca(Kalendar, mjesec, selektovanaSala, pocetak, kraj);
}

window.onload = function () {
    this.sljedeciprethodni(0);
    Kalendar.ucitajPodatke(this.periodicna, this.vanredna);
}
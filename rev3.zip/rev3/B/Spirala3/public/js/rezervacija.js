Pozivi.ucitajZauzeca(function(res) {
    Kalendar.ucitajPodatke(res.periodicna, res.vanredna);
});



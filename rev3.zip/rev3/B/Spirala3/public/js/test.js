let assert = chai.assert;

describe('Rezervacija', function() {
  describe('iscrtajKalendar()', function() {
    it('Pozivanje iscrtajKalendar za mjesec sa 30 dana: očekivano je da se prikaže 30 dana', function() { 
      sljedeciprethodni(0); //Posto trenutni mjesec tj Novembar ima 30 dana, pozivamo njega
      //  window.addEventListener('load', function () {
      var sale = document.getElementsByClassName("sala");
      let dan = 0;    
      for(var i = 0; i < sale.length; ++i) {
        var test = sale[i].innerHTML;
            //if(test == "") console.log("PRAZAN STRING");
           // else console.log("Vrijednost u ovoj iteraciji", test);
        if(parseInt(test) > 0 && parseInt(test) < 32)  dan++;
            //console.log("Vrijednost dana", dan);
      }
      var testProsao = false;        
      if(dan == 30)  testProsao = true;
      console.log(testProsao);
          //console.log(dan);
      assert.equal(testProsao, true);
    });

    it('Pozivanje iscrtajKalendar za mjesec sa 31 dana: očekivano je da se prikaže 31 dana', function() { 
      sljedeciprethodni(2); //Iduci mjesec je decembar, pa pozivamo njega jer ima 31 dan
      var sale = document.getElementsByClassName("sala");
      let dan = 0;    
      for(var i = 0; i < sale.length; ++i) {
        var test = sale[i].innerHTML;
           //if(test == "") console.log("PRAZAN STRING");
           // else console.log("Vrijednost u ovoj iteraciji", test);
        if(parseInt(test) > 0 && parseInt(test) < 32) {
          dan++;
        }
            //console.log("Vrijednost dana", dan);
      }
      var testProsao = false;
      if(dan == 31) testProsao = true;
      console.log(testProsao);
          //console.log(dan);
      assert.equal(testProsao, true);
    });

    it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 1. dan u petak', function() { 
      sljedeciprethodni(1); //Posto je posljednji mjesec bio decembar, pozivamo sa opcijom 1 funkciju da nas vrati na trneutni mjesec(Novembar)
    //  window.addEventListener('load', function () {
        var sale = document.getElementsByClassName("sala");
        let dan = false;    
        for(var i = 0; i < sale.length; ++i) {
          var test = sale[i].innerHTML;
          //if(test == "") console.log("PRAZAN STRING");
         // else console.log("Vrijednost u ovoj iteraciji", test);
          if(parseInt(test) == 1 && i % 4 == 0) { //Provjeravamo djeljivost sa 4 jer upravo je to dio grida koji treba da bude prvi dan
            dan = true;
          }
          //console.log("Vrijednost dana", dan);
        }
        var testProsao = false;
        if(dan == true) testProsao = true;
        console.log(testProsao);
        //console.log(dan);
        assert.equal(testProsao, true);
    });

    it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 30. dan u subotu', function() { 
      sljedeciprethodni(0); //Posto je posljednji mjesec bio decembar, pozivamo sa opcijom 1 funkciju da nas vrati na trneutni mjesec(Novembar)
    //  window.addEventListener('load', function () {
        var sale = document.getElementsByClassName("sala");
        let dan = false;    
        for(var i = 0; i < sale.length; ++i) {
          var test = sale[i].innerHTML;
          //if(test == "") console.log("PRAZAN STRING");
         // else console.log("Vrijednost u ovoj iteraciji", test);
          if(parseInt(test) == 30 && i % 33 == 0) { //Provjeravamo djeljivost sa 33 jer upravo je to dio grida koji treba da bude posljednji dan
            dan = true;
          }
          //console.log("Vrijednost dana", dan);
        }
        var testProsao = false;
        if(dan == true) testProsao = true;
        console.log(testProsao);
        //console.log(dan);
        assert.equal(testProsao, true);
    });

    it('Pozivanje iscrtajKalendar za januar: očekivano je da brojevi dana idu od 1 do 31 počevši od utorka', function() { 
      for(var i = 0; i < 10; ++i) sljedeciprethodni(1);
      //  window.addEventListener('load', function () {
        var sale = document.getElementsByClassName("sala");
        let dan = false;    
        for(var i = 0; i < sale.length; ++i) {
          var mjeIme = document.getElementsByClassName('mjesecIme')[0].innerHTML;
          var test = sale[i].innerHTML;
          var prviDan = 0;
          var zadnjiDan = 0;
          for(var i = 0; i < sale.length; ++i) {
            if(parseInt(sale[i].innerHTML) == 1) prviDan = i;
          }
          for(var i = 0; i < sale.length; ++i) {
            if(parseInt(sale[i].innerHTML) == 31) zadnjiDan = i;
          }
          //if(test == "") console.log("PRAZAN STRING");
         // else console.log("Vrijednost u ovoj iteraciji", test);
          if(mjeIme == "Januar" && prviDan == 1 && zadnjiDan == 31) { //Ovdje se dobro poklapa to sto je na indexu 1 u gridu upravo dan utorak pa je onda jednostavno testirati ovu funkcionalnost
            dan = true;
          }
          //console.log("Vrijednost dana", dan);
        }
        var testProsao = false;
        if(dan == true) testProsao = true;
        console.log(testProsao);
        //console.log(dan);
        assert.equal(testProsao, true);
    });

    it('Pozivanje iscrtajKalendar za februar: očekivano je da ima 28 dana', function() { 
      sljedeciprethodni(2);
      //  window.addEventListener('load', function () {
        var sale = document.getElementsByClassName("sala");
        let dan = false;    
        for(var i = 0; i < sale.length; ++i) {
          var mjeIme = document.getElementsByClassName('mjesecIme')[0].innerHTML;
        //  var test = sale[i].innerHTML;
          var brojDana = 0;
          for(var i = 0; i < sale.length; ++i) {
            if(parseInt(sale[i].innerHTML) >= 1 && parseInt(sale[i].innerHTML) <= 28) brojDana++;
          }
          //if(test == "") console.log("PRAZAN STRING");
         // else console.log("Vrijednost u ovoj iteraciji", test);
          if(mjeIme == "Februar" && brojDana == 28 && sale[32].innerHTML == " ") { //Provjeravamo da li je broj dana 28 i da li je na indexu 31(koji bi bio iduci dan) prazno mjesto
            dan = true;
          }
          //console.log("Vrijednost dana", dan);
        }
        var testProsao = false;
        if(dan == true) testProsao = true;
        console.log(testProsao);
        //console.log(dan);
        assert.equal(testProsao, true);
    });

    it('Pozivanje iscrtajKalendar za cijelu godinu da vidimo da li godina zaista ima 365 dana(da li su svi mjeseci dobro iscrtani', function() { 
      sljedeciprethodni(1);
      //  window.addEventListener('load', function () {
        var sale = document.getElementsByClassName("sala");
        let dan = false; 
        var brojDana = 0;
        for(var j = 0; j < 12; ++j) {    
        for(var i = 0; i < sale.length; ++i) {
          var mjeIme = document.getElementsByClassName('mjesecIme')[0].innerHTML;
        //  var test = sale[i].innerHTML;
          for(var i = 0; i < sale.length; ++i) {
            if(parseInt(sale[i].innerHTML) >= 1 && parseInt(sale[i].innerHTML) <= 31) brojDana++;
          }
          //if(test == "") console.log("PRAZAN STRING");
         // else console.log("Vrijednost u ovoj iteraciji", test);
          //console.log("Vrijednost dana", dan);
        }
        sljedeciprethodni(2);
      }
      if(brojDana == 365) { 
        dan = true;
      }
        var testProsao = false;
        if(dan == true) testProsao = true;
        console.log(testProsao);
        //console.log(dan);
        assert.equal(testProsao, true);
    });

  });

  describe('obojiZauzeca()', function() {
    it('Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan', function() { 
    Kalendar.ucitajPodatke([], []);
    Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 9, "VA1", "10:30", "12:00");
    Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 9);
    var sale = document.getElementsByClassName('zauzeta');
    
    assert.equal(sale.length, 0);
    });

    it('Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina:očekivano je da se dan oboji bez obzira što postoje duple vrijednosti', function() { 
      Kalendar.ucitajPodatke([{dan : 0, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}, {dan : 0, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}], []);
      Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 9);
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 9, "VA1", "10:30", "12:00");
      var broj = 0;
      var sale = document.getElementsByClassName('zauzeta');
      for(var i = 0; i < sale.length; ++i) {
        if(sale[i].innerHTML != " ") broj++;
      }
      assert.equal(broj, 4);
    });

    it('Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivanoje da se ne oboji zauzeće', function() { 
      Kalendar.ucitajPodatke([{dan : 0, semestar : 'ljetni', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}, {dan : 0, semestar : 'ljetni', pocetak : '13:00', kraj : '15:30', naziv : 'VA1', predavac : 'predavac1'}], []);
      Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 4); //Ovo je maj
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 4, "VA1", "10:30", "12:00");
      var broj = 0;
      var sale = document.getElementsByClassName('zauzeta');
      for(var i = 0; i < sale.length; ++i) {
        if(sale[i].innerHTML != " ") broj++;
      }
      assert.equal(broj, 0);
    });

    it('Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivanoje da se ne oboji zauzeće', function() { 
      reset1(); //funkcija koja vrati sve na slobodno
      Kalendar.ucitajPodatke([{dan : 0, semestar : 'ljetni', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}, {dan : 0, semestar : 'ljetni', pocetak : '13:00', kraj : '15:30', naziv : 'VA1', predavac : 'predavac1'}], []);
      Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 1); 
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 1, "VA1", "10:30", "12:00");
      var broj = 0;
      var sale = document.getElementsByClassName('zauzeta');
      for(var i = 0; i < sale.length; ++i) {
        if(sale[i].innerHTML != " ") broj++;
      }
      assert.equal(broj, 0);
    });

    it('Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina:očekivano je da se dan oboji bez obzira što postoje duple vrijednosti', function() { 
      Kalendar.ucitajPodatke([{dan : 0, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}, {dan : 0, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}], []);
      Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 9);
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 9, "VA1", "10:30", "12:00");
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 9, "VA1", "10:30", "12:00");
      var broj = 0;
      var sale = document.getElementsByClassName('zauzeta');
      for(var i = 0; i < sale.length; ++i) {
        if(sale[i].innerHTML != " ") broj++;
      }
      assert.equal(broj, 4);
    });

    it('Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina:očekivano je da se dan oboji bez obzira što postoje duple vrijednosti', function() { 
      Kalendar.ucitajPodatke([{dan : 0, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}, {dan : 0, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}], []);
      Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 9);
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 9, "VA1", "10:30", "12:00");
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 9, "VA1", "10:30", "12:00");
      var broj = 0;
      var sale = document.getElementsByClassName('zauzeta');
      for(var i = 0; i < sale.length; ++i) {
        if(sale[i].innerHTML != " ") broj++;
      }
      assert.equal(broj, 4);
    });


    it('Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi dani oboje', function() { 
      Kalendar.ucitajPodatke([{dan : 0, semestar : 'zimski', pocetak : '00:00', kraj : '23:59', naziv : 'VA1', predavac : 'predavac1'}, 
      {dan : 1, semestar : 'zimski', pocetak : '00:00', kraj : '23:59', naziv : 'VA1', predavac : 'predavac1'},
      {dan : 2, semestar : 'zimski', pocetak : '00:00', kraj : '23:59', naziv : 'VA1', predavac : 'predavac1'},
      {dan : 3, semestar : 'zimski', pocetak : '00:00', kraj : '23:59', naziv : 'VA1', predavac : 'predavac1'},
      {dan : 4, semestar : 'zimski', pocetak : '00:00', kraj : '23:59', naziv : 'VA1', predavac : 'predavac1'},
      {dan : 5, semestar : 'zimski', pocetak : '00:00', kraj : '23:59', naziv : 'VA1', predavac : 'predavac1'},
      {dan : 6, semestar : 'zimski', pocetak : '00:00', kraj : '23:59', naziv : 'VA1', predavac : 'predavac1'},    ], []);
      Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 10); 
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 10, "VA1", "10:30", "12:00");
      var broj = 0;
      var sale = document.getElementsByClassName('slobodna');
      for(var i = 0; i < sale.length; ++i) {
        if(sale[i].innerHTML != " ") broj++;
      }
      reset1();
      assert.equal(broj, 0);
    });

    it('Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: očekivano da sezauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podaci', function() { 
      Kalendar.ucitajPodatke([{dan : 0, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}], []);
      Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 9);
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 9, "VA1", "10:30", "12:00");
      Kalendar.ucitajPodatke([{dan : 1, semestar : 'zimski', pocetak : '10:00', kraj : '11:30', naziv : 'VA1', predavac : 'predavac1'}], []);
      Kalendar.iscrtajKalendar(document.getElementsByClassName('kalendar')[0], 9);
      Kalendar.obojiZauzeca(document.getElementsByClassName('kalendar')[0], 9, "VA1", "10:30", "12:00");
      var broj = 0;
      var sale = document.getElementsByClassName('zauzeta');
      for(var i = 0; i < sale.length; ++i) {
        if(sale[i].innerHTML != " ") broj++;
      }
      assert.equal(broj, 5);
    });
  });
});

var brojSlike = 3;
var brojKlikaDugmeta = 0;
var slike;
Pozivi.ucitajSliku((res) => {
    slike = res;
    if(brojKlikaDugmeta == 0) {
        document.getElementById("slika1").src = "./Images/" + slike.slika1.toString() + ".jpg";
        document.getElementById("slika2").src = "./Images/" + slike.slika2.toString() + ".jpg";
        document.getElementById("slika3").src = "./Images/" + slike.slika3.toString() + ".jpg";
    } 
    if(brojKlikaDugmeta == 1) {
        document.getElementById("slika1").src = "./Images/" + slike.slika4.toString() + ".jpg";
        document.getElementById("slika2").src = "./Images/" + slike.slika5.toString() + ".jpg";
        document.getElementById("slika3").src = "./Images/" + slike.slika6.toString() + ".jpg";
    } 
    if(brojKlikaDugmeta == 2) {
        document.getElementById("slika1").src = "./Images/" + slike.slika7.toString() + ".jpg";
        document.getElementById("slika2").src = "./Images/" + slike.slika8.toString() + ".jpg";
        document.getElementById("slika3").src = "./Images/" + slike.slika9.toString() + ".jpg";
    } 
    if(brojKlikaDugmeta == 3) {
        document.getElementById("slika1").src = "./Images/" + slike.slika10.toString() + ".jpg";
        document.getElementById("slika2").src = "";
        document.getElementById("slika2").alt = "";
    //    document.getElementById("slika2").setAttribute("alt=", " " );
        document.getElementById("slika3").src = "";
        document.getElementById("slika3").alt = "";
    //    document.getElementById("slika3").setAttribute("alt=", " " );
    }
});
function sljedeci() {
    document.getElementById("sljedeci").disabled = false;
    document.getElementById("prethodni").disabled = false;
    if(brojKlikaDugmeta == 3) {
        document.getElementById("sljedeci").disabled = true;
        document.getElementById("prethodni").disabled = false;
    }
    brojKlikaDugmeta++;
    Pozivi.ucitajSliku((res) => {
        slike = res;
        if(brojKlikaDugmeta == 0) {
            document.getElementById("slika1").src = "./Images/" + slike.slika1.toString() + ".jpg";
            document.getElementById("slika2").src = "./Images/" + slike.slika2.toString() + ".jpg";
            document.getElementById("slika3").src = "./Images/" + slike.slika3.toString() + ".jpg";
        } 
        if(brojKlikaDugmeta == 1) {
            document.getElementById("slika1").src = "./Images/" + slike.slika4.toString() + ".jpg";
            document.getElementById("slika2").src = "./Images/" + slike.slika5.toString() + ".jpg";
            document.getElementById("slika3").src = "./Images/" + slike.slika6.toString() + ".jpg";
        } 
        if(brojKlikaDugmeta == 2) {
            document.getElementById("slika1").src = "./Images/" + slike.slika7.toString() + ".jpg";
            document.getElementById("slika2").src = "./Images/" + slike.slika8.toString() + ".jpg";
            document.getElementById("slika3").src = "./Images/" + slike.slika9.toString() + ".jpg";
        } 
        if(brojKlikaDugmeta == 3) {
            document.getElementById("slika1").src = "./Images/" + slike.slika10.toString() + ".jpg";
            document.getElementById("slika2").src = "";
            document.getElementById("slika2").alt = "";
            //document.getElementById("slika2").setAttribute("alt=", " " );
            document.getElementById("slika3").src = "";
           // document.getElementById("slika3").setAttribute("alt=", " " );
            document.getElementById("slika3").alt = "";
        }
    });
}
function prethodni() {
    document.getElementById("sljedeci").disabled = false;
    document.getElementById("prethodni").disabled = false;
    if(brojKlikaDugmeta == 0) {
        document.getElementById("prethodni").disabled = true;
        document.getElementById("sljedeci").disabled = false;
    }
    brojKlikaDugmeta--;
    Pozivi.ucitajSliku((res) => {
        slike = res;
        if(brojKlikaDugmeta == 0) {
            document.getElementById("slika1").src = "./Images/" + slike.slika1.toString() + ".jpg";
            document.getElementById("slika2").src = "./Images/" + slike.slika2.toString() + ".jpg";
            document.getElementById("slika3").src = "./Images/" + slike.slika3.toString() + ".jpg";
        } 
        if(brojKlikaDugmeta == 1) {
            document.getElementById("slika1").src = "./Images/" + slike.slika4.toString() + ".jpg";
            document.getElementById("slika2").src = "./Images/" + slike.slika5.toString() + ".jpg";
            document.getElementById("slika3").src = "./Images/" + slike.slika6.toString() + ".jpg";
        } 
        if(brojKlikaDugmeta == 2) {
            document.getElementById("slika1").src = "./Images/" + slike.slika7.toString() + ".jpg";
            document.getElementById("slika2").src = "./Images/" + slike.slika8.toString() + ".jpg";
            document.getElementById("slika3").src = "./Images/" + slike.slika9.toString() + ".jpg";
        } 
        if(brojKlikaDugmeta == 3) {
            document.getElementById("slika1").src = "./Images/" + slike.slika10.toString() + ".jpg";
            document.getElementById("slika2").src = "";
            document.getElementById("slika2").alt = "";
         //   document.getElementById("slika2").setAttribute("alt=", " " );
            document.getElementById("slika3").src = "";
            document.getElementById("slika3").alt = "";
         //   document.getElementById("slika3").setAttribute("alt=", " " );
        }
    });
}
let Pozivi = (function () {
    function ucitajZauzecaImpl (ucitajZauzeca) {
        var ajax = new XMLHttpRequest();
        ajax.open("GET", "http://localhost:8080/zauzeca.json", true);
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4 && ajax.status == 200) {
                var zauzeca = JSON.parse(ajax.responseText);
             //   console.log(zauzeca);
                ucitajZauzeca(zauzeca);
            }
        };
        ajax.send();
    }

    function mjesecConvert(mjesec) {
        switch(mjesec) {
            case "Januar":
                mjesec = 0;
                break;
            case "Februar":
                mjesec = 1;
                break;
            case "Mart":
                mjesec = 2;
                break;                
            case "April":
                mjesec = 3;
                break;
            case "Maj":
                mjesec = 4;
                break;
            case "Juni":
                mjesec = 5;
                break;
            case "Juli":
                mjesec = 6;
                break;
            case "August":
                mjesec = 7;
                break;
            case "Septembar":
                mjesec = 8;
                break;
            case "Oktobar":
                mjesec = 9;
                break;
            case "Novembar":
                mjesec = 10;
                break;
            case "Decembar":
                mjesec = 11;
                break;             
        }
        return mjesec++;
    }

    function odabranDanImpl(id) {
        var dan = id;
        var mjesec = document.getElementsByClassName("mjesecIme")[0].innerHTML;
        mjesec = mjesecConvert(mjesec);
        mjesec++;
        
        var datum;
        
        var sale = document.getElementById('listaSala');
        var selektovanaSala = sale.options[sale.selectedIndex].text;
        var pocetakRez = document.getElementById('pocetakRezervacije').value;
        var krajRez = document.getElementById('krajRezervacije').value;
        var checkbox = document.getElementsByName('periodicnost');

        if(dan > 9) {
            datum = dan + "." + mjesec + ".2019";
        }
        else {
            datum = "0" + dan + "." + mjesec + ".2019"
        }
        var odgovor;
       /* if(id > 9) odgovor = {
            datum: dan + "." + mjesec + ".2019", 
            sala: selektovanaSala, 
            pocetak: pocetakRez, 
            kraj: krajRez, 
            periodicnost: checkbox[0].checked};
        else odgovor = {
            datum: "0" + dan + "." + mjesec + ".2019", 
            sala: selektovanaSala, 
            pocetak: pocetakRez, 
            kraj: krajRez, 
            periodicnost: checkbox[0].checked};*/

        if(checkbox[0].checked) {
            var danPovr = (id) % 7;
            if(mjesec >= 9 || mjesec == 1) {
                odgovor = {
                    dan: "" + danPovr + "",
                    semestar: "zimski",
                    pocetak: pocetakRez,
                    kraj: krajRez,
                    naziv: selektovanaSala,
                    predavac: "zaSadNepoznat"
                };
            }
            else if(mjesec >= 2 && mjesec <= 6) {
                odgovor = {
                    dan: "" + danPovr + "",
                    semestar: "ljetni",
                    pocetak: pocetakRez,
                    kraj: krajRez,
                    naziv: selektovanaSala,
                    predavac: "zaSadNepoznat"
                };
            }
        }
        else {
            if(id > 9) {
                odgovor = {
                    datum: id + "." + mjesec + ".2019",
                    pocetak: pocetakRez,
                    kraj: krajRez,
                    naziv: selektovanaSala,
                    predavac: "zaSadNepoznat"
                };
            }
            else {
                odgovor = {
                    datum: "0" + id + "." + mjesec + ".2019",
                    pocetak: pocetakRez,
                    kraj: krajRez,
                    naziv: selektovanaSala,
                    predavac: "zaSadNepoznat"
                };
            }
            
        }
        var rezultat = confirm("Jeste li sigurni da zelite ovu rezervaciju?");
        if(rezultat) {
            var ajax = new XMLHttpRequest();
            ajax.open("POST", "http://localhost:8080/zauzeca.json", true);
            ajax.setRequestHeader("Content-Type", "application/json");
           // "datum=" + datum + "sala=" + selektovanaSala + "pocetak=" + pocetakRez + "kraj=" + krajRez + "periodicnost=" + checkbox[0].checked;
            ajax.send(JSON.stringify(odgovor));
        //    console.log("Tekst je " + ajax.responseType);
            //Pozivi.ucitajZauzeca(JSON.stringify(odgovor));
        }

        ajax.onreadystatechange = function() {// Anonimna funkcija
            //console.log(ajax.responseText);
            if(ajax.responseText.toString() == "\"Nije moguće\"") {
                alert("Nije moguće rezervisati salu " + selektovanaSala + " za navedeni datum " + datum + " i termin od " + pocetakRez + " do " + krajRez + "!");
            //    console.log("Vracena poruka");
            }
                //alert(ajax.responseText);
        };
       /* if() {
            }

       /* console.log(datum);
        console.log(selektovanaSala);
        console.log(pocetakRez);
        console.log(krajRez);
        if(checkbox[0].checked) {
            console.log("periodican");
        }
        else console.log("vanredan");*/
    }



    function ucitajSlikuImpl(ucitajSliku) {
     //   console.log("Poslao zahtjev");
        var ajax = new XMLHttpRequest();
        var slike;
        ajax.open("GET", "http://localhost:8080/slike.json", true);
    //    console.log("http://localhost:8080/Images/Slika" + slika + ".jpg");
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4 && ajax.status == 200) {
                slike = JSON.parse(ajax.responseText);
                ucitajSliku(slike);
            }
        };
        ajax.send();
    }

    return {
        ucitajZauzeca: ucitajZauzecaImpl,
        odabranDan : odabranDanImpl,
        ucitajSliku : ucitajSlikuImpl
    }
}());
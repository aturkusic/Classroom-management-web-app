// kalendarRef je body tabele za kalendar

let danas = new Date();
let trenutniMjesec = danas.getMonth();
let trenutnaGodina = danas.getFullYear();
let kalendarRef = document.getElementById("kalendar-tabela").getElementsByTagName("tbody")[0];
let prethodniMjesecButton = document.getElementById("prethodni-btn");
let sljedeciMjesecButton = document.getElementById("sljedeci-btn");

var Kalendar = (function () {
  let periodicnaZauzeca;
  let vanrednaZauzeca;
  const mjeseci = [
    "Januar",
    "Februar",
    "Mart",
    "April",
    "Maj",
    "Juni",
    "Juli",
    "August",
    "Septembar",
    "Oktobar",
    "Novembar",
    "Decembar"
  ];

  var ucitajPodatke = function (periodicna, vanredna) {
    periodicnaZauzeca = periodicna;
    vanrednaZauzeca = vanredna;
  };

  var obojiZauzeca = function (kalendarRef, mjesec, sala, vrijemePocetka, vrijemeKraja) {
    if (!periodicnaZauzeca && !vanrednaZauzeca) {
      return;
    }

    let dani = kalendarRef.getElementsByTagName("td");

    // Dodavanje klase slobodnaSala za sve sale
    for (let i = 0; i < dani.length; i++) {
      if (dani[i].innerText !== "") {
        dani[i].getElementsByTagName("div")[0].classList.add("slobodnaSala");
      }
    }

    // Bojenje zauzeca za periodicna zauzeca
    for (let i = 0; i < periodicnaZauzeca.length; i++) {
      if (periodicnaZauzeca[i].naziv === sala) {
        let danZauzeca = periodicnaZauzeca[i].dan;
        dani = kalendarRef.getElementsByTagName("td");

        if (periodicnaZauzeca[i].semestar === dajSemestar(mjesec)) {
          while (danZauzeca < dani.length) {
            if (dani[danZauzeca].innerText !== "") {
              if (poklapanjeTermina(periodicnaZauzeca[i].pocetak, periodicnaZauzeca[i].kraj, vrijemePocetka, vrijemeKraja)) {
                dani[danZauzeca].getElementsByTagName("div")[0].classList.add("zauzetaSala");
                dani[danZauzeca].getElementsByTagName("div")[0].classList.remove("slobodnaSala");
              }
            }
            danZauzeca += 7;
          }
        }
      }
    }

    // Bojenje zauzeca za vanredna zauzeca
    for (let i = 0; i < vanrednaZauzeca.length; i++) {
      if (vanrednaZauzeca[i].naziv === sala) {
        const danMjesecGodina = vanrednaZauzeca[i].datum.split(".");
        let datum = new Date(danMjesecGodina[2], danMjesecGodina[1] - 1, danMjesecGodina[0]);

        if (datum instanceof Date) {
          dani = kalendarRef.getElementsByTagName("td");

          if (datum.getMonth() === mjesec) {
            let danZauzeca = datum.getDate();

            for (let j = 0; j < dani.length; j++) {
              if (dani[j].innerText === danZauzeca.toString() &&
                poklapanjeTermina(vanrednaZauzeca[i].pocetak, vanrednaZauzeca[i].kraj, vrijemePocetka, vrijemeKraja)) {
                dani[j].getElementsByTagName("div")[0].classList.remove("slobodnaSala");
                dani[j].getElementsByTagName("div")[0].classList.add("zauzetaSala");
              }
            }
          }
        }
      }
    }
  }

  function dajSemestar(mjesec) {
    if (mjesec >= 6 && mjesec < 9) {
      return null;
    } else if (mjesec >= 1 && mjesec < 6) {
      return "ljetni";
    } else {
      return "zimski";
    }
  }

  function poklapanjeTermina(pocetak, kraj, pocetakForma, krajForma) {
    let pocetakSat = pocetak.split(":")[0];
    let pocetakMinute = pocetak.split(":")[1];
    let krajSat = kraj.split(":")[0];
    let krajMinute = kraj.split(":")[1];

    let pocetakSatForma = pocetakForma.toString().split(":")[0];
    let pocetakMinuteForma = pocetakForma.toString().split(":")[1];
    let krajSatForma = krajForma.toString().split(":")[0];
    let krajMinuteForma = krajForma.toString().split(":")[1];

    // Kreiranje datuma za laksu provjeru poklapanja intervala
    let pocetakDate = new Date(2020, 1, 1, pocetakSat, pocetakMinute);
    let krajDate = new Date(2020, 1, 1, krajSat, krajMinute);
    let pocetakFormaDate = new Date(2020, 1, 1, pocetakSatForma, pocetakMinuteForma);
    let krajFormaDate = new Date(2020, 1, 1, krajSatForma, krajMinuteForma);

    if ((pocetakFormaDate >= pocetakDate && pocetakFormaDate < krajDate)
      || (krajFormaDate > pocetakDate && krajFormaDate <= krajDate)
      || (pocetakFormaDate <= pocetakDate && krajFormaDate >= krajDate)
      || (pocetakFormaDate >= pocetakDate && krajFormaDate <= krajDate)) {
      return true;
    } else {
      return false;
    }
  }

  var iscrtajKalendar = function (kalendarRef, mjesec) {
    let godina = new Date().getFullYear();
    kalendarRef.innerHTML = "";

    // Dodavanje mjeseca i godine u header tabele
    let godinaMjesec = document.getElementById("mjesec-godina");
    godinaMjesec.innerText = mjeseci[trenutniMjesec] + " " + trenutnaGodina;
    let prviDan = new Date(godina, mjesec).getDay();
    prviDan = prviDan === 0 ? 6 : prviDan - 1;
    let dan = 1;

    for (let i = 0; i < 6; i++) {
      let red = document.createElement("tr");

      for (let j = 0; j < 7; j++) {
        if (dan > dajBrojDana(godina, mjesec)) {
          break;
        } else {
          let celija = document.createElement("td");
          celija.addEventListener('click', handleSalaClick);
          let zauzetaSlobodnaDiv = document.createElement("div");
          let celijaText;

          if (i === 0 && j < prviDan) {
            celijaText = document.createTextNode("");
          } else {
            celijaText = document.createTextNode(dan);
            dan++;
          }

          celija.appendChild(celijaText);
          celija.appendChild(zauzetaSlobodnaDiv);
          red.appendChild(celija);
        }
      }

      kalendarRef.appendChild(red);
    }
  };

  var dajTrenutniMjesec = function() {
    return trenutniMjesec;
  }

  return {
    obojiZauzeca: obojiZauzeca,
    ucitajPodatke: ucitajPodatke,
    iscrtajKalendar: iscrtajKalendar,
    dajTrenutniMjesec: dajTrenutniMjesec
  };
})();

function dajBrojDana(godina, mjesec) {
  return 32 - new Date(godina, mjesec, 32).getDate();
}

function sljedeciMjesec() {
  if (trenutniMjesec < 11) {
    trenutniMjesec++;
    prethodniMjesecButton.disabled = false;
    prethodniMjesecButton.style.background = "white";
    prethodniMjesecButton.style.color = "darkcyan";
  }

  if (trenutniMjesec === 11) {
    sljedeciMjesecButton.disabled = true;
    sljedeciMjesecButton.style.background = "grey";
    sljedeciMjesecButton.style.color = "white";
  }

  osvjeziKalendar();
}

function prethodniMjesec() {
  if (trenutniMjesec > 0) {
    trenutniMjesec--;
    sljedeciMjesecButton.disabled = false;
    sljedeciMjesecButton.style.background = "white";
    sljedeciMjesecButton.style.color = "darkcyan";
  }

  if (trenutniMjesec === 0) {
    prethodniMjesecButton.disabled = true;
    prethodniMjesecButton.style.background = "grey";
    prethodniMjesecButton.style.color = "white";
  }

  osvjeziKalendar();
}

function osvjeziKalendar() {
  Kalendar.iscrtajKalendar(kalendarRef, trenutniMjesec);
  Kalendar.obojiZauzeca(
    kalendarRef,
    trenutniMjesec,
    saleSelect.options[saleSelect.selectedIndex].value,
    pocetakInput.value,
    krajInput.value
  );
}

$(document).ready(() => {
    Pozivi.ucitajZauzeca(ucitajZauzeca);
});

let saleSelect = document.getElementById("sale-select");
let pocetakInput = document.getElementById("pocetak-input");
let krajInput = document.getElementById("kraj-input");
let periodicnoInput = document.getElementById("periodicno-input");
let porukaDiv = document.getElementById('poruka');
let selektovaniDatum;
let datum;

function ucitajZauzeca(zauzeca) {
    Kalendar.iscrtajKalendar(kalendarRef, new Date().getMonth());
    Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
    Kalendar.obojiZauzeca(
        kalendarRef,
        trenutniMjesec,
        saleSelect.options[saleSelect.selectedIndex].value,
        pocetakInput.value,
        krajInput.value
    );
}

function handleFormChange() {
    obrisiPoruke();

    Kalendar.obojiZauzeca(
        kalendarRef,
        trenutniMjesec,
        saleSelect.options[saleSelect.selectedIndex].value,
        pocetakInput.value,
        krajInput.value
    );
}

function handleSalaClick(event) {
    obrisiPoruke();

    if (selektovaniDatum) {
        selektovaniDatum.classList.remove('selektovan');
    }

    if (event.target.localName === 'td') {
        selektovaniDatum = event.target;
        selektovaniDatum.classList.add('selektovan');
    } else {
        datum = event.target.parentElement.innerText;
        selektovaniDatum = event.target.parentElement;
        selektovaniDatum.classList.add('selektovan');
    }
}

function handleSubmit() {
    let poruka = provjeriPodatke(pocetakInput.value, krajInput.value, selektovaniDatum);

    if (poruka) {
        window.alert(poruka);
    } else {
        let odabirKorisnika = window.confirm("Da li želite rezervisati salu?\n"
            + "\nSala: " + saleSelect.options[saleSelect.selectedIndex].value
            + "\nPočetak: " + pocetakInput.value
            + "\nKraj: " + krajInput.value
            + "\nPeriodično: " + (periodicnoInput.checked ? "da" : "ne"));

        if (odabirKorisnika) {
            let zauzece = {
                datum: selektovaniDatum.innerText + '.' + (Kalendar.dajTrenutniMjesec() + 1) + '.' + 2020,
                pocetak: pocetakInput.value,
                kraj: krajInput.value,
                naziv: saleSelect.options[saleSelect.selectedIndex].value,
                predavac: ""
            }

            Pozivi.spremiZauzece(zauzece, ispisiPoruku);
        }
    }
}

function ispisiPoruku(status, poruka) {
    obrisiPoruke();
    porukaDiv.innerText = poruka;
    
    if (status === 200) {
        porukaDiv.classList.add('uspjesno');
    }
    else {
        porukaDiv.classList.add('greska');
    }

    Pozivi.ucitajZauzeca(ucitajZauzeca);
}

function obrisiPoruke() {
    porukaDiv.classList.remove('uspjesno');
    porukaDiv.classList.remove('greska');
    porukaDiv.innerText = '';
}

function provjeriPodatke(pocetak, kraj, selektovaniDatum) {
    let pocetakSat = pocetak.split(":")[0];
    let pocetakMinute = pocetak.split(":")[1];
    let krajSat = kraj.split(":")[0];
    let krajMinute = kraj.split(":")[1];

    if (!pocetakSat || !pocetakMinute) {
        return "Niste unijeli pocetno vrijeme rezervacije.";
    } else if (!krajSat || !krajMinute) {
        return "Niste unijeli vrijeme kraja rezervacije."
    } else if (!selektovaniDatum) {
        return "Niste selektovali datum."
    } else if (selektovaniDatum.children[0].classList.contains('zauzetaSala')) {
        return "Sala je zauzeta, molimo selektujte drugi datum ili drugo vrijeme.";
    } else {
        return "";
    }
}

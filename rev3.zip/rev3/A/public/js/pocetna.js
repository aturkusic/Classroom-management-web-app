$(document).ready(() => {
    Pozivi.ucitajPosjete(prikaziPosjete);
});

function prikaziPosjete(posjete) {
    let posjeteDiv = document.getElementById('posjete');
    posjeteDiv.innerText = "POSJETE\n" + "Chrome: " + posjete.chrome + "\nMozilla: " + posjete.mozilla
    + "\nBroj različitih ip adresa: " + posjete.ip.length;
}

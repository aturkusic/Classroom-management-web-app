const express = require('express');
const path = require('path');
const app = express();
const bodyParser = require('body-parser');
const fs = require('fs')
const useragent = require('useragent');

app.use(bodyParser.urlencoded());
app.use(express.static('public'));

app.get('/', (req, res) => {
    upisiPosjetu(req.get('User-Agent'), req.connection.remoteAddress);
    res.sendFile(path.resolve('public/pocetna.html'));
});

app.get('/zauzeca', (req, res) => {
    res.sendFile(path.resolve('zauzeca.json'));
});

app.get('/posjete', (req, res) => {
    res.sendFile(path.resolve('posjete.json'));
});


app.post('/zauzeca/spremi', (req, res) => {
    let zauzece = req.body.zauzece;

    if (zauzece) {
        if (!provjeriZauzece(zauzece)) {
            upisiZauzece(zauzece);
            res.status(200).json({ status: 200, poruka: "Uspješno spremljeno zauzeće!" });
        } else {
            res.status(409).json({
                poruka: "Nije moguće rezervisati salu " + zauzece.naziv + " za navedeni datum "
                    + zauzece.datum + " i termin od " + zauzece.pocetak + " do " + zauzece.kraj + "!"
            });
        }
    }
});

// Vraća true ako postoji poklapanje sa postojećim zauzećem
function provjeriZauzece(zauzece) {
    let json = JSON.parse(fs.readFileSync('zauzeca.json', 'utf8'));

    if (zauzece.dan) {

    } else {
        let vanredna = json.vanredna;

        for (let i = 0; i < vanredna.length; i++) {
            if (vanredna[i].datum === zauzece.datum
                && poklapanjeTermina(vanredna[i].pocetak, vanredna[i].kraj, zauzece.pocetak, zauzece.kraj)) {
                return true;
            }
        }
    }

    return false;
}

function poklapanjeTermina(pocetak, kraj, pocetakForma, krajForma) {
    let pocetakSat = pocetak.split(":")[0];
    let pocetakMinute = pocetak.split(":")[1];
    let krajSat = kraj.split(":")[0];
    let krajMinute = kraj.split(":")[1];

    let pocetakSatForma = pocetakForma.toString().split(":")[0];
    let pocetakMinuteForma = pocetakForma.toString().split(":")[1];
    let krajSatForma = krajForma.toString().split(":")[0];
    let krajMinuteForma = krajForma.toString().split(":")[1];

    // Kreiranje datuma za laksu provjeru poklapanja intervala
    let pocetakDate = new Date(2020, 1, 1, pocetakSat, pocetakMinute);
    let krajDate = new Date(2020, 1, 1, krajSat, krajMinute);
    let pocetakFormaDate = new Date(2020, 1, 1, pocetakSatForma, pocetakMinuteForma);
    let krajFormaDate = new Date(2020, 1, 1, krajSatForma, krajMinuteForma);

    if ((pocetakFormaDate >= pocetakDate && pocetakFormaDate < krajDate)
        || (krajFormaDate > pocetakDate && krajFormaDate <= krajDate)
        || (pocetakFormaDate <= pocetakDate && krajFormaDate >= krajDate)
        || (pocetakFormaDate >= pocetakDate && krajFormaDate <= krajDate)) {
        return true;
    } else {
        return false;
    }
}

function upisiZauzece(zauzece) {
    fs.readFile('zauzeca.json', function (err, data) {
        let json = JSON.parse(data)

        if (zauzece.dan) {
            json.periodicna.push(zauzece);
        }
        else {
            json.vanredna.push(zauzece);
        }

        fs.writeFile('zauzeca.json', JSON.stringify(json), () => { });
    });
}

function upisiPosjetu(userAgent, ip) {
    let json = JSON.parse(fs.readFileSync('posjete.json', 'utf8'));

    if (useragent.is(userAgent).chrome) {
        json.chrome++;
    }

    if (useragent.is(userAgent).firefox) {
        json.mozilla++;
    }

    // Ukoliko vec ne postoji dodaje ip adresu
    // IP adresa će biti u formatu ::broj ukoliko je sever na local hostu
    if (!json.ip.find(item => item === ip)) {
        json.ip.push(ip);
    }

    fs.writeFile('posjete.json', JSON.stringify(json), () => { });
}

app.listen(8080, () => {
    console.log('Server started at http://localhost:8080/');
})

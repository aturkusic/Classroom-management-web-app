var Pozivi = (function () {
    var ucitajZauzeca = function (callbackFunction) {
        $.ajax({
            url: '/zauzeca',
            type: 'GET',
            dataType: 'json',
            success: (data) => callbackFunction(data)
        });
    }

    var ucitajPosjete = function (callbackFunction) {
        $.ajax({
            url: '/posjete',
            type: 'GET',
            dataType: 'json',
            success: (data) => callbackFunction(data)
        });
    }

    var spremiZauzece = function (zauzece, callbackFunction) {
        $.ajax({
            url: '/zauzeca/spremi',
            type: 'POST',
            dataType: 'json',
            data: { zauzece: zauzece },
            success: (data) => callbackFunction(data.status, data.poruka),
            error: (data) => callbackFunction(data.status, data.responseJSON.poruka)
        });
    }

    return {
        ucitajZauzeca: ucitajZauzeca,
        spremiZauzece: spremiZauzece,
        ucitajPosjete: ucitajPosjete
    };
})();

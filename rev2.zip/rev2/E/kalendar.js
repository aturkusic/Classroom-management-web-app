

const Mjeseci = {
  0: "Januar",
  1: "Februar",
  2: "Mart",
  3: "April",
  4: "Maj",
  5: "Juni",
  6: "Juli",
  7: "August",
  8: "Septembar",
  9: "Oktobar",
  10: "Novembar",
  11: "Decembar"
};

const periodicnaTmp = [
  {
    dan: 1,
    semestar: "zimski",
    pocetak: "11:22",
    kraj: "12:33",
    naziv: "Naziv",
    predavac: "Rukf"
  },
  {
    dan: 2,
    semestar: "zimski",
    pocetak: "11:22",
    kraj: "16:33",
    naziv: "Naziv",
    predavac: "Rukf"
  },
  {
    dan: 2,
    semestar: "ljetni",
    pocetak: "11:00",
    kraj: "12:30",
    naziv: "Naziv",
    predavac: "Bilder"
  },
  {
    dan: 3,
    semestar: "ljetni",
    pocetak: "9:00",
    kraj: "11:25",
    naziv: "Naziv",
    predavac: "Hasnija"
  },
  {
    dan: 4,
    semestar: "ljetni",
    pocetak: "8:00",
    kraj: "23:00",
    naziv: "Naziv",
    predavac: "Rukf"
  }
];

const vanrednaTmp = [
  {
    datum: "01.03.2019",
    pocetak: "12:00",
    kraj: "13:00",
    naziv: "string",
    predavac: "Husko"
  },
  {
    datum: "25.02.2019",
    pocetak: "15:30",
    kraj: "17:00",
    naziv: "string",
    predavac: "string"
  },
  {
    datum: "12.03.2019",
    pocetak: "13:00",
    kraj: "23:00",
    naziv: "string",
    predavac: "string"
  },
  {
    datum: "01.01.2019",
    pocetak: "16:00",
    kraj: "18:00",
    naziv: "Novogodisnje avanture",
    predavac: "Cizi"
  },
  {
    datum: "21.11.2019",
    pocetak: "11:22",
    kraj: "13:22",
    naziv: "string",
    predavac: "string"
  }
];

const danasnjiDatum = new Date(Date.now());

let zauzecaSala = [];
for (var i = 0; i < 12; i++) {
  const daniUMjesecu = [];
  const brojDana = dajBrojDana(i, danasnjiDatum.getFullYear());
  for (var j = 0; j < brojDana; j++)
    daniUMjesecu.push([]);
  zauzecaSala.push(daniUMjesecu);
}

let mjesecKojiSePrikazuje = 10;

function sljedeciMjesec() {
  if (mjesecKojiSePrikazuje === 11) return;
  mjesecKojiSePrikazuje += 1;
  Kalendar.iscrtajKalendar(
    document.getElementById("kalendar"),
    mjesecKojiSePrikazuje
  );
}

function prethodniMjesec() {
  if (mjesecKojiSePrikazuje === 0) return;
  mjesecKojiSePrikazuje -= 1;
  Kalendar.iscrtajKalendar(
    document.getElementById("kalendar"),
    mjesecKojiSePrikazuje
  );
}

function dajBrojDana(mjesec, godina) {
  return 32 - new Date(godina, mjesec, 32).getDate();
}

var Kalendar = (function() {
  // ovdje idu privatni atributi

  function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {
    //implementacija ide ovdje
    // mjesec = mjesec - 1;

    console.log("POZIVA SE FUNKCIJA ZAUZECA", zauzecaSala[mjesec]);
    console.log('ZAUZECAAAA', mjesec, sala, pocetak, kraj)
    let prviDan = new Date(danasnjiDatum.getFullYear(), mjesec, 1).getDay();
    prviDan = prviDan ? prviDan : 7;
    const brojDana = dajBrojDana(mjesec, danasnjiDatum.getFullYear());
    for (let i = 1; i < brojDana + prviDan; i++) {

      if(i >= prviDan) {
        let jeLiZauzeta = false;
        if(zauzecaSala[mjesec][i - prviDan] && zauzecaSala[mjesec][i - prviDan]){
          zauzecaSala[mjesec][i - prviDan].forEach((zauzece)=>{
            console.log('ZAUZECEEE', zauzece, pocetak, kraj)
              if(pocetak){
                if(zauzece.pocetak === pocetak)
                  jeLiZauzeta = true; 
                else
                  jeLiZauzeta = false;
              }
              if(kraj){
                if(zauzece.kraj === kraj)
                  jeLiZauzeta = true;
                else
                  jeLiZauzeta = false;
              }
                
              // if(sala && zauzece.sala === sala)
              //   jeLiZauzeta = true;
              // else
              //   jeLiZauzeta = false;
          });
        }
        // console.log('djksjd', 'sala-'+mjesec+'-'+(i-prviDan))
       let divSala = document.getElementById('sala-'+mjesec+'-'+(i-prviDan));
       divSala.className = jeLiZauzeta ? "zauzeta" : "slobodna";
      }
    }
  }
  function ucitajPodatkeImpl(periodicna, vanredna) {
    //resetovanje niza zauzeca sala
    zauzecaSala = []
    for (var i = 0; i < 12; i++) {
      const daniUMjesecu = [];
      const brojDana = dajBrojDana(i, danasnjiDatum.getFullYear());
      for (var j = 0; j < brojDana; j++)
        daniUMjesecu.push([]);
      zauzecaSala.push(daniUMjesecu);
    }


    if(periodicna && periodicna.length)
        for (var i = 0; i < periodicna.length; i++) {
        const semestar = periodicna[i].semestar;
        const dan = periodicna[i].dan;

        let mjeseci = [];
        if (semestar === "zimski") mjeseci = [0, 9, 10, 11];
        else if (semestar === "ljetni")
            mjeseci = [1, 2, 3, 4, 5];

        mjeseci.forEach(mjesec => {
            let prviDanMjeseca = new Date(
            danasnjiDatum.getFullYear(),
            mjesec,
            1
            ).getDay();
            prviDanMjeseca = prviDanMjeseca ? prviDanMjeseca - 1 : 6;
            let a = dan - prviDanMjeseca;
            if (prviDanMjeseca > dan) a = 7 - prviDanMjeseca + dan;
            zauzecaSala[mjesec].forEach((element, index) => {
            if (index === a) {
                a += 7;
                let pomocniElement = {}
                pomocniElement.zauzeta = true;
                pomocniElement.pocetak = periodicna[i].pocetak;
                pomocniElement.kraj = periodicna[i].kraj;
                pomocniElement.naziv = periodicna[i].naziv;
                pomocniElement.predavac = periodicna[i].predavac;
                element.push(pomocniElement);
            }
            });
        });
        }
    if(vanredna && vanredna.length)
        for(var i = 0; i < vanredna.length; i++){
          console.log('VANREDNA', vanredna);
            let datumString = vanredna[i].datum;
            datumString = datumString.substr(3,2) + '.' + datumString.substr(0,2) + '.' + datumString.substr(6)
            const datum = new Date(datumString);
            let pomocniElement = {}
            pomocniElement.zauzeta = true;
            pomocniElement.pocetak = vanredna[i].pocetak;
            pomocniElement.kraj = vanredna[i].kraj;
            pomocniElement.naziv = vanredna[i].naziv;
            pomocniElement.predavac = vanredna[i].predavac;
            zauzecaSala[datum.getMonth()][datum.getDate()-1].push(pomocniElement)
            console.log('VANREDNA', zauzecaSala);
        }
  }
  function iscrtajKalendarImpl(kalendarRef, mjesec) {
    //Div u kojem se nalazi kalendar
    //Djeca su mu labela sa nazivom kalendara i div koji kontrolise responzivnost
    const divGlavni = document.createElement("div");
    divGlavni.className = "glavni";
    //Naziv mjeseca
    const labelMjesec = document.createElement("label");
    labelMjesec.innerHTML = Mjeseci[mjesec];
    labelMjesec.className = "novembar";
    //Div koji mijenja flex na mobilnoj verziji
    //Djeca su mu div sa danima i grid-container
    const divResponzivnost = document.createElement("div");
    divResponzivnost.className = "rowToColumn";
    //Div koji sadrzi dane u sedmici
    //Djeca su mu divovi koji predstavljaju dane u sedmici
    const divDani = document.createElement("div");
    divDani.className = "days";
    const divPon = document.createElement("div");
    divPon.innerHTML = "PON";
    divPon.className = "day";
    const divUto = document.createElement("div");
    divUto.innerHTML = "UTO";
    divUto.className = "day";
    const divSri = document.createElement("div");
    divSri.innerHTML = "SRI";
    divSri.className = "day";
    const divCet = document.createElement("div");
    divCet.innerHTML = "CET";
    divCet.className = "day";
    const divPet = document.createElement("div");
    divPet.innerHTML = "PET";
    divPet.className = "day";
    const divSub = document.createElement("div");
    divSub.innerHTML = "SUB";
    divSub.className = "day";
    const divNed = document.createElement("div");
    divNed.innerHTML = "NED";
    divNed.className = "day";
    divDani.append(divPon, divUto, divSri, divCet, divPet, divSub, divNed);
    //Div koji sarzi sve dane u mjesecu
    const divGridContainer = document.createElement("div");
    divGridContainer.className = "grid-container";

    //Crtanje kalendara
    let prviDan = new Date(danasnjiDatum.getFullYear(), mjesec, 1).getDay();
    prviDan = prviDan ? prviDan : 7;
    const brojDana = dajBrojDana(mjesec, danasnjiDatum.getFullYear());

    let dan = null;
    let datum = null;
    let sala = null;

    for (let i = 1; i < brojDana + prviDan; i++) {
      //Prikazi prazan div na mjestu gdje mjesec jos nije poceo
      if (i < prviDan) {
        dan = document.createElement("div");
        dan.className = "hidden notDay";
        divGridContainer.appendChild(dan);
      }
      //Ukoliko je mjesec poceo prikazi dan
      else {
        let jeLiZauzeta = false;
        // if(zauzecaSala[mjesec][i - prviDan] && zauzecaSala[mjesec][i - prviDan][0]){
        //     jeLiZauzeta = true;
        // }
        dan = document.createElement("div");
        dan.className = "hidden wholeCell";
        datum = document.createElement("div");
        datum.innerHTML = i - prviDan + 1;
        datum.className = "primaryPart";
        sala = document.createElement("div");
        sala.className = jeLiZauzeta ? "zauzeta" : "slobodna";
        sala.id="sala-" + mjesec + '-' + (i-prviDan);
        dan.append(datum, sala);
        divGridContainer.appendChild(dan);
      }
    }

    divResponzivnost.append(divDani, divGridContainer);
    divGlavni.append(labelMjesec, divResponzivnost);
    if (kalendarRef.childNodes[0])
      kalendarRef.removeChild(kalendarRef.childNodes[0]);
    kalendarRef.appendChild(divGlavni);
  }
  return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl
  };
})();
//primjer korištenja modula
// Kalendar.obojiZauzeca(document.getElementById('kalendar'),1,'1-15','12:00','13:30');

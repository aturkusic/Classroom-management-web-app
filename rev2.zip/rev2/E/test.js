let assert = chai.assert;
mocha.setup({
  ignoreLeaks: true
});
describe("iscrtajKalendar()", function() {
  it("Pozivanje iscrtajKalendar za mjesec sa 30 dana: očekivano je da se prikaže 30 dana / april", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 3);
    let sviDani = document.getElementsByClassName("wholeCell");
    assert.equal(sviDani.length, 30);
    kalendar.remove();
    kalendar = null;
  });
});

describe("iscrtajKalendar()", function() {
  it("Pozivanje iscrtajKalendar za mjesec sa 31 dan: očekivano je da se prikaže 31 dan / januar", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
    let sviDani = document.getElementsByClassName("wholeCell");
    assert.equal(sviDani.length, 31);
    kalendar.remove();
    kalendar = null;
  });
});

describe("iscrtajKalendar()", function() {
  it("Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 1. dan u petak", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    let prazneCelije = document.getElementsByClassName("notDay");
    let prviDan = new Date(danasnjiDatum.getFullYear(), 10, 0).getDay();
    assert.equal(prviDan, prazneCelije.length);
    kalendar.remove();
    kalendar = null;
  });
});

describe("iscrtajKalendar()", function() {
  it("Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 30. dan u subotu", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    let sviDani = document.getElementsByClassName("hidden");
    let subota = (sviDani.length % 7) - 1;
    assert.equal(subota, 5);
    kalendar.remove();
    kalendar = null;
  });
});

describe("iscrtajKalendar()", function() {
  it("Pozivanje iscrtajKalendar za januar: očekivano je da brojevi dana idu od 1 do 31 počevši od utorka", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
    let prviDan = new Date(danasnjiDatum.getFullYear(), 0, 0).getDay();
    let prazneCelije = document.getElementsByClassName("notDay");
    let sviDani = document.getElementsByClassName("wholeCell");
    let counter = 0;
    for (i = prviDan; i <= sviDani.length; i++) {
      counter += 1;
    }
    assert.equal(prviDan, prazneCelije.length);
    assert.equal(counter, 31);
    kalendar.remove();
    kalendar = null;
  });
});

describe("iscrtajKalendar()", function() {
  it("Pozivanje iscrtajKalendar za mjesec sa 28 dana: očekivano je da se prikaže 28 dana / februar", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 1);
    let sviDani = document.getElementsByClassName("wholeCell");
    assert.equal(sviDani.length, 28);
    kalendar.remove();
    kalendar = null;
  });
});

describe("iscrtajKalendar()", function() {
  it("Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 28. dan u cetvrtak", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    let sviDani = document.getElementsByClassName("hidden");
    let subota = (sviDani.length % 7) - 3;
    assert.equal(subota, 3);
    kalendar.remove();
    kalendar = null;
  });
});

describe("obojiZauzeca()", function() {
  it("Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "11:22",
      "12:33"
    );
    let sala = document.getElementsByClassName("zauzeta");
    assert.equal(sala.length, 0);
    kalendar.remove();
    kalendar = null;
  });
});

describe("obojiZauzeca()", function() {
  it("Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina: očekivano je da se dan oboji bez obzira što postoje duple vrijednosti", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);

    const vanredna1 = [
      {
        datum: "01.11.2019",
        pocetak: "12:00",
        kraj: "13:00",
        naziv: "string",
        predavac: "Husko"
      },
      {
        datum: "01.11.2019",
        pocetak: "12:00",
        kraj: "13:00",
        naziv: "string",
        predavac: "Husko"
      }
    ];

    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    Kalendar.ucitajPodatke([], vanredna1);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "12:00",
      "13:00"
    );
    let sala = document.getElementsByClassName("zauzeta");
    assert.equal(sala.length, 1);
    kalendar.remove();
    kalendar = null;
  });
});

describe("obojiZauzeca()", function() {
  it("Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);

    const periodicna = [
      {
        dan: 1,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "12:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 2,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      }
    ];

    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 5);
    Kalendar.ucitajPodatke(periodicna, []);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      5,
      "1-01",
      "11:22",
      "16:33"
    );
    let sala = document.getElementsByClassName("zauzeta");
    assert.equal(sala.length, 0);
    kalendar.remove();
    kalendar = null;
  });
});

describe("obojiZauzeca()", function() {
  it("Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano je da se ne oboji zauzeće", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);

    const vanredna2 = [
      {
        datum: "05.07.2019",
        pocetak: "12:00",
        kraj: "13:00",
        naziv: "string",
        predavac: "Husko"
      },
      {
        datum: "05.07.2019",
        pocetak: "12:00",
        kraj: "13:00",
        naziv: "string",
        predavac: "Husko"
      }
    ];

    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    Kalendar.ucitajPodatke([], vanredna2);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "12:00",
      "13:00"
    );
    let sala = document.getElementsByClassName("zauzeta");
    console.log(sala);
    assert.equal(sala.length, 0);
    kalendar.remove();
    kalendar = null;
  });
});

describe("obojiZauzeca()", function() {
  it("Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi dani oboje", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);

    const periodicna2 = [
      {
        dan: 0,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "12:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 1,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 2,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 3,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 4,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 5,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 6,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      }
    ];

    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    Kalendar.ucitajPodatke(periodicna2, []);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "11:22",
      null
    );
    let sala = document.getElementsByClassName("zauzeta");
    assert.equal(sala.length, 30);
    kalendar.remove();
    kalendar = null;
  });
});

describe("obojiZauzeca()", function() {
  // pogledat ce lila kasnije
  it("Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);

    const periodicna3 = [
      {
        dan: 0,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "12:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 1,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 2,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 3,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 4,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 5,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 6,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      }
    ];

    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    Kalendar.ucitajPodatke(periodicna3, []);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "11:22",
      null
    );
    //uzimi br zaizetih
    let sala1 = document.getElementsByClassName("zauzeta");

    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "11:22",
      null
    );
    //uzimi br zaizetih
    let sala2 = document.getElementsByClassName("zauzeta");

    assert.equal(sala1.length, sala2.length);
    kalendar.remove();
    kalendar = null;
  });
});

describe("obojiZauzeca()", function() {
  it("Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: očekivano da se zauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podac", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);

    const periodicna4 = [
      {
        dan: 0,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "12:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 1,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 2,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 3,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 4,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 5,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      },
      {
        dan: 6,
        semestar: "zimski",
        pocetak: "11:22",
        kraj: "16:33",
        naziv: "Naziv",
        predavac: "Rukf"
      }
    ];

    const vanredna4 = [
      {
        datum: "05.11.2019",
        pocetak: "11:22",
        kraj: "13:00",
        naziv: "string",
        predavac: "Husko"
      },
      {
        datum: "06.11.2019",
        pocetak: "11:22",
        kraj: "13:00",
        naziv: "string",
        predavac: "Husko"
      }
    ];

    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    Kalendar.ucitajPodatke(periodicna4, []);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "11:22",
      null
    );

    Kalendar.ucitajPodatke([], vanredna4);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "11:22",
      null
    );

    let sala = document.getElementsByClassName("zauzeta");
    assert.equal(sala.length, 2);
    kalendar.remove();
    kalendar = null;
  });
});

describe("obojiZauzeca()", function() {
  it("Pozivanje ucitajPodatke, obojiZauzeca, za sale gdje je su svaki dan slobodne: očekivano da su sve sale zelene", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);

    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    Kalendar.ucitajPodatke([], []);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "11:22",
      null
    );

    let sala = document.getElementsByClassName("slobodna");
    assert.equal(sala.length, 30);
    kalendar.remove();
    kalendar = null;
  });
});


describe("obojiZauzeca()", function() {
  it("Pozivanje ucitajPodatke, obojiZauzeca, za vanrednu salu 15.tog novembra: očekivano da je sala 15.tog novembra zauzeta", function() {
    kalendar = document.createElement("div");
    kalendar.id = "kalendar";
    body = document.getElementsByTagName("body")[0];
    body.append(kalendar);

    const vanredna6 = [
      {
        datum: "15.11.2019",
        pocetak: "12:00",
        kraj: "13:00",
        naziv: "string",
        predavac: "Husko"
      },
    ]

    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
    Kalendar.ucitajPodatke([], vanredna6);
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      10,
      "1-01",
      "12:00",
      null
    );

    let sala = document.getElementsByClassName("zauzeta");
    assert.equal(sala.length, 1);
    kalendar.remove();
    kalendar = null;
  });
});